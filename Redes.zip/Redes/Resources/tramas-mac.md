---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Cabecera
MAC ^YmNb0aGd

Cabecera
LLC ^qb31AjKJ

Datos ^FxMor7J1

Cola
MAC ^EzJcQsT9

Unidad de datos del
protocolo LLC (PDU) ^zADOE91X

Trama MAC ^yAJJEFWO

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 910,
			"versionNonce": 400011753,
			"isDeleted": false,
			"id": "bJQAlP1yTWy6ph_hbOKNf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.41802978515625,
			"y": -230.30059735110973,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 578.117642485125,
			"height": 81.30895153812143,
			"seed": 231369594,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681835479602,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 385,
			"versionNonce": 1611372521,
			"isDeleted": false,
			"id": "YmNb0aGd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.7929979586802,
			"y": -212.3528578229306,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 84.32917785644531,
			"height": 46.729282493173244,
			"seed": 1887954025,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"fontSize": 18.6917129972693,
			"fontFamily": 1,
			"text": "Cabecera\nMAC",
			"rawText": "Cabecera\nMAC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cabecera\nMAC",
			"lineHeight": 1.25,
			"baseline": 39
		},
		{
			"type": "line",
			"version": 366,
			"versionNonce": 705230631,
			"isDeleted": false,
			"id": "8YZgetopFHfkOLktSiUEd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -265.86187847455375,
			"y": -230.24243329026098,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.7962708809936834,
			"height": 78.74362307071819,
			"seed": 1608365543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.7962708809936834,
					78.74362307071819
				]
			]
		},
		{
			"type": "text",
			"version": 485,
			"versionNonce": 277000905,
			"isDeleted": false,
			"id": "qb31AjKJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -245.35643005935634,
			"y": -212.9447459057794,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 84.32917785644531,
			"height": 46.729282493173244,
			"seed": 1887954025,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"fontSize": 18.6917129972693,
			"fontFamily": 1,
			"text": "Cabecera\nLLC",
			"rawText": "Cabecera\nLLC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cabecera\nLLC",
			"lineHeight": 1.25,
			"baseline": 39
		},
		{
			"type": "line",
			"version": 353,
			"versionNonce": 877492807,
			"isDeleted": false,
			"id": "pSAjzh_SEhV4dN84nCCGE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -143.16404694902184,
			"y": -229.89252459027705,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.08328216850589958,
			"height": 79.66680971144484,
			"seed": 473016361,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.08328216850589958,
					79.66680971144484
				]
			]
		},
		{
			"type": "text",
			"version": 417,
			"versionNonce": 487813545,
			"isDeleted": false,
			"id": "FxMor7J1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -69.60597479038785,
			"y": -199.98200947719218,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 58.10713195800781,
			"height": 23.36464124658662,
			"seed": 1819404297,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"fontSize": 18.691712997269295,
			"fontFamily": 1,
			"text": "Datos",
			"rawText": "Datos",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datos",
			"lineHeight": 1.25,
			"baseline": 16
		},
		{
			"type": "text",
			"version": 463,
			"versionNonce": 89430375,
			"isDeleted": false,
			"id": "EzJcQsT9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.40077061768392,
			"y": -212.64874244499958,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.77227783203125,
			"height": 46.72928249317324,
			"seed": 1887954025,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"fontSize": 18.691712997269295,
			"fontFamily": 1,
			"text": "Cola\nMAC",
			"rawText": "Cola\nMAC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cola\nMAC",
			"lineHeight": 1.25,
			"baseline": 39
		},
		{
			"type": "line",
			"version": 428,
			"versionNonce": 451499145,
			"isDeleted": false,
			"id": "mUpczjXWP0jgj3PKDot_r",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 62.16068421875457,
			"y": -229.0747197871451,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.7962708809936834,
			"height": 78.74362307071819,
			"seed": 1608365543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681835308993,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.7962708809936834,
					78.74362307071819
				]
			]
		},
		{
			"type": "arrow",
			"version": 124,
			"versionNonce": 1583539591,
			"isDeleted": false,
			"id": "rVDv_PFt9XKkdXW3HLtdq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -263.39768727620446,
			"y": -75.86840577601953,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 322.35041300455725,
			"height": 0.7951863606770644,
			"seed": 934892711,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "zADOE91X"
				}
			],
			"updated": 1681835340318,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					322.35041300455725,
					-0.7951863606770644
				]
			]
		},
		{
			"type": "text",
			"version": 47,
			"versionNonce": 1787135335,
			"isDeleted": false,
			"id": "zADOE91X",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -204.41239929199224,
			"y": -101.26599895635806,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 204.3798370361328,
			"height": 50,
			"seed": 578466697,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835356167,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Unidad de datos del\nprotocolo LLC (PDU)",
			"rawText": "Unidad de datos del\nprotocolo LLC (PDU)",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "rVDv_PFt9XKkdXW3HLtdq",
			"originalText": "Unidad de datos del\nprotocolo LLC (PDU)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 131,
			"versionNonce": 1738105129,
			"isDeleted": false,
			"id": "DFpnjQfFIiP94vZrDClTL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -386.81555430094386,
			"y": -7.813748793597597,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 561.5689595540364,
			"height": 0.8950297037760606,
			"seed": 1251885191,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "yAJJEFWO"
				}
			],
			"updated": 1681835372060,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					561.5689595540364,
					0.8950297037760606
				]
			]
		},
		{
			"type": "text",
			"version": 18,
			"versionNonce": 1940507367,
			"isDeleted": false,
			"id": "yAJJEFWO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.70104217529286,
			"y": -19.866233941709567,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 115.33993530273438,
			"height": 25,
			"seed": 500126407,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681835377080,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Trama MAC",
			"rawText": "Trama MAC",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "DFpnjQfFIiP94vZrDClTL",
			"originalText": "Trama MAC",
			"lineHeight": 1.25,
			"baseline": 17
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#000000",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 388.440080124625,
		"scrollY": 358.637570669998,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%