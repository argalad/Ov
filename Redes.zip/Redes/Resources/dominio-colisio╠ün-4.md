---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Dominio de colisión ^MnAXsZ73

Max. 5m ^sJII6shy

HUB
100BASE-TX ^GpceayAW

HUB
100BASE-TX ^UzK7FDLt

Dominio de colisión ^fTx1NEmh

Max. 5m ^AhY1bO9D

HUB
100BASE-TX ^qtZ8clvs

HUB
100BASE-TX ^CccxCtiN

SWITCH
100BASE-TX ^qpwUxldL

SWITCH
100BASE-TX ^lBfChkUV

Dominio
de colisión ^XkGHn4KM

Dominio
de colisión ^JTxFXyb2

Dominio
de colisión ^EvDSssG1

Dominio
de colisión ^vC2Hxxk0

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "ellipse",
			"version": 1418,
			"versionNonce": 983509282,
			"isDeleted": false,
			"id": "i65m5ojui3IRM0rSvL9u5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -585.4789918805827,
			"y": -88.89002681057866,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 639.1758182338217,
			"height": 359.9931257264907,
			"seed": 2035219390,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 809,
			"versionNonce": 555545086,
			"isDeleted": false,
			"id": "MnAXsZ73",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -349.7558415113134,
			"y": 230.22500940168214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 189.04751586914062,
			"height": 26.67493840100947,
			"seed": 942180286,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"fontSize": 21.339950720807575,
			"fontFamily": 1,
			"text": "Dominio de colisión",
			"rawText": "Dominio de colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio de colisión",
			"lineHeight": 1.25,
			"baseline": 19
		},
		{
			"type": "rectangle",
			"version": 1463,
			"versionNonce": 1088533730,
			"isDeleted": false,
			"id": "DdJSzza5Q7j6PJ5dTZE68",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -489.34660926421464,
			"y": 138.06223559326065,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"3i6k0zzINC3GVCSoZDNLp"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1686,
			"versionNonce": 2129265214,
			"isDeleted": false,
			"id": "2rPokbG3RG8NFDT3IaHBE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -504.13644475719343,
			"y": 167.36795397567096,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"3i6k0zzINC3GVCSoZDNLp"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1521,
			"versionNonce": 1046268066,
			"isDeleted": false,
			"id": "NAouuJxu95qUiJnDWjClF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -482.55013788095243,
			"y": 143.67487401038537,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"3i6k0zzINC3GVCSoZDNLp"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1486,
			"versionNonce": 2032863870,
			"isDeleted": false,
			"id": "GUrBArXbaRec4n0aIoEax",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -496.82144390553685,
			"y": 173.8089626395705,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"3i6k0zzINC3GVCSoZDNLp"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1455,
			"versionNonce": 1254057058,
			"isDeleted": false,
			"id": "YcgBEJwEcXdvy_AX1TaFa",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -447.4263369801199,
			"y": 172.72622361504853,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"3i6k0zzINC3GVCSoZDNLp"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 361,
			"versionNonce": 1319176894,
			"isDeleted": false,
			"id": "S-vJcyghyxWNfRrebnN0e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -333.3635327614949,
			"y": 4.188853805317706,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 150.10300063043206,
			"height": 0.18913975226441215,
			"seed": 1024435874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					150.10300063043206,
					0.18913975226441215
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1544,
			"versionNonce": 802719778,
			"isDeleted": false,
			"id": "u4ke0xC_s1nMNfQeCWoIe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -413.12668487192593,
			"y": 138.06125872784068,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"JbortPXPEiu3Q28MZ4npH"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1767,
			"versionNonce": 1038942974,
			"isDeleted": false,
			"id": "Z8GRRM0X7yGrOxnCNfDxp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -427.9165203649047,
			"y": 167.36697711025096,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"JbortPXPEiu3Q28MZ4npH"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1602,
			"versionNonce": 630666210,
			"isDeleted": false,
			"id": "JSCqvbn4pqNUaS0rmvqoA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -406.33021348866373,
			"y": 143.6738971449654,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"JbortPXPEiu3Q28MZ4npH"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1567,
			"versionNonce": 160428862,
			"isDeleted": false,
			"id": "o7vj4z9ssqRGDtrPnRFS4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -420.60151951324815,
			"y": 173.80798577415055,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"JbortPXPEiu3Q28MZ4npH"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1536,
			"versionNonce": 235562914,
			"isDeleted": false,
			"id": "GHM_PTLEjYhmdgov8MciB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -371.2064125878312,
			"y": 172.72524674962858,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"JbortPXPEiu3Q28MZ4npH"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1476,
			"versionNonce": 2078989182,
			"isDeleted": false,
			"id": "3ilkm6DdRrDG7AGOKHROG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.7704953583901,
			"y": 138.34955032023092,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"gT5inbry-mpTAya-QG35q"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1699,
			"versionNonce": 828449634,
			"isDeleted": false,
			"id": "wFdcneN3p2LyOJopICqak",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -349.5603308513689,
			"y": 167.6552687026412,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"gT5inbry-mpTAya-QG35q"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1534,
			"versionNonce": 1799273406,
			"isDeleted": false,
			"id": "SWMjn--FWGSt6ny9SaxA8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -327.97402397512786,
			"y": 143.96218873735563,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"gT5inbry-mpTAya-QG35q"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1498,
			"versionNonce": 2045404962,
			"isDeleted": false,
			"id": "xJ-PmyFHqEve6vwRnZNIY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -342.24532999971234,
			"y": 174.0962773665408,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"gT5inbry-mpTAya-QG35q"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1468,
			"versionNonce": 1034720254,
			"isDeleted": false,
			"id": "PxnqmqeBG15dSg3rhk6Ry",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -292.85022307429534,
			"y": 173.01353834201882,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"gT5inbry-mpTAya-QG35q"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 334,
			"versionNonce": 806695650,
			"isDeleted": false,
			"id": "m-yNk4TIwvoO6yjtO_WpT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -469.2980978872931,
			"y": 138.14885680850546,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.794210793802804,
			"height": 99.21094048373006,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.794210793802804,
					-99.21094048373006
				]
			]
		},
		{
			"type": "line",
			"version": 324,
			"versionNonce": 1832215614,
			"isDeleted": false,
			"id": "0oCALGHUicswMqzRl7GCA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -393.20949211788746,
			"y": 39.143383684773084,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8022856141919125,
			"height": 98.30103686243935,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.8022856141919125,
					98.30103686243935
				]
			]
		},
		{
			"type": "line",
			"version": 329,
			"versionNonce": 913344162,
			"isDeleted": false,
			"id": "z2CQENDOhVK6p5KaI9eZl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -365.24416101451334,
			"y": 39.14012746670656,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 49.466836757682536,
			"height": 99.03154612696476,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					49.466836757682536,
					99.03154612696476
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1581,
			"versionNonce": 196750462,
			"isDeleted": false,
			"id": "hQ79tHSNNdq87PLSMIAoU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.65070461134962,
			"y": 140.7357059953417,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"CzWKj072Wn7T5KmYzlG2x"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1804,
			"versionNonce": 1168859746,
			"isDeleted": false,
			"id": "Uudl9luyPtFNArnKK9-UU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -235.44054010432836,
			"y": 170.04142437775198,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"CzWKj072Wn7T5KmYzlG2x"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1639,
			"versionNonce": 1190915262,
			"isDeleted": false,
			"id": "i7g0KHKM2meoZyaAOw-YM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -213.85423322808737,
			"y": 146.34834441246642,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"CzWKj072Wn7T5KmYzlG2x"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1603,
			"versionNonce": 680838690,
			"isDeleted": false,
			"id": "Op0rGzi0ebSo9KuUjGcNy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -228.12553925267184,
			"y": 176.48243304165157,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"CzWKj072Wn7T5KmYzlG2x"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1572,
			"versionNonce": 1822139646,
			"isDeleted": false,
			"id": "2r2iK6pu1ZIALPPx3SZv1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -178.73043232725485,
			"y": 175.39969401712955,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"CzWKj072Wn7T5KmYzlG2x"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1661,
			"versionNonce": 2015080930,
			"isDeleted": false,
			"id": "gbfqCY-IMFjWn7JnfCCVP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -144.60049840311007,
			"y": 140.73472912992173,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"pOk5_qVx81rhHrMPaMzKa"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1884,
			"versionNonce": 1847219518,
			"isDeleted": false,
			"id": "TfgM9JWs8a6afy9tZmq03",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -159.3903338960888,
			"y": 170.04044751233204,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"pOk5_qVx81rhHrMPaMzKa"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1719,
			"versionNonce": 1464804770,
			"isDeleted": false,
			"id": "0m0QLptjuCtI_xgPw842Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.8040270198478,
			"y": 146.34736754704645,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"pOk5_qVx81rhHrMPaMzKa"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1683,
			"versionNonce": 1691942270,
			"isDeleted": false,
			"id": "vj5UQJPMEMsIsD4X5jSLo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -152.07533304443228,
			"y": 176.48145617623163,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"pOk5_qVx81rhHrMPaMzKa"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1652,
			"versionNonce": 794698082,
			"isDeleted": false,
			"id": "F1EZmXZS5dKR5bi5WubpU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -102.68022611901529,
			"y": 175.3987171517096,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"pOk5_qVx81rhHrMPaMzKa"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1592,
			"versionNonce": 370711998,
			"isDeleted": false,
			"id": "nBqUHS9PhYuxgH3eoroxv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -66.40864895099617,
			"y": 141.02302072231197,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"sodXYdDV_WVH06Tc97Q_6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1815,
			"versionNonce": 1805100322,
			"isDeleted": false,
			"id": "GKtiUvSbAPUoezjCC7zCG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -81.19848444397496,
			"y": 170.32873910472227,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"sodXYdDV_WVH06Tc97Q_6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1650,
			"versionNonce": 1996109310,
			"isDeleted": false,
			"id": "b4naQScU28o1qVXGlUP-W",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.612177567733966,
			"y": 146.63565913943668,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"sodXYdDV_WVH06Tc97Q_6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1614,
			"versionNonce": 896184546,
			"isDeleted": false,
			"id": "c3pmILcCzMAOHiORudbC8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -73.88348359231838,
			"y": 176.76974776862187,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"sodXYdDV_WVH06Tc97Q_6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1583,
			"versionNonce": 813614654,
			"isDeleted": false,
			"id": "XBNTreS33Jq07aoZzhwXl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -24.488376666901445,
			"y": 175.68700874409984,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"sodXYdDV_WVH06Tc97Q_6"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 452,
			"versionNonce": 812008610,
			"isDeleted": false,
			"id": "OrvYBWFm2L_TaPZcOWcrJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -200.6021932344281,
			"y": 140.82232721058648,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.794210793802804,
			"height": 99.21094048373006,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.794210793802804,
					-99.21094048373006
				]
			]
		},
		{
			"type": "line",
			"version": 451,
			"versionNonce": 596070014,
			"isDeleted": false,
			"id": "w1Asammuv5liGi8eRk2e3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.5135874650224,
			"y": 40.20629843582239,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8022856141919125,
			"height": 100.07318589083697,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.8022856141919125,
					100.07318589083697
				]
			]
		},
		{
			"type": "line",
			"version": 462,
			"versionNonce": 909729890,
			"isDeleted": false,
			"id": "IR_QifDpeWZB2liWXScQH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -97.53675530052374,
			"y": 39.69941944888228,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.121277451086854,
			"height": 101.14572454687008,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178063920,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.121277451086854,
					101.14572454687008
				]
			]
		},
		{
			"type": "text",
			"version": 242,
			"versionNonce": 1825885886,
			"isDeleted": false,
			"id": "sJII6shy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -312.1240765821375,
			"y": -28.958989648779323,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 85.74650573730469,
			"height": 26.67493840100947,
			"seed": 416859042,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178063921,
			"link": null,
			"locked": false,
			"fontSize": 21.339950720807575,
			"fontFamily": 1,
			"text": "Max. 5m",
			"rawText": "Max. 5m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 5m",
			"lineHeight": 1.25,
			"baseline": 19
		},
		{
			"type": "rectangle",
			"version": 227,
			"versionNonce": 909485282,
			"isDeleted": false,
			"id": "SGCgBUwwU4zS2GryZa3kr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -452.04585861809437,
			"y": -32.52105437846195,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 119,
			"height": 72,
			"seed": 1768757950,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "GpceayAW"
				}
			],
			"updated": 1682178068932,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 244,
			"versionNonce": 950187838,
			"isDeleted": false,
			"id": "GpceayAW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -438.20767044670765,
			"y": -15.164480251153883,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 91.32362365722656,
			"height": 37.28685174538387,
			"seed": 411755234,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178063921,
			"link": null,
			"locked": false,
			"fontSize": 14.91474069815355,
			"fontFamily": 1,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "SGCgBUwwU4zS2GryZa3kr",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25,
			"baseline": 32
		},
		{
			"type": "rectangle",
			"version": 266,
			"versionNonce": 1732249470,
			"isDeleted": false,
			"id": "ZTewdN7c0Z93pLMT779Z4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -183.86654211709188,
			"y": -31.788614988268627,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 119,
			"height": 71,
			"seed": 1768757950,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "UzK7FDLt"
				},
				{
					"id": "rgduawPknHVmaxdT1aSB-",
					"type": "arrow"
				}
			],
			"updated": 1682178236306,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 226,
			"versionNonce": 1064337342,
			"isDeleted": false,
			"id": "UzK7FDLt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -170.02835394570516,
			"y": -14.932040860960562,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 91.32362365722656,
			"height": 37.28685174538387,
			"seed": 1371459426,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178063922,
			"link": null,
			"locked": false,
			"fontSize": 14.91474069815355,
			"fontFamily": 1,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZTewdN7c0Z93pLMT779Z4",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25,
			"baseline": 32
		},
		{
			"type": "ellipse",
			"version": 1781,
			"versionNonce": 203130046,
			"isDeleted": false,
			"id": "KFQMb12nZobgQYaDHnWt2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 683.2468207037732,
			"y": -92.11800482384353,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 639.1758182338217,
			"height": 359.9931257264907,
			"seed": 2035219390,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1172,
			"versionNonce": 2027597346,
			"isDeleted": false,
			"id": "fTx1NEmh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 918.9699710730425,
			"y": 226.99703138841727,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 189.04751586914062,
			"height": 26.67493840100947,
			"seed": 942180286,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"fontSize": 21.339950720807575,
			"fontFamily": 1,
			"text": "Dominio de colisión",
			"rawText": "Dominio de colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio de colisión",
			"lineHeight": 1.25,
			"baseline": 19
		},
		{
			"type": "rectangle",
			"version": 1826,
			"versionNonce": 436747518,
			"isDeleted": false,
			"id": "Th8HR09CxNImTJIRxH2K2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 779.3792033201413,
			"y": 134.83425757999578,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"x2VfgLRS4Dj61bhmO5zb_",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2049,
			"versionNonce": 392468962,
			"isDeleted": false,
			"id": "NsLmIwXokPvO-7uNqmz1G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 764.5893678271625,
			"y": 164.13997596240608,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"x2VfgLRS4Dj61bhmO5zb_",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1884,
			"versionNonce": 1916005694,
			"isDeleted": false,
			"id": "41ew6vBLxOVzQUAnIdpYu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 786.1756747034035,
			"y": 140.4468959971205,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"x2VfgLRS4Dj61bhmO5zb_",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1849,
			"versionNonce": 1832586658,
			"isDeleted": false,
			"id": "F-EhU9Q-6VmS9PI5lYz3d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 771.9043686788191,
			"y": 170.58098462630562,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"x2VfgLRS4Dj61bhmO5zb_",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1818,
			"versionNonce": 1644139902,
			"isDeleted": false,
			"id": "N3EuF5rs66G4tUFQ8abwu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 821.299475604236,
			"y": 169.49824560178365,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"x2VfgLRS4Dj61bhmO5zb_",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 724,
			"versionNonce": 1871513954,
			"isDeleted": false,
			"id": "8ckBbTZhUsj5rNbA1k1WF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 935.362279822861,
			"y": 0.9608757920528319,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 150.10300063043206,
			"height": 0.18913975226441215,
			"seed": 1024435874,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					150.10300063043206,
					0.18913975226441215
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1907,
			"versionNonce": 1655453118,
			"isDeleted": false,
			"id": "6ipLBT-e1eaj3nHk1Vkdr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 855.59912771243,
			"y": 134.8332807145758,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"sdtbg0Anz8BwSi7-js5R3",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2130,
			"versionNonce": 363433250,
			"isDeleted": false,
			"id": "XizbYy0btcWEbSPbHP3GD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 840.8092922194512,
			"y": 164.13899909698608,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"sdtbg0Anz8BwSi7-js5R3",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1965,
			"versionNonce": 492490238,
			"isDeleted": false,
			"id": "n3tM3ZSvZ6cO980nuA9KE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 862.3955990956922,
			"y": 140.44591913170052,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"sdtbg0Anz8BwSi7-js5R3",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1930,
			"versionNonce": 352295138,
			"isDeleted": false,
			"id": "nI8q3QGEIMwHOOQGttIXr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 848.1242930711078,
			"y": 170.58000776088568,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"sdtbg0Anz8BwSi7-js5R3",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1899,
			"versionNonce": 1863081534,
			"isDeleted": false,
			"id": "1Giw1BzMB6F31YQG4OS9a",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 897.5193999965247,
			"y": 169.4972687363637,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"sdtbg0Anz8BwSi7-js5R3",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1839,
			"versionNonce": 488516770,
			"isDeleted": false,
			"id": "3sJIgVquuDYER-VnddzZ3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 933.9553172259658,
			"y": 135.12157230696604,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"IZh66auewVce1TUnaKPUY",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2062,
			"versionNonce": 1822549630,
			"isDeleted": false,
			"id": "wUkdUUuf8khX-fCLO5Qm2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 919.165481732987,
			"y": 164.42729068937632,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"IZh66auewVce1TUnaKPUY",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1897,
			"versionNonce": 330582114,
			"isDeleted": false,
			"id": "QQIu4yfHDff6gKDePTL8R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 940.751788609228,
			"y": 140.73421072409076,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"IZh66auewVce1TUnaKPUY",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1861,
			"versionNonce": 1725720254,
			"isDeleted": false,
			"id": "2UgTQcqqIpS0gxJzJyKxg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 926.4804825846436,
			"y": 170.86829935327592,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"IZh66auewVce1TUnaKPUY",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1831,
			"versionNonce": 1351674914,
			"isDeleted": false,
			"id": "nuUcW_UP_7vTp4w86xeL4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 975.8755895100605,
			"y": 169.78556032875395,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"IZh66auewVce1TUnaKPUY",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 697,
			"versionNonce": 1851580158,
			"isDeleted": false,
			"id": "10kBatBpoClUWNsx0U6_T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 799.4277146970628,
			"y": 134.92087879524058,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.794210793802804,
			"height": 99.21094048373006,
			"seed": 632767230,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.794210793802804,
					-99.21094048373006
				]
			]
		},
		{
			"type": "line",
			"version": 687,
			"versionNonce": 1503860706,
			"isDeleted": false,
			"id": "Dur6x7cGpMeyE1qW-uZkd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 875.5163204664684,
			"y": 35.91540567150821,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8022856141919125,
			"height": 98.30103686243935,
			"seed": 699567678,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.8022856141919125,
					98.30103686243935
				]
			]
		},
		{
			"type": "line",
			"version": 692,
			"versionNonce": 1470385982,
			"isDeleted": false,
			"id": "G0vFk8VwMotUR0hMrQVW_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 903.4816515698426,
			"y": 35.912149453441685,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 49.466836757682536,
			"height": 99.03154612696476,
			"seed": 194738238,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					49.466836757682536,
					99.03154612696476
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1944,
			"versionNonce": 519687074,
			"isDeleted": false,
			"id": "2S5eDHzZTHlZXKvf3yrEM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1048.0751079730064,
			"y": 137.50772798207683,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"ca_Gg5JjjWtcJZb5mun48",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2167,
			"versionNonce": 1058256766,
			"isDeleted": false,
			"id": "-PQ2dNY4KY34k_blxq5ql",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1033.2852724800275,
			"y": 166.8134463644871,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"ca_Gg5JjjWtcJZb5mun48",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2002,
			"versionNonce": 918816610,
			"isDeleted": false,
			"id": "ceuwOPyZryeFqcVJc-Uwm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1054.8715793562685,
			"y": 143.12036639920154,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"ca_Gg5JjjWtcJZb5mun48",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1966,
			"versionNonce": 216799166,
			"isDeleted": false,
			"id": "Ad_lASnF-IAiqq41MKufU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1040.600273331684,
			"y": 173.2544550283867,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"ca_Gg5JjjWtcJZb5mun48",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1935,
			"versionNonce": 424725282,
			"isDeleted": false,
			"id": "5MWSFiEe6PXdILx4c5hn7",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1089.995380257101,
			"y": 172.17171600386467,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"ca_Gg5JjjWtcJZb5mun48",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2024,
			"versionNonce": 2035183614,
			"isDeleted": false,
			"id": "rUCKvKf4cZF__H2IHEMWQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1124.1253141812458,
			"y": 137.50675111665686,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"WBNNu_-QbsGmcHctfpSNL",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2247,
			"versionNonce": 1561269986,
			"isDeleted": false,
			"id": "qRsqloNDGZ_1EGpQeSrGE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1109.3354786882671,
			"y": 166.81246949906716,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"WBNNu_-QbsGmcHctfpSNL",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2082,
			"versionNonce": 272351294,
			"isDeleted": false,
			"id": "leku7ORAw8HxKKcqofEDI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1130.9217855645081,
			"y": 143.11938953378157,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"WBNNu_-QbsGmcHctfpSNL",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2046,
			"versionNonce": 1921903266,
			"isDeleted": false,
			"id": "JLHwbQQ68AnfBn1_vpxkk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1116.6504795399237,
			"y": 173.25347816296676,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"WBNNu_-QbsGmcHctfpSNL",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 2015,
			"versionNonce": 898959486,
			"isDeleted": false,
			"id": "cE7hmsxXB2LHnHlSwqab8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1166.0455864653406,
			"y": 172.17073913844473,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"WBNNu_-QbsGmcHctfpSNL",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1955,
			"versionNonce": 1618757218,
			"isDeleted": false,
			"id": "-7qI4b_roYihwoaV27DGR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1202.3171636333598,
			"y": 137.7950427090471,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.27625407761043,
			"height": 29.05461745207992,
			"seed": 929909630,
			"groupIds": [
				"XQBAEG-jn7h8_LPyjClOU",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2178,
			"versionNonce": 689653950,
			"isDeleted": false,
			"id": "rtqsUSdhaSh-GEvTr_xQL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1187.5273281403809,
			"y": 167.1007610914574,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 68.28759111261911,
			"height": 19.463229438163307,
			"seed": 859159522,
			"groupIds": [
				"XQBAEG-jn7h8_LPyjClOU",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2013,
			"versionNonce": 2141792802,
			"isDeleted": false,
			"id": "I2vSwDwc0Dvefgg45fEHR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1209.113635016622,
			"y": 143.4076811261718,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 23.30172907108968,
			"height": 18.504412769773232,
			"seed": 1576636258,
			"groupIds": [
				"XQBAEG-jn7h8_LPyjClOU",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1977,
			"versionNonce": 175079678,
			"isDeleted": false,
			"id": "JMn8ZWpbHVZ44_7B4wNCq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1194.8423289920377,
			"y": 173.541769755357,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 27.15327683498265,
			"height": 2.974276099368974,
			"seed": 1773146238,
			"groupIds": [
				"XQBAEG-jn7h8_LPyjClOU",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1946,
			"versionNonce": 922981858,
			"isDeleted": false,
			"id": "kp0YasWvK8FvEKf1aVBYV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1244.2374359174544,
			"y": 172.45903073083497,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 5.495240126476098,
			"height": 4.820156345183109,
			"seed": 2030535650,
			"groupIds": [
				"XQBAEG-jn7h8_LPyjClOU",
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 815,
			"versionNonce": 1561506110,
			"isDeleted": false,
			"id": "LzT9-Amml3CCsyVluJy9d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1068.1236193499278,
			"y": 137.5943491973216,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.794210793802804,
			"height": 99.21094048373006,
			"seed": 632767230,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.794210793802804,
					-99.21094048373006
				]
			]
		},
		{
			"type": "line",
			"version": 814,
			"versionNonce": 932874658,
			"isDeleted": false,
			"id": "pKCV663FvZKL9CQXZZ4ID",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1144.2122251193337,
			"y": 36.978320422557516,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8022856141919125,
			"height": 100.07318589083697,
			"seed": 699567678,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.8022856141919125,
					100.07318589083697
				]
			]
		},
		{
			"type": "line",
			"version": 825,
			"versionNonce": 208001406,
			"isDeleted": false,
			"id": "pd4If6H77dUT-7zqriJz_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1171.1890572838322,
			"y": 36.47144143561741,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.121277451086854,
			"height": 101.14572454687008,
			"seed": 194738238,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					50.121277451086854,
					101.14572454687008
				]
			]
		},
		{
			"type": "text",
			"version": 605,
			"versionNonce": 949814626,
			"isDeleted": false,
			"id": "AhY1bO9D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 956.6017360022184,
			"y": -32.1869676620442,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 85.74650573730469,
			"height": 26.67493840100947,
			"seed": 416859042,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178356208,
			"link": null,
			"locked": false,
			"fontSize": 21.339950720807575,
			"fontFamily": 1,
			"text": "Max. 5m",
			"rawText": "Max. 5m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 5m",
			"lineHeight": 1.25,
			"baseline": 19
		},
		{
			"type": "rectangle",
			"version": 591,
			"versionNonce": 1873410494,
			"isDeleted": false,
			"id": "UqljeY_mHYW82S0p4uZXR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 816.6799539662616,
			"y": -35.749032391726836,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 119,
			"height": 72,
			"seed": 1768757950,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "qtZ8clvs"
				},
				{
					"id": "7DvhEb4tlCGMC3LVsVyXi",
					"type": "arrow"
				}
			],
			"updated": 1682178356208,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 608,
			"versionNonce": 524326114,
			"isDeleted": false,
			"id": "qtZ8clvs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 830.5181421376483,
			"y": -18.39245826441877,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 91.32362365722656,
			"height": 37.28685174538387,
			"seed": 411755234,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178356209,
			"link": null,
			"locked": false,
			"fontSize": 14.91474069815355,
			"fontFamily": 1,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "UqljeY_mHYW82S0p4uZXR",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25,
			"baseline": 32
		},
		{
			"type": "rectangle",
			"version": 628,
			"versionNonce": 1651057214,
			"isDeleted": false,
			"id": "_iDfGDkF7CSsgpdJkiDnx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1084.859270467264,
			"y": -35.01659300153349,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 119,
			"height": 71,
			"seed": 1768757950,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "CccxCtiN"
				}
			],
			"updated": 1682178356209,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 590,
			"versionNonce": 769632418,
			"isDeleted": false,
			"id": "CccxCtiN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1098.6974586386507,
			"y": -18.160018874225422,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 91.32362365722656,
			"height": 37.28685174538387,
			"seed": 1371459426,
			"groupIds": [
				"LQg7yHtCLmeOJsxONWx_9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178356209,
			"link": null,
			"locked": false,
			"fontSize": 14.91474069815355,
			"fontFamily": 1,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "_iDfGDkF7CSsgpdJkiDnx",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25,
			"baseline": 32
		},
		{
			"id": "Jb2uBS8WiH-_pCMZ3Hg-0",
			"type": "rectangle",
			"x": 119.02175883471762,
			"y": 322.84569933884563,
			"width": 213,
			"height": 112,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 1200616830,
			"version": 399,
			"versionNonce": 1887263486,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "qpwUxldL"
				},
				{
					"id": "rgduawPknHVmaxdT1aSB-",
					"type": "arrow"
				},
				{
					"id": "AOzCwFFiCHUNUbtLBGfKt",
					"type": "arrow"
				},
				{
					"id": "b-YFxIxjpT4frOTIEefZ7",
					"type": "arrow"
				}
			],
			"updated": 1682178310173,
			"link": null,
			"locked": false
		},
		{
			"id": "qpwUxldL",
			"type": "text",
			"x": 139.77179698169027,
			"y": 343.84569933884563,
			"width": 171.4999237060547,
			"height": 70,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1354944126,
			"version": 346,
			"versionNonce": 404534334,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178220952,
			"link": null,
			"locked": false,
			"text": "SWITCH\n100BASE-TX",
			"rawText": "SWITCH\n100BASE-TX",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 59,
			"containerId": "Jb2uBS8WiH-_pCMZ3Hg-0",
			"originalText": "SWITCH\n100BASE-TX",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 513,
			"versionNonce": 217967522,
			"isDeleted": false,
			"id": "S_QRPslvSovodYfouKqmK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 428.8744671466435,
			"y": 323.07209718435695,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 213,
			"height": 112,
			"seed": 1200616830,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "lBfChkUV"
				},
				{
					"id": "DCiOTkxk-tBrBygM2AWWV",
					"type": "arrow"
				},
				{
					"id": "7DvhEb4tlCGMC3LVsVyXi",
					"type": "arrow"
				}
			],
			"updated": 1682178341806,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 461,
			"versionNonce": 1781978082,
			"isDeleted": false,
			"id": "lBfChkUV",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 449.62450529361615,
			"y": 344.07209718435695,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 171.4999237060547,
			"height": 70,
			"seed": 1354944126,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178225803,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "SWITCH\n100BASE-TX",
			"rawText": "SWITCH\n100BASE-TX",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "S_QRPslvSovodYfouKqmK",
			"originalText": "SWITCH\n100BASE-TX",
			"lineHeight": 1.25,
			"baseline": 59
		},
		{
			"id": "rgduawPknHVmaxdT1aSB-",
			"type": "arrow",
			"x": -61.187605417485365,
			"y": 37.95866512975752,
			"width": 212.73605167463094,
			"height": 282.9466042302678,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 105462654,
			"version": 110,
			"versionNonce": 131618878,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178388054,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					212.73605167463094,
					282.9466042302678
				]
			],
			"lastCommittedPoint": [
				212.73605167463097,
				282.9466042302678
			],
			"startBinding": {
				"elementId": "ZTewdN7c0Z93pLMT779Z4",
				"gap": 3.67893669960651,
				"focus": -0.43426570777999307
			},
			"endBinding": {
				"elementId": "Jb2uBS8WiH-_pCMZ3Hg-0",
				"gap": 1.9404299788203616,
				"focus": -0.20463939622348384
			},
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "6KFA1X-A_EFMBjIDWB_cp",
			"type": "ellipse",
			"x": 129.4601330525673,
			"y": 151.37083352133425,
			"width": 100.32229298942315,
			"height": 78.39030104266385,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"eHtr3QPts4P84XlfcdAj1"
			],
			"roundness": {
				"type": 2
			},
			"seed": 1762589438,
			"version": 146,
			"versionNonce": 118806946,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "AOzCwFFiCHUNUbtLBGfKt",
					"type": "arrow"
				}
			],
			"updated": 1682178304348,
			"link": null,
			"locked": false
		},
		{
			"id": "mHBWIkUpoHdGDMwOrj8yn",
			"type": "rectangle",
			"x": 155.87871937272934,
			"y": 171.7300059701568,
			"width": 48.00075925181328,
			"height": 38.578133458561915,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"eHtr3QPts4P84XlfcdAj1"
			],
			"roundness": {
				"type": 3
			},
			"seed": 514244606,
			"version": 157,
			"versionNonce": 97502718,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178279469,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 220,
			"versionNonce": 1650221758,
			"isDeleted": false,
			"id": "YlosDAltAlQuerP1dORE4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 253.4719288213574,
			"y": 149.90433709276806,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 100.32229298942315,
			"height": 78.39030104266385,
			"seed": 1762589438,
			"groupIds": [
				"sQhWVqeOSvjPndEP0VW8D"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "b-YFxIxjpT4frOTIEefZ7",
					"type": "arrow"
				}
			],
			"updated": 1682178310173,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 231,
			"versionNonce": 513942590,
			"isDeleted": false,
			"id": "rG7ITkduaymyNCedPf96H",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 279.8905151415195,
			"y": 170.26350954159062,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 48.00075925181328,
			"height": 38.578133458561915,
			"seed": 514244606,
			"groupIds": [
				"sQhWVqeOSvjPndEP0VW8D"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178293712,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 199,
			"versionNonce": 265323518,
			"isDeleted": false,
			"id": "1lurpPHVMa8criJxujbQY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 515.297635312091,
			"y": 152.77437290866396,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 100.32229298942315,
			"height": 78.39030104266385,
			"seed": 1762589438,
			"groupIds": [
				"KvFhvLFpod87gjWIiFHTS"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "DCiOTkxk-tBrBygM2AWWV",
					"type": "arrow"
				}
			],
			"updated": 1682178333362,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 210,
			"versionNonce": 1391299106,
			"isDeleted": false,
			"id": "TgK3X1JphnIVxdZjzwUrW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 541.7162216322531,
			"y": 173.13354535748653,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 48.00075925181328,
			"height": 38.578133458561915,
			"seed": 514244606,
			"groupIds": [
				"KvFhvLFpod87gjWIiFHTS"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178291954,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 221,
			"versionNonce": 1276797310,
			"isDeleted": false,
			"id": "rFbaTq4dJOyVZV_GWUeO6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 393.70614771781464,
			"y": 150.550612580628,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 100.32229298942315,
			"height": 78.39030104266385,
			"seed": 1762589438,
			"groupIds": [
				"ZDbBmLcSfdNyvxtqsAtxw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "BKtRmt7edXLf7voVLrF78",
					"type": "arrow"
				}
			],
			"updated": 1682178361448,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 232,
			"versionNonce": 1468891582,
			"isDeleted": false,
			"id": "O4h-wc-jV1MYpFz3YivjS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 420.1247340379768,
			"y": 170.90978502945057,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 48.00075925181328,
			"height": 38.578133458561915,
			"seed": 514244606,
			"groupIds": [
				"ZDbBmLcSfdNyvxtqsAtxw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682178361448,
			"link": null,
			"locked": false
		},
		{
			"id": "AOzCwFFiCHUNUbtLBGfKt",
			"type": "arrow",
			"x": 182.65686169215223,
			"y": 231.62142041331663,
			"width": 29.831804305907383,
			"height": 90.07932214360892,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 791660194,
			"version": 112,
			"versionNonce": 1038000254,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178388054,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					29.831804305907383,
					90.07932214360892
				]
			],
			"lastCommittedPoint": [
				29.831754754665326,
				90.07917251999743
			],
			"startBinding": {
				"elementId": "6KFA1X-A_EFMBjIDWB_cp",
				"gap": 1.9301737128105074,
				"focus": 0.20382468764480352
			},
			"endBinding": {
				"elementId": "Jb2uBS8WiH-_pCMZ3Hg-0",
				"gap": 1.1449567819200865,
				"focus": 0.047116800455814026
			},
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "b-YFxIxjpT4frOTIEefZ7",
			"type": "arrow",
			"x": 294.970733243067,
			"y": 228.7143010459681,
			"width": 14.356509143687333,
			"height": 92.8261206733905,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 75520290,
			"version": 79,
			"versionNonce": 611442878,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178388054,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-14.356509143687333,
					92.8261206733905
				]
			],
			"lastCommittedPoint": [
				-14.434731849977084,
				93.3318919789898
			],
			"startBinding": {
				"elementId": "YlosDAltAlQuerP1dORE4",
				"gap": 1,
				"focus": 0.05018209420305435
			},
			"endBinding": {
				"elementId": "Jb2uBS8WiH-_pCMZ3Hg-0",
				"gap": 1.3052776194870148,
				"focus": 0.4014347631596495
			},
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "BKtRmt7edXLf7voVLrF78",
			"type": "arrow",
			"x": 450.99619349446584,
			"y": 230.19132668658276,
			"width": 44.05410540758061,
			"height": 93.05552367372812,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 945113918,
			"version": 111,
			"versionNonce": 1649737058,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178361448,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					44.05410540758061,
					93.05552367372812
				]
			],
			"lastCommittedPoint": [
				52.29222825969157,
				92.81213035948053
			],
			"startBinding": {
				"elementId": "rFbaTq4dJOyVZV_GWUeO6",
				"focus": 0.2247197880426148,
				"gap": 1.6389639421649491
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "DCiOTkxk-tBrBygM2AWWV",
			"type": "arrow",
			"x": 562.029056835416,
			"y": 232.07425270726011,
			"width": 19.900798754835364,
			"height": 89.99784447709683,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 986478690,
			"version": 51,
			"versionNonce": 255006974,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178388055,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-19.900798754835364,
					89.99784447709683
				]
			],
			"lastCommittedPoint": [
				-19.97129118567932,
				90.31663403454434
			],
			"startBinding": {
				"elementId": "1lurpPHVMa8criJxujbQY",
				"gap": 1,
				"focus": -0.10683642978273375
			},
			"endBinding": {
				"elementId": "S_QRPslvSovodYfouKqmK",
				"gap": 1,
				"focus": -0.04921098367497682
			},
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "7DvhEb4tlCGMC3LVsVyXi",
			"type": "arrow",
			"x": 822.9079447693218,
			"y": 37.25096760827316,
			"width": 205.19902103253548,
			"height": 283.2373028608887,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 966925438,
			"version": 111,
			"versionNonce": 899893566,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178388055,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-205.19902103253548,
					283.2373028608887
				]
			],
			"lastCommittedPoint": [
				-206.1601521145651,
				287.19364230855365
			],
			"startBinding": {
				"elementId": "UqljeY_mHYW82S0p4uZXR",
				"gap": 1,
				"focus": 0.309254254861745
			},
			"endBinding": {
				"elementId": "S_QRPslvSovodYfouKqmK",
				"gap": 2.583826715195073,
				"focus": 0.271242264907433
			},
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "XkGHn4KM",
			"type": "text",
			"x": 117.91200794185227,
			"y": 77.99507666923603,
			"width": 98.73989868164062,
			"height": 50,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 3316222,
			"version": 76,
			"versionNonce": 230159202,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682178383768,
			"link": null,
			"locked": false,
			"text": "Dominio\nde colisión",
			"rawText": "Dominio\nde colisión",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 42,
			"containerId": null,
			"originalText": "Dominio\nde colisión",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 136,
			"versionNonce": 50339426,
			"isDeleted": false,
			"id": "JTxFXyb2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 252.90064873533265,
			"y": 79.65312944030774,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 98.73989868164062,
			"height": 50,
			"seed": 3316222,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178402801,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Dominio\nde colisión",
			"rawText": "Dominio\nde colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio\nde colisión",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "text",
			"version": 113,
			"versionNonce": 587958434,
			"isDeleted": false,
			"id": "EvDSssG1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 390.6027900681455,
			"y": 78.8168507475716,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 98.73989868164062,
			"height": 50,
			"seed": 3316222,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178394726,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Dominio\nde colisión",
			"rawText": "Dominio\nde colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio\nde colisión",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "text",
			"version": 100,
			"versionNonce": 1138615714,
			"isDeleted": false,
			"id": "vC2Hxxk0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 530.8601206299091,
			"y": 79.00920333414786,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 98.73989868164062,
			"height": 50,
			"seed": 3316222,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682178396620,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Dominio\nde colisión",
			"rawText": "Dominio\nde colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio\nde colisión",
			"lineHeight": 1.25,
			"baseline": 42
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#952d2d",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": null,
		"scrollX": 588.9682369402572,
		"scrollY": 713.4274689765199,
		"zoom": {
			"value": 0.48322904482031825
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%