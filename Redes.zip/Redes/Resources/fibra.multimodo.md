---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"id": "iDP2XjtmzKXvUyEzZayaa",
			"type": "ellipse",
			"x": -307.7002258300781,
			"y": -202.22943878173828,
			"width": 29.08917236328125,
			"height": 49.324981689453125,
			"angle": 0,
			"strokeColor": "#a61e4d",
			"backgroundColor": "#e64980",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"seed": 118923238,
			"version": 291,
			"versionNonce": 290079334,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "90EC6avrhew0j-jc3ornl",
					"type": "arrow"
				}
			],
			"updated": 1681760350311,
			"link": null,
			"locked": false
		},
		{
			"id": "vIXbzdoxlc5zXXGYymulO",
			"type": "line",
			"x": -291.3798522949219,
			"y": -202.8713150024414,
			"width": 334.3931884765625,
			"height": 1.369293212890625,
			"angle": 0,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"seed": 542816358,
			"version": 180,
			"versionNonce": 826146554,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-1.369293212890625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 296,
			"versionNonce": 148964774,
			"isDeleted": false,
			"id": "e27EBtfEZhYAJkim5oXqh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.1886965088546,
			"y": -154.79639297202232,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 334.3931884765625,
			"height": 0.06414794921875,
			"seed": 1481859450,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-0.06414794921875
				]
			]
		},
		{
			"id": "aEQ2K2Bx-_odtuxsKFtHV",
			"type": "line",
			"x": 44.934600830078125,
			"y": -205.92227935791016,
			"width": 14.1124267578125,
			"height": 49.03826904296875,
			"angle": 0,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"seed": 666854842,
			"version": 180,
			"versionNonce": 903352250,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12.98699951171875,
					26.975311279296875
				],
				[
					-1.12542724609375,
					49.03826904296875
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "GOnyQY9cSP8IypiMirK5C",
			"type": "arrow",
			"x": -327.6921691894531,
			"y": -179.34491729736328,
			"width": 361.4541015625,
			"height": 0.43218994140625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1174045094,
			"version": 143,
			"versionNonce": 1702899770,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					361.4541015625,
					0.43218994140625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "BJcxXqqmRUayJS8nZ-K5w",
			"type": "arrow",
			"x": -322.1935729980469,
			"y": -163.38822174072266,
			"width": 354.93707275390625,
			"height": 48.4991455078125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 273054758,
			"version": 569,
			"versionNonce": 490871034,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					76.565673828125,
					-39.222076416015625
				],
				[
					133.2806396484375,
					9.277069091796875
				],
				[
					206.7481689453125,
					-37.87841796875
				],
				[
					265.76531982421875,
					8.23297119140625
				],
				[
					321.033935546875,
					-37.74578857421875
				],
				[
					354.93707275390625,
					-13.93267822265625
				]
			],
			"lastCommittedPoint": [
				354.93707275390625,
				-13.93267822265625
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "90EC6avrhew0j-jc3ornl",
			"type": "arrow",
			"x": -319.8274404887501,
			"y": -195.90997804074127,
			"width": 357.10682891648446,
			"height": 49.9197998046875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1163402874,
			"version": 808,
			"versionNonce": 1648593830,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					71.03730987351571,
					42.80013764767486
				],
				[
					144.99269317429696,
					-5.750338426543891
				],
				[
					207.83961700242196,
					41.957150587127984
				],
				[
					268.9619924907032,
					-7.119662157012641
				],
				[
					321.5861379985157,
					41.717526563690484
				],
				[
					357.10682891648446,
					21.39614594845611
				]
			],
			"lastCommittedPoint": [
				358.35174560546875,
				19.910552978515625
			],
			"startBinding": {
				"elementId": "iDP2XjtmzKXvUyEzZayaa",
				"focus": -0.08685293625039538,
				"gap": 15.276515534294951
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "cl_X46SLissN1UiTcG3q_",
			"type": "line",
			"x": 45.383880615234375,
			"y": -183.13190460205078,
			"width": 58.619140625,
			"height": 14.031097412109375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 820328358,
			"version": 20,
			"versionNonce": 1131945254,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					58.619140625,
					-14.031097412109375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "Ee33TFceFc8xyzxfqWpya",
			"type": "arrow",
			"x": -324.5384826660156,
			"y": -168.25782012939453,
			"width": 81.69622802734375,
			"height": 34.27972412109375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 807530554,
			"version": 82,
			"versionNonce": 1443203174,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					81.69622802734375,
					-34.27972412109375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#e64980",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 632.1617431640625,
		"scrollY": 424.7716979980469,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%