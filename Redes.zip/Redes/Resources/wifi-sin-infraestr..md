---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.26",
	"elements": [
		{
			"type": "line",
			"version": 1394,
			"versionNonce": 1291606172,
			"isDeleted": false,
			"id": "l9CL16qhvfaknyVp9s7Oc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 7.363017771799832,
			"x": -88.38205818028744,
			"y": 29.740390383253192,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 12.60374456340063,
			"height": 22.116146668423887,
			"seed": 746119230,
			"groupIds": [
				"CwrLhR5Z6QWQrwvhCpVFx"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327201400,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.7855019485060288,
					-15.895729446093675
				],
				[
					12.60374456340063,
					-22.116146668423887
				]
			]
		},
		{
			"type": "line",
			"version": 1597,
			"versionNonce": 1376259876,
			"isDeleted": false,
			"id": "34HVRblTcgVXoc9Ct0v2N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 7.363017771799832,
			"x": -96.79160019548392,
			"y": 31.811699416851383,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 32.6883605154316,
			"height": 41.168172318942986,
			"seed": 746119230,
			"groupIds": [
				"CwrLhR5Z6QWQrwvhCpVFx"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327201400,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.037233518116554,
					-29.589156681909287
				],
				[
					32.6883605154316,
					-41.168172318942986
				]
			]
		},
		{
			"type": "line",
			"version": 1514,
			"versionNonce": 1033823516,
			"isDeleted": false,
			"id": "ohIh9HflzoLafWDPbZCAN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 7.363017771799832,
			"x": -85.58509414784332,
			"y": 32.092515634417815,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 6.756973509501292,
			"height": 6.226098298165507,
			"seed": 746119230,
			"groupIds": [
				"CwrLhR5Z6QWQrwvhCpVFx"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327201400,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4211142038794883,
					-4.474937498661298
				],
				[
					6.756973509501292,
					-6.226098298165507
				]
			]
		},
		{
			"type": "line",
			"version": 1132,
			"versionNonce": 1731909758,
			"isDeleted": false,
			"id": "aQ_KAfSVocGLWg4PFTUAI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2361497028496977,
			"x": -174.22765043727387,
			"y": -81.54141753955375,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 12.60374456340063,
			"height": 22.116146668423887,
			"seed": 746119230,
			"groupIds": [
				"b_0oY8lqM8FpfCgQwIZZe"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185027607,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.7855019485060288,
					-15.895729446093675
				],
				[
					12.60374456340063,
					-22.116146668423887
				]
			]
		},
		{
			"type": "line",
			"version": 1335,
			"versionNonce": 1624995426,
			"isDeleted": false,
			"id": "frecRAFBzSsvFQJznouO2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2361497028496977,
			"x": -178.84328655857,
			"y": -66.59719779273563,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 32.6883605154316,
			"height": 41.168172318942986,
			"seed": 746119230,
			"groupIds": [
				"b_0oY8lqM8FpfCgQwIZZe"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185027607,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.037233518116554,
					-29.589156681909287
				],
				[
					32.6883605154316,
					-41.168172318942986
				]
			]
		},
		{
			"type": "line",
			"version": 1252,
			"versionNonce": 1166481598,
			"isDeleted": false,
			"id": "crHy5B67LQBdJgjXmffBz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.2361497028496977,
			"x": -179.81518095815898,
			"y": -95.28027985167381,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 6.756973509501292,
			"height": 6.226098298165507,
			"seed": 746119230,
			"groupIds": [
				"b_0oY8lqM8FpfCgQwIZZe"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185027607,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4211142038794883,
					-4.474937498661298
				],
				[
					6.756973509501292,
					-6.226098298165507
				]
			]
		},
		{
			"type": "line",
			"version": 765,
			"versionNonce": 678953058,
			"isDeleted": false,
			"id": "NZ8BOxRCKJSc1pDQNx9iN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.786865173252627,
			"x": 14.953208814518675,
			"y": -77.95502013635415,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 12.60374456340063,
			"height": 22.116146668423887,
			"seed": 746119230,
			"groupIds": [
				"7z42b2REpXxCA90_XmePs"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185007720,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.7855019485060288,
					-15.895729446093675
				],
				[
					12.60374456340063,
					-22.116146668423887
				]
			]
		},
		{
			"type": "line",
			"version": 968,
			"versionNonce": 995110590,
			"isDeleted": false,
			"id": "n_HIU2BEuUqm0ZDp32mTR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.786865173252627,
			"x": -0.3239982713044647,
			"y": -62.96937105956417,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 32.6883605154316,
			"height": 41.168172318942986,
			"seed": 746119230,
			"groupIds": [
				"7z42b2REpXxCA90_XmePs"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185007720,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.037233518116554,
					-29.589156681909287
				],
				[
					32.6883605154316,
					-41.168172318942986
				]
			]
		},
		{
			"type": "line",
			"version": 885,
			"versionNonce": 69051426,
			"isDeleted": false,
			"id": "BM2cufATacgpAOt3Cmd2_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 4.786865173252627,
			"x": 23.499705755575363,
			"y": -94.52427203437526,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 6.756973509501292,
			"height": 6.226098298165507,
			"seed": 746119230,
			"groupIds": [
				"7z42b2REpXxCA90_XmePs"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682185007720,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4211142038794883,
					-4.474937498661298
				],
				[
					6.756973509501292,
					-6.226098298165507
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1079,
			"versionNonce": 1839826844,
			"isDeleted": false,
			"id": "CNyHEE_bvGiCWh7_bmE8P",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.9453004350638,
			"y": -169.4495607910847,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"7gI_gjOupK3HSnMJoppwA"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327207799,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1304,
			"versionNonce": 1095323684,
			"isDeleted": false,
			"id": "sA3BvmJjz-ApY_Je-pB3n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.3509400835013,
			"y": -130.99773278815502,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"7gI_gjOupK3HSnMJoppwA"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327207800,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1137,
			"versionNonce": 1322136604,
			"isDeleted": false,
			"id": "af4MB0AiFAhgg8icBZj1V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -248.0276978960013,
			"y": -162.08525720221752,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"7gI_gjOupK3HSnMJoppwA"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327207800,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1102,
			"versionNonce": 1936960420,
			"isDeleted": false,
			"id": "mckvsPb1wZJBiMiVX5OOo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -266.75297865772006,
			"y": -122.54653039557688,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"7gI_gjOupK3HSnMJoppwA"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327207800,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1072,
			"versionNonce": 1873367196,
			"isDeleted": false,
			"id": "tAjtAkYGtIN48xVrYRn9Y",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -201.9420045366263,
			"y": -123.96718469245188,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"7gI_gjOupK3HSnMJoppwA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "A0yYah-aOfpTFb5kirRt5",
					"type": "arrow"
				}
			],
			"updated": 1682327207800,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1201,
			"versionNonce": 568438820,
			"isDeleted": false,
			"id": "IieTg0HtqbQKwqPoKZiSr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -108.2376916457089,
			"y": 50.95149522098063,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"yCzjOKeexLfdQrgnEDkMk"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327252595,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1422,
			"versionNonce": 711709724,
			"isDeleted": false,
			"id": "dOOC7d_G3Tdw6XbmKxJLX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -127.6433312941464,
			"y": 89.40332322391032,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"yCzjOKeexLfdQrgnEDkMk"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327252595,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1259,
			"versionNonce": 1644170148,
			"isDeleted": false,
			"id": "Ick-UoLf7_RLqGO5SRP6j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -99.3200891066464,
			"y": 58.31579880984782,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"yCzjOKeexLfdQrgnEDkMk"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327252595,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1222,
			"versionNonce": 1184034972,
			"isDeleted": false,
			"id": "gXAbTL6glYen-VVQ83-KG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -118.04536986836516,
			"y": 97.85452561648844,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"yCzjOKeexLfdQrgnEDkMk"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327252595,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1191,
			"versionNonce": 1422325540,
			"isDeleted": false,
			"id": "C9fktC2SJWybXk13ckFam",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -53.23439574727141,
			"y": 96.43387131961344,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"yCzjOKeexLfdQrgnEDkMk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327252595,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1123,
			"versionNonce": 1091785186,
			"isDeleted": false,
			"id": "gCPr07ia_0OVnHBLVt-46",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 61.7614331856235,
			"y": -168.4588974268293,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"2ma_G93GKX0TeoX9Ameuz"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682184893060,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1348,
			"versionNonce": 963531618,
			"isDeleted": false,
			"id": "PyD4kWKB4kB7f_aVcgt62",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 42.355793537186,
			"y": -130.00706942389962,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"2ma_G93GKX0TeoX9Ameuz"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682185088168,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1181,
			"versionNonce": 1616037282,
			"isDeleted": false,
			"id": "0p-41OYqi_jm6ACb5WrDz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 70.679035724686,
			"y": -161.09459383796212,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"2ma_G93GKX0TeoX9Ameuz"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682184893060,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1148,
			"versionNonce": 392125822,
			"isDeleted": false,
			"id": "fEeQPseUdZbt5nr9M8b7R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 51.95375496296725,
			"y": -121.5558670313215,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"2ma_G93GKX0TeoX9Ameuz"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "qf3KH-X9jkl8BOY3W9CkB",
					"type": "arrow"
				}
			],
			"updated": 1682184893060,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1115,
			"versionNonce": 384680290,
			"isDeleted": false,
			"id": "Tff3T4cBu2Cw7aclCIDpI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 116.764729084061,
			"y": -122.9765213281965,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"2ma_G93GKX0TeoX9Ameuz"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682184893060,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 808,
			"versionNonce": 960063260,
			"isDeleted": false,
			"id": "A0yYah-aOfpTFb5kirRt5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.2200073608397961,
			"x": -224.44276556087394,
			"y": -50.372345906944005,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 64.84275573808529,
			"height": 64.1121831568701,
			"seed": 1737277090,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682327219690,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					64.84275573808529,
					33.382590860965045
				],
				[
					33.08809307435628,
					46.07615970603535
				],
				[
					59.266813467632254,
					64.1121831568701
				]
			]
		},
		{
			"type": "arrow",
			"version": 682,
			"versionNonce": 866746908,
			"isDeleted": false,
			"id": "qf3KH-X9jkl8BOY3W9CkB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 6.101936429797209,
			"x": 70.5630834295354,
			"y": -44.07647308170882,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 62.46667848009596,
			"height": 55.34335805100306,
			"seed": 1965325986,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682327234460,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-48.95685483988575,
					26.08890967691644
				],
				[
					-19.880030765137477,
					29.048686999249878
				],
				[
					-44.46925071574339,
					45.60295938467932
				],
				[
					-62.46667848009596,
					55.34335805100306
				]
			]
		},
		{
			"type": "arrow",
			"version": 701,
			"versionNonce": 160080284,
			"isDeleted": false,
			"id": "2pCr1AnIWCpYc98879eI-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0.380631620376918,
			"x": -116.84624321809189,
			"y": -131.10581530288934,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 76.07220301397913,
			"height": 43.49675270061681,
			"seed": 1702663074,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682327244984,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					11.210584211567259
				],
				[
					43.233699078319226,
					-6.057326081775074
				],
				[
					33.91993418210384,
					14.793946003335762
				],
				[
					60.97940290652097,
					-9.027924060209642
				],
				[
					76.07220301397913,
					-28.702806697281048
				]
			]
		},
		{
			"type": "line",
			"version": 597,
			"versionNonce": 1321240476,
			"isDeleted": true,
			"id": "bhw-5zfeu3nWWyCjJxGtk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.368708350049822,
			"y": 66.91505544498733,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 12.60374456340063,
			"height": 22.116146668423887,
			"seed": 746119230,
			"groupIds": [
				"PxZHuRIdsaO0HqVWddNvQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.7855019485060288,
					-15.895729446093675
				],
				[
					12.60374456340063,
					-22.116146668423887
				]
			]
		},
		{
			"type": "line",
			"version": 800,
			"versionNonce": 1629638692,
			"isDeleted": true,
			"id": "EG3AOs_LyNre8fqqObu6s",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 12.561573024761165,
			"y": 71.55237351051062,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 32.6883605154316,
			"height": 41.168172318942986,
			"seed": 746119230,
			"groupIds": [
				"PxZHuRIdsaO0HqVWddNvQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.037233518116554,
					-29.589156681909287
				],
				[
					32.6883605154316,
					-41.168172318942986
				]
			]
		},
		{
			"type": "line",
			"version": 717,
			"versionNonce": 1963275292,
			"isDeleted": true,
			"id": "WI3iv0KEXiYzFS_mSAMyz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 40.31214848102759,
			"y": 63.93708619102321,
			"strokeColor": "#ae9642",
			"backgroundColor": "transparent",
			"width": 6.756973509501292,
			"height": 6.226098298165507,
			"seed": 746119230,
			"groupIds": [
				"PxZHuRIdsaO0HqVWddNvQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4211142038794883,
					-4.474937498661298
				],
				[
					6.756973509501292,
					-6.226098298165507
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1216,
			"versionNonce": 808233892,
			"isDeleted": true,
			"id": "FbKrja3Xd84Et6OOsvXe8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 60.122265114374045,
			"y": 67.33311894244764,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"RVgcOVa0R918frRtlOHfU"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1439,
			"versionNonce": 922767516,
			"isDeleted": true,
			"id": "c9EvhuzcftboRJ18NKa2T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 40.716625465936545,
			"y": 105.78494694537733,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"RVgcOVa0R918frRtlOHfU"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1276,
			"versionNonce": 1952421668,
			"isDeleted": true,
			"id": "EQhUtFJZ0x9_3KnIfMMbd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 69.03986765343654,
			"y": 74.69742253131483,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"RVgcOVa0R918frRtlOHfU"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1239,
			"versionNonce": 878959900,
			"isDeleted": true,
			"id": "okABMUFaDCMSMGJ-ubXHZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 50.314586891717795,
			"y": 114.23614933795545,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"RVgcOVa0R918frRtlOHfU"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1208,
			"versionNonce": 438899364,
			"isDeleted": true,
			"id": "KeZQ0SP4h7npdn2D-vqmt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 115.12556101281154,
			"y": 112.81549504108045,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"RVgcOVa0R918frRtlOHfU"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 130,
			"versionNonce": 769734300,
			"isDeleted": true,
			"id": "Wdb1KQV2uFMk3cu0eFUYf",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -134.6809584094632,
			"y": -57.804954528808594,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 122,
			"height": 76,
			"seed": 992813630,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "CPWODmDY"
				}
			],
			"updated": 1682327176055,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 9,
			"versionNonce": 82317604,
			"isDeleted": true,
			"id": "CPWODmDY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -92.11895432010772,
			"y": -37.304954528808594,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 36.87599182128906,
			"height": 35,
			"seed": 344873150,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682327176055,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "AP",
			"rawText": "AP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Wdb1KQV2uFMk3cu0eFUYf",
			"originalText": "AP",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "ellipse",
			"version": 197,
			"versionNonce": 932334756,
			"isDeleted": true,
			"id": "izx4H4FeoPylliE4l9HKA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -361.4883991234223,
			"y": -263.04402812691114,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 586.7881569661918,
			"height": 500.8715191000642,
			"seed": 446063330,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682327179606,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 672,
			"versionNonce": 1185012124,
			"isDeleted": true,
			"id": "zo7CyH1A_T34WJ0_rjv_A",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 1.6526572671338497,
			"x": 9.579886840617892,
			"y": 51.98311401851703,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 32.94237988160979,
			"height": 34.72963733478301,
			"seed": 1965325986,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682327182482,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-25.81784959893814,
					16.371582850180832
				],
				[
					-10.483917849608744,
					18.22893297522429
				],
				[
					-23.45127011347885,
					28.617241464877964
				],
				[
					-32.94237988160979,
					34.72963733478301
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#fab005",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 474.6502839719796,
		"scrollY": 323.24675537753427,
		"zoom": {
			"value": 1.55
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%