---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
DIFS ^tw6uFTjs

Trama de datos ^vXqL4x5Z

SIFS ^pbh4IlOB

ACK ^519a8Luc

DIFS ^tpYRHI1B

Trama de datos ^6GvhxQaI

Contienda
(la estación 3 debe competir 
por el control de acceso al medio)  ^jBtoyJWX

Time ^wPw7JOKq

Time ^hkNqV1Bg

Time ^SlsWtPOT

La estación 3 quiere transmitir, pero
debe esperar a que el medio quede libre ^psJ26Aua

Estación 1
(Emisor) ^7xqQdoPd

Estación 2
(Receptor) ^CNUjBK2t

Estación 3 ^MRLy9kXU

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.26",
	"elements": [
		{
			"id": "_nJayCwtJc7zIYijGeexE",
			"type": "arrow",
			"x": -487.4773864746094,
			"y": -261.56319427490234,
			"width": 1065.4146118164062,
			"height": 2.6744384765625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 512862076,
			"version": 204,
			"versionNonce": 1873227972,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1065.4146118164062,
					-2.6744384765625
				]
			],
			"lastCommittedPoint": [
				819.4828491210938,
				-1.3907012939453125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "xdRpx6EnMNBSFBewJx7Hg",
			"type": "arrow",
			"x": -487.59368896484375,
			"y": -124.5319595336914,
			"width": 1061.7645568847656,
			"height": 3.02960205078125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 89981636,
			"version": 207,
			"versionNonce": 640953724,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1061.7645568847656,
					-3.02960205078125
				]
			],
			"lastCommittedPoint": [
				813.1712341308594,
				-2.0154571533203125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "9DUj1ERXTGkN5xYGN6WsJ",
			"type": "arrow",
			"x": -486.8960876464844,
			"y": 7.914756774902344,
			"width": 1052.9236755371094,
			"height": 0.6290435791015625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 796617924,
			"version": 286,
			"versionNonce": 680294468,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1052.9236755371094,
					0.6290435791015625
				]
			],
			"lastCommittedPoint": [
				806.0336303710938,
				0.4492950439453125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "1K0tini2Ozblfa270p8uH",
			"type": "line",
			"x": -451.8267517089844,
			"y": -342.4966812133789,
			"width": 0.1497802734375,
			"height": 81.44804382324219,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1069596796,
			"version": 47,
			"versionNonce": 1321803260,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.1497802734375,
					81.44804382324219
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "_UMydlDZn7aqfWLtCI1J1",
			"type": "line",
			"x": -296.2949523925781,
			"y": -342.17147064208984,
			"width": 1.13824462890625,
			"height": 80.53231811523438,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 974699388,
			"version": 81,
			"versionNonce": 878497732,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.13824462890625,
					80.53231811523438
				]
			],
			"lastCommittedPoint": [
				1.13824462890625,
				80.53231811523438
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "bOSnZInE6iCAqefzNfNer",
			"type": "arrow",
			"x": -449.8377380371094,
			"y": -323.80347442626953,
			"width": 155.20660400390625,
			"height": 1.0997314453125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1973079804,
			"version": 63,
			"versionNonce": 1751907964,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "tw6uFTjs"
				}
			],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					155.20660400390625,
					1.0997314453125
				]
			],
			"lastCommittedPoint": [
				155.20660400390625,
				1.0997314453125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "tw6uFTjs",
			"type": "text",
			"x": -397.3044204711914,
			"y": -335.7536087036133,
			"width": 50.13996887207031,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1199713788,
			"version": 10,
			"versionNonce": 590755652,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"text": "DIFS",
			"rawText": "DIFS",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "bOSnZInE6iCAqefzNfNer",
			"originalText": "DIFS",
			"lineHeight": 1.25
		},
		{
			"id": "f1ikYGCPMPgu9hg9qJAdt",
			"type": "rectangle",
			"x": -296.1454772949219,
			"y": -305.8350296020508,
			"width": 181,
			"height": 45,
			"angle": 0,
			"strokeColor": "#2188e2",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 982302148,
			"version": 386,
			"versionNonce": 2078199548,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "vXqL4x5Z"
				}
			],
			"updated": 1682370406471,
			"link": null,
			"locked": false
		},
		{
			"id": "vXqL4x5Z",
			"type": "text",
			"x": -287.79541778564453,
			"y": -295.8350296020508,
			"width": 164.2998809814453,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 24567620,
			"version": 159,
			"versionNonce": 1366732484,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"text": "Trama de datos",
			"rawText": "Trama de datos",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "f1ikYGCPMPgu9hg9qJAdt",
			"originalText": "Trama de datos",
			"lineHeight": 1.25
		},
		{
			"id": "eNHxt-zil7kFWpEPv5NgC",
			"type": "line",
			"x": -111.90982055664062,
			"y": -260.45047760009766,
			"width": 0.380859375,
			"height": 71.83294677734375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 973689284,
			"version": 112,
			"versionNonce": 698584956,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.380859375,
					71.83294677734375
				]
			],
			"lastCommittedPoint": [
				0.380859375,
				40.85240173339844
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 305,
			"versionNonce": 1606170180,
			"isDeleted": false,
			"id": "lDVDeXS45Br-WxxF3YZEl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.237864407124,
			"y": -232.91382472583555,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.4578857421875,
			"height": 58.25543212890625,
			"seed": 973689284,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4578857421875,
					58.25543212890625
				]
			]
		},
		{
			"id": "sOUVsX58OWG4npOyD7q4K",
			"type": "arrow",
			"x": -112.14041137695312,
			"y": -204.47464752197266,
			"width": 85.757080078125,
			"height": 1.22808837890625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 979013828,
			"version": 243,
			"versionNonce": 838615036,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "pbh4IlOB"
				}
			],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					85.757080078125,
					-1.22808837890625
				]
			],
			"lastCommittedPoint": [
				59.97564697265625,
				-1.10400390625
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "pbh4IlOB",
			"type": "text",
			"x": -92.61185455322266,
			"y": -217.58869171142578,
			"width": 46.69996643066406,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1300262468,
			"version": 57,
			"versionNonce": 1713940604,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370517900,
			"link": null,
			"locked": false,
			"text": "SIFS",
			"rawText": "SIFS",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "sOUVsX58OWG4npOyD7q4K",
			"originalText": "SIFS",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 475,
			"versionNonce": 2095767676,
			"isDeleted": false,
			"id": "amKryV0V2thrVm7rVfNab",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -24.906829833984375,
			"y": -172.8027114868164,
			"strokeColor": "#2188e2",
			"backgroundColor": "transparent",
			"width": 60,
			"height": 47,
			"seed": 982302148,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "519a8Luc"
				}
			],
			"updated": 1682370406471,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 251,
			"versionNonce": 1141798212,
			"isDeleted": false,
			"id": "519a8Luc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.036819458007812,
			"y": -161.8027114868164,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 38.259979248046875,
			"height": 25,
			"seed": 24567620,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ACK",
			"rawText": "ACK",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "amKryV0V2thrVm7rVfNab",
			"originalText": "ACK",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 151,
			"versionNonce": 573665532,
			"isDeleted": false,
			"id": "dWFtZTUNvCM-juDiewl0f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 36.1314094917547,
			"y": -124.03294525352771,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.1497802734375,
			"height": 81.44804382324219,
			"seed": 1069596796,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.1497802734375,
					81.44804382324219
				]
			]
		},
		{
			"type": "line",
			"version": 333,
			"versionNonce": 1754737860,
			"isDeleted": false,
			"id": "5duY4Ic5doRD6dnG_k8Ul",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 196.5327766792547,
			"y": -101.17407379356678,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.54046630859375,
			"height": 165.279541015625,
			"seed": 974699388,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370406471,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.54046630859375,
					165.279541015625
				]
			]
		},
		{
			"type": "arrow",
			"version": 220,
			"versionNonce": 1901195644,
			"isDeleted": false,
			"id": "RZylNH25wtCyaWAG98Egy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 39.7079475776922,
			"y": -62.056809999621464,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 155.20660400390625,
			"height": 1.0997314453125,
			"seed": 1973079804,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "tpYRHI1B"
				}
			],
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					155.20660400390625,
					1.0997314453125
				]
			]
		},
		{
			"type": "text",
			"version": 169,
			"versionNonce": 1819356484,
			"isDeleted": false,
			"id": "tpYRHI1B",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 92.24126514361018,
			"y": -74.00694427696521,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.13996887207031,
			"height": 25,
			"seed": 1199713788,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370517901,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DIFS",
			"rawText": "DIFS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "RZylNH25wtCyaWAG98Egy",
			"originalText": "DIFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 566,
			"versionNonce": 2039374332,
			"isDeleted": false,
			"id": "CRtkPLRCkMriydK2S-JOb",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 258.0227966308594,
			"y": -37.424888610839844,
			"strokeColor": "#2188e2",
			"backgroundColor": "transparent",
			"width": 181,
			"height": 45,
			"seed": 982302148,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6GvhxQaI"
				}
			],
			"updated": 1682370406472,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 339,
			"versionNonce": 1987955652,
			"isDeleted": false,
			"id": "6GvhxQaI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 266.3728561401367,
			"y": -27.424888610839844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.2998809814453,
			"height": 25,
			"seed": 24567620,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Trama de datos",
			"rawText": "Trama de datos",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "CRtkPLRCkMriydK2S-JOb",
			"originalText": "Trama de datos",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 517,
			"versionNonce": 300466812,
			"isDeleted": false,
			"id": "yu4OKF0Cs47naZwWH2VtO",
			"fillStyle": "cross-hatch",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 196.72982788085938,
			"y": -39.378746032714844,
			"strokeColor": "#2188e2",
			"backgroundColor": "#228be6",
			"width": 60,
			"height": 47,
			"seed": 982302148,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370406472,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 363,
			"versionNonce": 1876407108,
			"isDeleted": false,
			"id": "OfQQ2pJ7X3dyQZoy6ldoa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 256.85491062955464,
			"y": 7.539811443598012,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.4578857421875,
			"height": 58.25543212890625,
			"seed": 973689284,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4578857421875,
					58.25543212890625
				]
			]
		},
		{
			"id": "6XfsgFCWzSIQs726Lz2II",
			"type": "arrow",
			"x": 158.02108764648438,
			"y": 38.43415069580078,
			"width": 39.833984375,
			"height": 1.1082763671875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1292030588,
			"version": 76,
			"versionNonce": 1629688572,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					39.833984375,
					1.1082763671875
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "HdFkcm0cXiBzFEnHWlVDT",
			"type": "arrow",
			"x": 294.7121276855469,
			"y": 38.78076934814453,
			"width": 36.44921875,
			"height": 0.522064208984375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 243009732,
			"version": 94,
			"versionNonce": 76065476,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-36.44921875,
					0.522064208984375
				]
			],
			"lastCommittedPoint": [
				-36.44921875,
				0.522064208984375
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "jBtoyJWX",
			"type": "text",
			"x": 56.743865966796875,
			"y": 75.7049331665039,
			"width": 346.8597412109375,
			"height": 75,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1176399100,
			"version": 168,
			"versionNonce": 1707037564,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"text": "Contienda\n(la estación 3 debe competir \npor el control de acceso al medio) ",
			"rawText": "Contienda\n(la estación 3 debe competir \npor el control de acceso al medio) ",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 67,
			"containerId": null,
			"originalText": "Contienda\n(la estación 3 debe competir \npor el control de acceso al medio) ",
			"lineHeight": 1.25
		},
		{
			"id": "wPw7JOKq",
			"type": "text",
			"x": 594.5645980834961,
			"y": -145.93819427490234,
			"width": 61.68397521972656,
			"height": 35,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 556130812,
			"version": 49,
			"versionNonce": 1462678084,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"text": "Time",
			"rawText": "Time",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 24,
			"containerId": null,
			"originalText": "Time",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 64,
			"versionNonce": 2113897468,
			"isDeleted": false,
			"id": "hkNqV1Bg",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 587.6867904663086,
			"y": -10.796775817871094,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 61.68397521972656,
			"height": 35,
			"seed": 556130812,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Time",
			"rawText": "Time",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Time",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 50,
			"versionNonce": 111659460,
			"isDeleted": false,
			"id": "SlsWtPOT",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 593.0080795288086,
			"y": -282.6700668334961,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 61.68397521972656,
			"height": 35,
			"seed": 556130812,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Time",
			"rawText": "Time",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Time",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"id": "psJ26Aua",
			"type": "text",
			"x": -291.98052978515625,
			"y": -37.943504333496094,
			"width": 315.71185302734375,
			"height": 40,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 271389180,
			"version": 189,
			"versionNonce": 1877320828,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"text": "La estación 3 quiere transmitir, pero\ndebe esperar a que el medio quede libre",
			"rawText": "La estación 3 quiere transmitir, pero\ndebe esperar a que el medio quede libre",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 34,
			"containerId": null,
			"originalText": "La estación 3 quiere transmitir, pero\ndebe esperar a que el medio quede libre",
			"lineHeight": 1.25
		},
		{
			"id": "EG9uPwc0Ph4VD7G6QB055",
			"type": "line",
			"x": -291.4509582519531,
			"y": -45.747840881347656,
			"width": 346.207763671875,
			"height": 1.8143310546875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1962164732,
			"version": 91,
			"versionNonce": 638710084,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370406472,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					346.207763671875,
					1.8143310546875
				]
			],
			"lastCommittedPoint": [
				346.207763671875,
				1.8143310546875
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "7xqQdoPd",
			"type": "text",
			"x": -670.2582402343428,
			"y": -294.8522546223702,
			"width": 138.93594360351562,
			"height": 70,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 795587964,
			"version": 80,
			"versionNonce": 2039733316,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370436113,
			"link": null,
			"locked": false,
			"text": "Estación 1\n(Emisor)",
			"rawText": "Estación 1\n(Emisor)",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "Estación 1\n(Emisor)",
			"lineHeight": 1.25
		},
		{
			"id": "CNUjBK2t",
			"type": "text",
			"x": -684.3260531198803,
			"y": -162.03090679415075,
			"width": 151.283935546875,
			"height": 70,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 2136603132,
			"version": 78,
			"versionNonce": 289222268,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682370470289,
			"link": null,
			"locked": false,
			"text": "Estación 2\n(Receptor)",
			"rawText": "Estación 2\n(Receptor)",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 59,
			"containerId": null,
			"originalText": "Estación 2\n(Receptor)",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 175,
			"versionNonce": 49081924,
			"isDeleted": false,
			"id": "MRLy9kXU",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -685.1720793208068,
			"y": -9.996460791856691,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 150.4159393310547,
			"height": 35,
			"seed": 2136603132,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370493090,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Estación 3",
			"rawText": "Estación 3",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Estación 3",
			"lineHeight": 1.25,
			"baseline": 24
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#228be6",
		"currentItemFillStyle": "cross-hatch",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "triangle",
		"scrollX": 603.1638029128263,
		"scrollY": 467.1915517218373,
		"zoom": {
			"value": 0.9450732994079585
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%