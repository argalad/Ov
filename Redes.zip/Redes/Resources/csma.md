---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
¿Trama lista
para transmitir? ^ETNcUsHQ

Escuchar canal ^pXDnfHn7

¿Canal libre? ^bfiELyJj

Transmitir trama ^GXlRf59D

Esperar ACK ^vj3weSqO

¿ACK recibido? ^uHtgHj3D

¿Time-out? ^y5Kxmrpl

Esperar intervalo
aleatorio (backoff) ^5HsciI3X

Iniciar
retransmisión ^o1JeKisq

Fin ^6RZGabkV

Sí ^QnRrdCzV

Sí ^rHqdDtXW

Sí ^EG1cQD2A

Sí ^1f79Xjkj

Colisión ^WDXLxPSH

No ^QR49gAlC

No ^JlAKzfte

No ^BRrel3vO

No ^rGmKUubl

Para evitar que los computadores
involucrados retransmitan
inmediatamente y se produzca otra colisión ^3OctvZjC

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.26",
	"elements": [
		{
			"type": "arrow",
			"version": 736,
			"versionNonce": 2021251399,
			"isDeleted": false,
			"id": "oUJ3GI-81maTE5qs8-dtr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 55.38884434252691,
			"y": 649.9987043504696,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 58.861749473957175,
			"height": 344.2791401324491,
			"seed": 1166500775,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841398347,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "uYx64pI5bIp6FIzc0cEVO",
				"focus": 1.5379370866393398,
				"gap": 1
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					54.64457537019349,
					-36.72136383562088
				],
				[
					58.861749473957175,
					-308.4054924024648
				],
				[
					8.274953018270958,
					-344.2791401324491
				]
			]
		},
		{
			"type": "diamond",
			"version": 252,
			"versionNonce": 819092775,
			"isDeleted": false,
			"id": "qKi3kBSUPdHFfd12XVhWf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.50778198242188,
			"y": -334.5926539617458,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"HqumOebvy25DUTzQrKJYk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "D4gdQGBSg_Q70gKNeAlp1",
					"type": "arrow"
				}
			],
			"updated": 1681841343617,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 158,
			"versionNonce": 1105898697,
			"isDeleted": false,
			"id": "ETNcUsHQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -154.33370971679688,
			"y": -303.9004440307617,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 159.21986389160156,
			"height": 50,
			"seed": 380734185,
			"groupIds": [
				"HqumOebvy25DUTzQrKJYk"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Trama lista\npara transmitir?",
			"rawText": "¿Trama lista\npara transmitir?",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Trama lista\npara transmitir?",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 443,
			"versionNonce": 782575495,
			"isDeleted": false,
			"id": "1jL5K4vhNs5aqhrflTGGK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.98189963927769,
			"y": -149.82598322211956,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"WUXCosQUNwO_g71HzACpJ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "CrsScDhWRQ4GAaMmez04d",
					"type": "arrow"
				},
				{
					"id": "WcJ7wkvFRxpuWeCjV3O86",
					"type": "arrow"
				}
			],
			"updated": 1681841456738,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 431,
			"versionNonce": 325856169,
			"isDeleted": false,
			"id": "pXDnfHn7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -147.65515352433,
			"y": -138.33051566314035,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 148.91990661621094,
			"height": 25,
			"seed": 551045735,
			"groupIds": [
				"WUXCosQUNwO_g71HzACpJ"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "XOSVhUemnyuByXHPsB5XD",
					"type": "arrow"
				},
				{
					"id": "z5Hbr9qoZJXgueDIppLq9",
					"type": "arrow"
				}
			],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Escuchar canal",
			"rawText": "Escuchar canal",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Escuchar canal",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "diamond",
			"version": 456,
			"versionNonce": 1953866404,
			"isDeleted": false,
			"id": "F1nakk76YYM-_QMq3yH0E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.54647318127502,
			"y": -32.89997271830214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"pAFWHjtJollszQVnbMBRh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "z5Hbr9qoZJXgueDIppLq9",
					"type": "arrow"
				},
				{
					"id": "CrsScDhWRQ4GAaMmez04d",
					"type": "arrow"
				}
			],
			"updated": 1682334099228,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 410,
			"versionNonce": 1004554660,
			"isDeleted": false,
			"id": "bfiELyJj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.8653310011089,
			"y": 13.733452462792002,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 124.03990173339844,
			"height": 25,
			"seed": 380734185,
			"groupIds": [
				"pAFWHjtJollszQVnbMBRh"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682334099229,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Canal libre?",
			"rawText": "¿Canal libre?",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Canal libre?",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 487,
			"versionNonce": 1688599175,
			"isDeleted": false,
			"id": "_hqEUZYmpfq0eNzzAGf11",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -222.39512340296335,
			"y": 156.95738640979715,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"7uiJvFkdsEWFqheLshQ3Y"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "qs_UpiyS9ml3ZmoBtKmYq",
					"type": "arrow"
				}
			],
			"updated": 1681841343617,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 491,
			"versionNonce": 481432937,
			"isDeleted": false,
			"id": "GXlRf59D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -161.23489071530275,
			"y": 169.30266987920936,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 168.7798614501953,
			"height": 25,
			"seed": 551045735,
			"groupIds": [
				"7uiJvFkdsEWFqheLshQ3Y"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "xHi0FeFABCiXFB_6WPgOb",
					"type": "arrow"
				}
			],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Transmitir trama",
			"rawText": "Transmitir trama",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Transmitir trama",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 508,
			"versionNonce": 1201701545,
			"isDeleted": false,
			"id": "Eo1YpSY2b9HKZgH5_kksN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -222.10551530903467,
			"y": 279.3998272110461,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"4u08gYwhluWLS0HyDnkV_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "xHi0FeFABCiXFB_6WPgOb",
					"type": "arrow"
				},
				{
					"id": "1zcVLMag59SGE7O1syaGj",
					"type": "arrow"
				}
			],
			"updated": 1681841398347,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 599,
			"versionNonce": 1048412233,
			"isDeleted": false,
			"id": "vj3weSqO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.92112770637442,
			"y": 291.5032824145282,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 123.93991088867188,
			"height": 25,
			"seed": 551045735,
			"groupIds": [
				"4u08gYwhluWLS0HyDnkV_"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Esperar ACK",
			"rawText": "Esperar ACK",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Esperar ACK",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "diamond",
			"version": 527,
			"versionNonce": 307250375,
			"isDeleted": false,
			"id": "kRpAkLhAIivMPuVLZHx4V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -213.09457004087733,
			"y": 401.7180046977046,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"tO2RuWWOyV9nWOPllCMdJ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "hBO67_ImbvtbwsUly_CCV",
					"type": "arrow"
				},
				{
					"id": "jqJL2WmoUYSKf4w8iu7HK",
					"type": "arrow"
				}
			],
			"updated": 1681841343617,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 528,
			"versionNonce": 760778537,
			"isDeleted": false,
			"id": "uHtgHj3D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -146.08033978987805,
			"y": 448.45811317672377,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 139.75987243652344,
			"height": 25,
			"seed": 380734185,
			"groupIds": [
				"tO2RuWWOyV9nWOPllCMdJ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿ACK recibido?",
			"rawText": "¿ACK recibido?",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿ACK recibido?",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "diamond",
			"version": 571,
			"versionNonce": 330817961,
			"isDeleted": false,
			"id": "uYx64pI5bIp6FIzc0cEVO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.80681661826486,
			"y": 588.0336428195088,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"yRNl774Rf-GhkeF_WNF4a"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "hBO67_ImbvtbwsUly_CCV",
					"type": "arrow"
				},
				{
					"id": "oUJ3GI-81maTE5qs8-dtr",
					"type": "arrow"
				}
			],
			"updated": 1681841370493,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 558,
			"versionNonce": 1873723913,
			"isDeleted": false,
			"id": "y5Kxmrpl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -128.10838043825134,
			"y": 636.0042452054124,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 106.55987548828125,
			"height": 25,
			"seed": 380734185,
			"groupIds": [
				"yRNl774Rf-GhkeF_WNF4a"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Time-out?",
			"rawText": "¿Time-out?",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Time-out?",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 580,
			"versionNonce": 325286441,
			"isDeleted": false,
			"id": "zDV--T1PVtdGhiSX67DGd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -221.7332706854051,
			"y": 773.3644806141407,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"Mj5R__xwoSLP9S7Ksntpm"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "eIjlICqlApt8UZiSYhQgB",
					"type": "arrow"
				},
				{
					"id": "48sCmMBA4h-zydeylqyiV",
					"type": "arrow"
				},
				{
					"id": "46qJf2p1TgWFWqdtDunSW",
					"type": "arrow"
				}
			],
			"updated": 1681841931554,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 725,
			"versionNonce": 846960873,
			"isDeleted": false,
			"id": "5HsciI3X",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -168.64756192352576,
			"y": 776.7443167847215,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 188.17982482910156,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"Mj5R__xwoSLP9S7Ksntpm"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343617,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Esperar intervalo\naleatorio (backoff)",
			"rawText": "Esperar intervalo\naleatorio (backoff)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Esperar intervalo\naleatorio (backoff)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 570,
			"versionNonce": 119360615,
			"isDeleted": false,
			"id": "3nq7wru2VHarqINCYrjmE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.78190162935118,
			"y": 896.1091544362322,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"utQH0TMZaWwaZ95AKV57g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "48sCmMBA4h-zydeylqyiV",
					"type": "arrow"
				},
				{
					"id": "WcJ7wkvFRxpuWeCjV3O86",
					"type": "arrow"
				}
			],
			"updated": 1681841456738,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 826,
			"versionNonce": 2001376201,
			"isDeleted": false,
			"id": "o1JeKisq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.38029966507304,
			"y": 897.0364850264475,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 125.67987060546875,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"utQH0TMZaWwaZ95AKV57g"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Iniciar\nretransmisión",
			"rawText": "Iniciar\nretransmisión",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Iniciar\nretransmisión",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 175,
			"versionNonce": 1731209543,
			"isDeleted": false,
			"id": "XOSVhUemnyuByXHPsB5XD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.08317398161722,
			"y": -219.36771792456622,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "pXDnfHn7",
				"focus": -0.05052094390565168,
				"gap": 14.729620081654076
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 350,
			"versionNonce": 1383181860,
			"isDeleted": false,
			"id": "z5Hbr9qoZJXgueDIppLq9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.52467463642571,
			"y": -98.88850955485125,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3190789181420541,
			"height": 65.1250768064867,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682334099228,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "pXDnfHn7",
				"focus": 0.010521480447920666,
				"gap": 14.442006108289121
			},
			"endBinding": {
				"elementId": "F1nakk76YYM-_QMq3yH0E",
				"focus": -0.012662666893885241,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3190789181420541,
					65.1250768064867
				]
			]
		},
		{
			"type": "arrow",
			"version": 488,
			"versionNonce": 1175021671,
			"isDeleted": false,
			"id": "qs_UpiyS9ml3ZmoBtKmYq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -76.03100702603982,
			"y": 83.16982872100127,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8981359457307292,
			"height": 68.933442260877,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "_hqEUZYmpfq0eNzzAGf11",
				"focus": -0.00584789685877575,
				"gap": 4.8541154279188845
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.8981359457307292,
					68.933442260877
				]
			]
		},
		{
			"type": "arrow",
			"version": 233,
			"versionNonce": 132969865,
			"isDeleted": false,
			"id": "xHi0FeFABCiXFB_6WPgOb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.39555168548131,
			"y": 209.0207759121493,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "GXlRf59D",
				"focus": -0.02360965982138527,
				"gap": 14.718106032939943
			},
			"endBinding": {
				"elementId": "Eo1YpSY2b9HKZgH5_kksN",
				"focus": -0.007868387603566137,
				"gap": 4.07146911912497
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 305,
			"versionNonce": 1907213191,
			"isDeleted": false,
			"id": "1zcVLMag59SGE7O1syaGj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.2488004888468,
			"y": 332.95437739967656,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 69.50112014140936,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Eo1YpSY2b9HKZgH5_kksN",
				"focus": -0.01002905550284796,
				"gap": 1.8118744073804578
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					69.50112014140936
				]
			]
		},
		{
			"type": "arrow",
			"version": 342,
			"versionNonce": 463953001,
			"isDeleted": false,
			"id": "hBO67_ImbvtbwsUly_CCV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.41530296148646,
			"y": 520.7998518068015,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.9953043366207623,
			"height": 66.18684445764347,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "kRpAkLhAIivMPuVLZHx4V",
				"focus": -0.009887173385483875,
				"gap": 1
			},
			"endBinding": {
				"elementId": "uYx64pI5bIp6FIzc0cEVO",
				"focus": -0.012637057667606776,
				"gap": 1.2897552808756743
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.9953043366207623,
					66.18684445764347
				]
			]
		},
		{
			"type": "arrow",
			"version": 254,
			"versionNonce": 1515829927,
			"isDeleted": false,
			"id": "eIjlICqlApt8UZiSYhQgB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -75.47299259850993,
			"y": 703.6665438981242,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "zDV--T1PVtdGhiSX67DGd",
				"focus": -0.010845306049244127,
				"gap": 3.390354536244672
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 248,
			"versionNonce": 1563551561,
			"isDeleted": false,
			"id": "48sCmMBA4h-zydeylqyiV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.03690351555005,
			"y": 825.5637559377124,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zDV--T1PVtdGhiSX67DGd",
				"focus": -0.015749603935797257,
				"gap": 1
			},
			"endBinding": {
				"elementId": "3nq7wru2VHarqINCYrjmE",
				"focus": -0.0076520611924527256,
				"gap": 4.2378163187480595
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 1369,
			"versionNonce": 1090397988,
			"isDeleted": false,
			"id": "jqJL2WmoUYSKf4w8iu7HK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 61.9219126682456,
			"y": 459.657019370232,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 84.30644408845794,
			"height": 0.6009571984805575,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682334097400,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "kRpAkLhAIivMPuVLZHx4V",
				"gap": 1.2857142857142854,
				"focus": -0.0029261704996016895
			},
			"endBinding": {
				"elementId": "XulUJOZXGhi4yKvrHYk5L",
				"gap": 8.81296218783273,
				"focus": 0.04950890822991109
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					84.30644408845794,
					-0.6009571984805575
				]
			]
		},
		{
			"type": "rectangle",
			"version": 217,
			"versionNonce": 1726486057,
			"isDeleted": false,
			"id": "XulUJOZXGhi4yKvrHYk5L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 155.04131894453624,
			"y": 437.3869932197986,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 65,
			"height": 45,
			"seed": 941750599,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "6RZGabkV",
					"type": "text"
				},
				{
					"id": "jqJL2WmoUYSKf4w8iu7HK",
					"type": "arrow"
				}
			],
			"updated": 1681841343618,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 227,
			"versionNonce": 1810529511,
			"isDeleted": false,
			"id": "6RZGabkV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 174.94132809980968,
			"y": 447.3869932197986,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 25.199981689453125,
			"height": 25,
			"seed": 1604928873,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fin",
			"rawText": "Fin",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "XulUJOZXGhi4yKvrHYk5L",
			"originalText": "Fin",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 56,
			"versionNonce": 2075486473,
			"isDeleted": false,
			"id": "QnRrdCzV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -34.37990668052774,
			"y": -203.52479953288073,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 48,
			"versionNonce": 1400391687,
			"isDeleted": false,
			"id": "rHqdDtXW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -36.078284645434934,
			"y": 100.72527440508293,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 60,
			"versionNonce": 1964335081,
			"isDeleted": false,
			"id": "EG1cQD2A",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 79.5702198606819,
			"y": 416.35691709598774,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 85,
			"versionNonce": 425701159,
			"isDeleted": false,
			"id": "1f79Xjkj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -17.839149162077177,
			"y": 719.9102538772834,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "6J5YigvZDkmxsGh4IHyQL",
					"type": "arrow"
				}
			],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 161,
			"versionNonce": 1897102025,
			"isDeleted": false,
			"id": "6J5YigvZDkmxsGh4IHyQL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.173094845204929,
			"y": 731.8842792801818,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 56.743760263576604,
			"height": 0.1955275745066274,
			"seed": 722076391,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1f79Xjkj",
				"focus": -0.048507491220964934,
				"gap": 14.572256824664919
			},
			"endBinding": {
				"elementId": "WDXLxPSH",
				"focus": 0.00669010467751252,
				"gap": 5.202142230082416
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					56.743760263576604,
					0.1955275745066274
				]
			]
		},
		{
			"type": "text",
			"version": 69,
			"versionNonce": 2014130759,
			"isDeleted": false,
			"id": "WDXLxPSH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 77.11899733886395,
			"y": 719.8014848814944,
			"strokeColor": "#c92a2a",
			"backgroundColor": "#fa5252",
			"width": 69.25991821289062,
			"height": 25,
			"seed": 92790089,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "6J5YigvZDkmxsGh4IHyQL",
					"type": "arrow"
				}
			],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Colisión",
			"rawText": "Colisión",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Colisión",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 549,
			"versionNonce": 1078671785,
			"isDeleted": false,
			"id": "D4gdQGBSg_Q70gKNeAlp1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 57.79270961510093,
			"y": -273.37723452438655,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 237.66583704175423,
			"height": 141.4480643384095,
			"seed": 1853967271,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "qKi3kBSUPdHFfd12XVhWf",
				"focus": 0.3320121295075341,
				"gap": 1
			},
			"endBinding": {
				"elementId": "qKi3kBSUPdHFfd12XVhWf",
				"focus": 0.054310186974509296,
				"gap": 1.9477936846300423
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					105.10886780269897,
					-13.821333271471815
				],
				[
					91.43345836116771,
					-135.29136226975027
				],
				[
					-114.75743370481291,
					-141.4480643384095
				],
				[
					-132.55696923905526,
					-63.1132582332246
				]
			]
		},
		{
			"type": "arrow",
			"version": 465,
			"versionNonce": 157464092,
			"isDeleted": false,
			"id": "CrsScDhWRQ4GAaMmez04d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 62.905091747841425,
			"y": 26.22021672336387,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 95.98701810088967,
			"height": 148.98032041853259,
			"seed": 1510642761,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682334099229,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "F1nakk76YYM-_QMq3yH0E",
				"focus": 0.22099586410993796,
				"gap": 1
			},
			"endBinding": {
				"elementId": "1jL5K4vhNs5aqhrflTGGK",
				"focus": -0.423470275003777,
				"gap": 2.417878947706356
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					89.3152522719315,
					-8.421675328193018
				],
				[
					95.98701810088967,
					-137.1011939248781
				],
				[
					11.372806505899758,
					-148.98032041853259
				]
			]
		},
		{
			"type": "text",
			"version": 38,
			"versionNonce": 333978761,
			"isDeleted": false,
			"id": "JlAKzfte",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 94.71546670743305,
			"y": -13.221261976196786,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 108,
			"versionNonce": 329026695,
			"isDeleted": false,
			"id": "QR49gAlC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 103.80585971207029,
			"y": -315.1393854880162,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841343618,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 61,
			"versionNonce": 2001766439,
			"isDeleted": false,
			"id": "BRrel3vO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 62.24162863732039,
			"y": 592.7338128468263,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841408194,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 68,
			"versionNonce": 1125645639,
			"isDeleted": false,
			"id": "rGmKUubl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -49.35523714273285,
			"y": 532.1526514738715,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681841413961,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 512,
			"versionNonce": 111619751,
			"isDeleted": false,
			"id": "WcJ7wkvFRxpuWeCjV3O86",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -222.21831354275673,
			"y": 925.4473104701888,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 104.56654866536473,
			"height": 1048.0542755126958,
			"seed": 2102321545,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681841469249,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "3nq7wru2VHarqINCYrjmE",
				"focus": -0.8995659228268833,
				"gap": 1.43641191340555
			},
			"endBinding": {
				"elementId": "1jL5K4vhNs5aqhrflTGGK",
				"focus": 0.8731314238134301,
				"gap": 2.307723311031168
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-99.36737060546875,
					-122.30326334635424
				],
				[
					-104.56654866536473,
					-927.9190063476566
				],
				[
					-0.07130940755212123,
					-1048.0542755126958
				]
			]
		},
		{
			"type": "arrow",
			"version": 1234,
			"versionNonce": 1327141673,
			"isDeleted": false,
			"id": "46qJf2p1TgWFWqdtDunSW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 83.58701463639318,
			"y": 800.7089398323701,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 162.59673657702365,
			"height": 194.28050245210272,
			"seed": 1856662631,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842027106,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zDV--T1PVtdGhiSX67DGd",
				"focus": -0.8549425324570925,
				"gap": 13.47836637648578
			},
			"endBinding": {
				"elementId": "3OctvZjC",
				"focus": 0.6198331610919959,
				"gap": 7.4678579758414685
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					162.59673657702365,
					110.71986014455831
				],
				[
					54.779355974105044,
					194.28050245210272
				]
			]
		},
		{
			"type": "text",
			"version": 654,
			"versionNonce": 927306887,
			"isDeleted": false,
			"id": "3OctvZjC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -205.57218858847511,
			"y": 1002.2843320997005,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 336.3801574707031,
			"height": 59.34092965134528,
			"seed": 1648842983,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "46qJf2p1TgWFWqdtDunSW",
					"type": "arrow"
				}
			],
			"updated": 1681842007935,
			"link": null,
			"locked": false,
			"fontSize": 15.824247907025406,
			"fontFamily": 1,
			"text": "Para evitar que los computadores\ninvolucrados retransmitan\ninmediatamente y se produzca otra colisión",
			"rawText": "Para evitar que los computadores\ninvolucrados retransmitan\ninmediatamente y se produzca otra colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Para evitar que los computadores\ninvolucrados retransmitan\ninmediatamente y se produzca otra colisión",
			"lineHeight": 1.25,
			"baseline": 53
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#fa5252",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1309.8784335078815,
		"scrollY": 520.9693752846257,
		"zoom": {
			"value": 0.5
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%