---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^8cHVGHQP

B ^7ShYU0GD

C ^1ukm7DoB

D ^dTDfIyfn

E ^JL6NhCOD

F ^cykIXMKe

G ^eyNWa2IA

H ^QugMg4uL

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.3",
	"elements": [
		{
			"type": "rectangle",
			"version": 251,
			"versionNonce": 2047275687,
			"isDeleted": false,
			"id": "0atNWSx1Yo_U7LE1XUnXD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -149.6239102136484,
			"y": -208.5073593940586,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370279,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 245,
			"versionNonce": 1142173513,
			"isDeleted": false,
			"id": "8cHVGHQP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.76517608278903,
			"y": -197.70906532667578,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370279,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 619,
			"versionNonce": 1509950919,
			"isDeleted": false,
			"id": "g8njt6eGEM6nZfetlhbey",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -250.23943959639257,
			"y": -170.64161485903222,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 501,
			"versionNonce": 1245797929,
			"isDeleted": false,
			"id": "7ShYU0GD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -231.64678822920507,
			"y": -160.89039415590722,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 429,
			"versionNonce": 2074719463,
			"isDeleted": false,
			"id": "9QQv9xTMwqBx70XP3FFGy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -282.3209011804452,
			"y": -92.11451042555274,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 134709178,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 387,
			"versionNonce": 883273993,
			"isDeleted": false,
			"id": "1ukm7DoB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -264.46216704958584,
			"y": -81.31621635816992,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 557021306,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 727,
			"versionNonce": 378568711,
			"isDeleted": false,
			"id": "TqTYr8Lb6qb742AAzMfHT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.98728768104291,
			"y": -13.488195738236925,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 2113728742,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 677,
			"versionNonce": 951887849,
			"isDeleted": false,
			"id": "dTDfIyfn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -232.32852710014635,
			"y": -1.8948719768122828,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.599990844726562,
			"height": 25,
			"seed": 1480188966,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "D",
			"rawText": "D",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "D",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "line",
			"version": 278,
			"versionNonce": 1018226471,
			"isDeleted": false,
			"id": "L7eOq2jQ6O_9LTTR96oVO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.80059173220309,
			"y": -163.40813530348242,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"seed": 179889254,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			]
		},
		{
			"type": "line",
			"version": 516,
			"versionNonce": 1351729865,
			"isDeleted": false,
			"id": "DWwMr5ET0xN-4BzFb8le6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -202.24412343772076,
			"y": -126.45149077815151,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.669769287109375,
			"height": 19.737258911132812,
			"seed": 1732116966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					23.669769287109375,
					19.737258911132812
				]
			]
		},
		{
			"type": "line",
			"version": 358,
			"versionNonce": 209152583,
			"isDeleted": false,
			"id": "F_1IHui4-hCjGgpSPrRuC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -230.0981686364999,
			"y": -70.4450386848301,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.6435546875,
			"height": 0.6782379150390625,
			"seed": 2008008422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					39.6435546875,
					0.6782379150390625
				]
			]
		},
		{
			"type": "line",
			"version": 577,
			"versionNonce": 683704745,
			"isDeleted": false,
			"id": "tK1fcQSbH88XcRypT34HT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -179.30013043394183,
			"y": -32.92543370862003,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.852935791015625,
			"height": 20.293563842773438,
			"seed": 207788006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-24.852935791015625,
					20.293563842773438
				]
			]
		},
		{
			"type": "ellipse",
			"version": 116,
			"versionNonce": 583043431,
			"isDeleted": false,
			"id": "Waqake79mMTFQXHx0V7w3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.47184753417974,
			"y": -129.97772923775148,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 127.6279296875,
			"height": 119.86566162109375,
			"seed": 15501417,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 712,
			"versionNonce": 1316250761,
			"isDeleted": false,
			"id": "QfL3aMtIcZpsXYB8En2wk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -150.17695617675787,
			"y": 26.206093394084434,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 596,
			"versionNonce": 1289274503,
			"isDeleted": false,
			"id": "JL6NhCOD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.44950866699224,
			"y": 35.957314097209434,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "E",
			"rawText": "E",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "E",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 693,
			"versionNonce": 493415273,
			"isDeleted": false,
			"id": "O2eyk_XNs0cPNV9l8anx8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -51.548263549804744,
			"y": -16.02847997017338,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 576,
			"versionNonce": 2054986663,
			"isDeleted": false,
			"id": "cykIXMKe",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -32.955612182617244,
			"y": -6.2772592670483505,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "F",
			"rawText": "F",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "F",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 718,
			"versionNonce": 1844024905,
			"isDeleted": false,
			"id": "VmP7mQAmboW-fWIBZn_iT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -21.599288940429744,
			"y": -93.7465585834546,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 604,
			"versionNonce": 1876463303,
			"isDeleted": false,
			"id": "eyNWa2IA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -3.0066375732422443,
			"y": -83.86481419868898,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.779998779296875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "G",
			"rawText": "G",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "G",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "rectangle",
			"version": 760,
			"versionNonce": 2000383655,
			"isDeleted": false,
			"id": "WA1W0JDtX2O2H6_q1MjoU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -53.61140441894537,
			"y": -173.06681004829835,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834394967,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 643,
			"versionNonce": 1064661833,
			"isDeleted": false,
			"id": "QugMg4uL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -35.01875305175787,
			"y": -163.31558934517335,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.019989013671875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834394967,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "H",
			"rawText": "H",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "H",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "line",
			"version": 291,
			"versionNonce": 932009993,
			"isDeleted": false,
			"id": "G0IUUQuxRssE1CwNtCWn5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -125.59046649246949,
			"y": -8.420225712960956,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"seed": 179889254,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			]
		},
		{
			"type": "line",
			"version": 596,
			"versionNonce": 1419430151,
			"isDeleted": false,
			"id": "lTAFK0v29omM3bK8vBRiu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -72.39628850892193,
			"y": -33.97836143366192,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.669769287109375,
			"height": 19.737258911132812,
			"seed": 1732116966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					23.669769287109375,
					19.737258911132812
				]
			]
		},
		{
			"type": "line",
			"version": 439,
			"versionNonce": 1847029481,
			"isDeleted": false,
			"id": "eEXMzWhTzkRYah3k0gb0K",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -61.6969931416214,
			"y": -72.11104228519966,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.6435546875,
			"height": 0.6782379150390625,
			"seed": 2008008422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834370280,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					39.6435546875,
					0.6782379150390625
				]
			]
		},
		{
			"type": "line",
			"version": 756,
			"versionNonce": 1759632873,
			"isDeleted": false,
			"id": "tuU2FgX76XU41jA7ZTt5h",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -54.31799649730797,
			"y": -131.60622433051134,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.852935791015625,
			"height": 20.293563842773438,
			"seed": 207788006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834391572,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-24.852935791015625,
					20.293563842773438
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 342.5321470623906,
		"scrollY": 226.86767401561207,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%