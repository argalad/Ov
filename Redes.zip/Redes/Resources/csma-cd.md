---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
¿Trama lista
para transmitir? ^ETNcUsHQ

Escuchar canal ^pXDnfHn7

¿Canal libre? ^bfiELyJj

Transmitir trama / 
Escuchar canal ^GXlRf59D

¿Señal escuchada
= señal transmitida? ^uHtgHj3D

Interrumpir transmisión y
enviar invalidación (jam) ^5HsciI3X

Iniciar
retransmisión ^o1JeKisq

Fin ^6RZGabkV

Sí ^QnRrdCzV

Sí ^rHqdDtXW

Sí ^EG1cQD2A

No ^1f79Xjkj

Colisión ^WDXLxPSH

No ^QR49gAlC

No ^JlAKzfte

Esperar intervalo
aleatorio (backoff) ^a6TzFI4D

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "diamond",
			"version": 253,
			"versionNonce": 742704553,
			"isDeleted": false,
			"id": "qKi3kBSUPdHFfd12XVhWf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.50778198242188,
			"y": -334.5926539617458,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"HqumOebvy25DUTzQrKJYk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "D4gdQGBSg_Q70gKNeAlp1",
					"type": "arrow"
				}
			],
			"updated": 1681842331920,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 159,
			"versionNonce": 999458151,
			"isDeleted": false,
			"id": "ETNcUsHQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -154.33370971679688,
			"y": -303.9004440307617,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 159.21986389160156,
			"height": 50,
			"seed": 380734185,
			"groupIds": [
				"HqumOebvy25DUTzQrKJYk"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331920,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Trama lista\npara transmitir?",
			"rawText": "¿Trama lista\npara transmitir?",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Trama lista\npara transmitir?",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 444,
			"versionNonce": 1624254601,
			"isDeleted": false,
			"id": "1jL5K4vhNs5aqhrflTGGK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.98189963927769,
			"y": -149.82598322211956,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"WUXCosQUNwO_g71HzACpJ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "CrsScDhWRQ4GAaMmez04d",
					"type": "arrow"
				},
				{
					"id": "WcJ7wkvFRxpuWeCjV3O86",
					"type": "arrow"
				}
			],
			"updated": 1681842331921,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 432,
			"versionNonce": 1913340039,
			"isDeleted": false,
			"id": "pXDnfHn7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -147.65515352433,
			"y": -138.33051566314035,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 148.91990661621094,
			"height": 25,
			"seed": 551045735,
			"groupIds": [
				"WUXCosQUNwO_g71HzACpJ"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "XOSVhUemnyuByXHPsB5XD",
					"type": "arrow"
				},
				{
					"id": "z5Hbr9qoZJXgueDIppLq9",
					"type": "arrow"
				}
			],
			"updated": 1681842331921,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Escuchar canal",
			"rawText": "Escuchar canal",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Escuchar canal",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "diamond",
			"version": 456,
			"versionNonce": 2007773033,
			"isDeleted": false,
			"id": "F1nakk76YYM-_QMq3yH0E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.54647318127502,
			"y": -32.36933306986464,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"pAFWHjtJollszQVnbMBRh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "z5Hbr9qoZJXgueDIppLq9",
					"type": "arrow"
				},
				{
					"id": "CrsScDhWRQ4GAaMmez04d",
					"type": "arrow"
				}
			],
			"updated": 1681842331921,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 410,
			"versionNonce": 1275041703,
			"isDeleted": false,
			"id": "bfiELyJj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.8653310011089,
			"y": 14.264092111229502,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 124.03990173339844,
			"height": 25,
			"seed": 380734185,
			"groupIds": [
				"pAFWHjtJollszQVnbMBRh"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331921,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Canal libre?",
			"rawText": "¿Canal libre?",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Canal libre?",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 491,
			"versionNonce": 656693833,
			"isDeleted": false,
			"id": "_hqEUZYmpfq0eNzzAGf11",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -222.41618344247888,
			"y": 156.25595202954298,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"7uiJvFkdsEWFqheLshQ3Y"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "qs_UpiyS9ml3ZmoBtKmYq",
					"type": "arrow"
				}
			],
			"updated": 1681842331921,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 649,
			"versionNonce": 261884615,
			"isDeleted": false,
			"id": "GXlRf59D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -173.6219457389567,
			"y": 158.52188057727562,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 198.7798614501953,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"7uiJvFkdsEWFqheLshQ3Y"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331921,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Transmitir trama / \nEscuchar canal",
			"rawText": "Transmitir trama / \nEscuchar canal",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Transmitir trama / \nEscuchar canal",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "diamond",
			"version": 643,
			"versionNonce": 1207167719,
			"isDeleted": false,
			"id": "kRpAkLhAIivMPuVLZHx4V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.13011027398954,
			"y": 273.64237486084176,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 274.451904296875,
			"height": 118.18827819824219,
			"seed": 429827495,
			"groupIds": [
				"tO2RuWWOyV9nWOPllCMdJ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "hBO67_ImbvtbwsUly_CCV",
					"type": "arrow"
				},
				{
					"id": "jqJL2WmoUYSKf4w8iu7HK",
					"type": "arrow"
				},
				{
					"id": "xHi0FeFABCiXFB_6WPgOb",
					"type": "arrow"
				}
			],
			"updated": 1681842351136,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 800,
			"versionNonce": 1087962055,
			"isDeleted": false,
			"id": "uHtgHj3D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -176.0204625231956,
			"y": 307.66221947247044,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 204.49984741210938,
			"height": 50,
			"seed": 380734185,
			"groupIds": [
				"tO2RuWWOyV9nWOPllCMdJ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842350816,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "¿Señal escuchada\n= señal transmitida?",
			"rawText": "¿Señal escuchada\n= señal transmitida?",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "¿Señal escuchada\n= señal transmitida?",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 746,
			"versionNonce": 713022729,
			"isDeleted": false,
			"id": "zDV--T1PVtdGhiSX67DGd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.08545844883162,
			"y": 460.3590254088817,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"Mj5R__xwoSLP9S7Ksntpm"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "hBO67_ImbvtbwsUly_CCV",
					"type": "arrow"
				},
				{
					"id": "48sCmMBA4h-zydeylqyiV",
					"type": "arrow"
				}
			],
			"updated": 1681842545657,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 948,
			"versionNonce": 983970279,
			"isDeleted": false,
			"id": "5HsciI3X",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.28114933628905,
			"y": 461.51703766903677,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 242.0597686767578,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"Mj5R__xwoSLP9S7Ksntpm"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842551880,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Interrumpir transmisión y\nenviar invalidación (jam)",
			"rawText": "Interrumpir transmisión y\nenviar invalidación (jam)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Interrumpir transmisión y\nenviar invalidación (jam)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 913,
			"versionNonce": 366722727,
			"isDeleted": false,
			"id": "3nq7wru2VHarqINCYrjmE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.0809407655812,
			"y": 708.1603825189842,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"utQH0TMZaWwaZ95AKV57g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "WcJ7wkvFRxpuWeCjV3O86",
					"type": "arrow"
				},
				{
					"id": "PlpZgUUtVF2Bkb2RMUvpu",
					"type": "arrow"
				}
			],
			"updated": 1681842506964,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1169,
			"versionNonce": 962286023,
			"isDeleted": false,
			"id": "o1JeKisq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -135.67933880130306,
			"y": 709.0877131091995,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 125.67987060546875,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"utQH0TMZaWwaZ95AKV57g"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "WcJ7wkvFRxpuWeCjV3O86",
					"type": "arrow"
				},
				{
					"id": "PlpZgUUtVF2Bkb2RMUvpu",
					"type": "arrow"
				}
			],
			"updated": 1681842506964,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Iniciar\nretransmisión",
			"rawText": "Iniciar\nretransmisión",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Iniciar\nretransmisión",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 178,
			"versionNonce": 1724874121,
			"isDeleted": false,
			"id": "XOSVhUemnyuByXHPsB5XD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.85871698088982,
			"y": -219.36771792456622,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842483383,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "pXDnfHn7",
				"focus": -0.047516650035434066,
				"gap": 14.729620081654076
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 349,
			"versionNonce": 1894582663,
			"isDeleted": false,
			"id": "z5Hbr9qoZJXgueDIppLq9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.52467463642571,
			"y": -98.88850955485123,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3373565458303176,
			"height": 66.3075821797718,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842331921,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "pXDnfHn7",
				"focus": 0.010521480447920666,
				"gap": 14.442006108289121
			},
			"endBinding": {
				"elementId": "F1nakk76YYM-_QMq3yH0E",
				"focus": -0.012662666893885241,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.3373565458303176,
					66.3075821797718
				]
			]
		},
		{
			"type": "arrow",
			"version": 492,
			"versionNonce": 661091945,
			"isDeleted": false,
			"id": "qs_UpiyS9ml3ZmoBtKmYq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -76.03100702603982,
			"y": 83.16982872100127,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.9098513197723435,
			"height": 68.23200788062283,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842331921,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "_hqEUZYmpfq0eNzzAGf11",
				"focus": -0.00584789685877575,
				"gap": 4.8541154279188845
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.9098513197723435,
					68.23200788062283
				]
			]
		},
		{
			"type": "arrow",
			"version": 698,
			"versionNonce": 303745065,
			"isDeleted": false,
			"id": "xHi0FeFABCiXFB_6WPgOb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -76.32648502125147,
			"y": 207.60188178106182,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.02672447613642248,
			"height": 65.82562015515555,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842351136,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "kRpAkLhAIivMPuVLZHx4V",
				"focus": -0.010735069816203785,
				"gap": 1
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.02672447613642248,
					65.82562015515555
				]
			]
		},
		{
			"type": "arrow",
			"version": 719,
			"versionNonce": 1248941033,
			"isDeleted": false,
			"id": "hBO67_ImbvtbwsUly_CCV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.03113814708102,
			"y": 392.54348277250335,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.5023243298530531,
			"height": 62.89828850430058,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842545657,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "kRpAkLhAIivMPuVLZHx4V",
				"focus": -0.009887173385483875,
				"gap": 1
			},
			"endBinding": {
				"elementId": "zDV--T1PVtdGhiSX67DGd",
				"focus": -0.011050962101724524,
				"gap": 4.917254132077801
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.5023243298530531,
					62.89828850430058
				]
			]
		},
		{
			"type": "arrow",
			"version": 1387,
			"versionNonce": 1493763911,
			"isDeleted": false,
			"id": "48sCmMBA4h-zydeylqyiV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -73.05699203712248,
			"y": 513.1017011901317,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07801578159912026,
			"height": 67.33810376736346,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842554459,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "zDV--T1PVtdGhiSX67DGd",
				"focus": 0.00010865147066196472,
				"gap": 1
			},
			"endBinding": {
				"elementId": "LM_I4jY_7YEUNb5Muzo50",
				"focus": 0.0047672335401140395,
				"gap": 4.438659496279229
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.07801578159912026,
					67.33810376736346
				]
			]
		},
		{
			"type": "arrow",
			"version": 1742,
			"versionNonce": 1460598729,
			"isDeleted": false,
			"id": "jqJL2WmoUYSKf4w8iu7HK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 63.5960477570861,
			"y": 332.90779923476947,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 103.40481144358398,
			"height": 0.25706250809145104,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842447144,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "kRpAkLhAIivMPuVLZHx4V",
				"gap": 1.2857142857142854,
				"focus": -0.0029261704996016895
			},
			"endBinding": {
				"elementId": "XulUJOZXGhi4yKvrHYk5L",
				"gap": 8.81296218783273,
				"focus": 0.04950890822991109
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					103.40481144358398,
					0.25706250809145104
				]
			]
		},
		{
			"type": "rectangle",
			"version": 289,
			"versionNonce": 603753577,
			"isDeleted": false,
			"id": "XulUJOZXGhi4yKvrHYk5L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 175.81382138850282,
			"y": 311.8855155050516,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 65,
			"height": 45,
			"seed": 941750599,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "6RZGabkV",
					"type": "text"
				},
				{
					"id": "jqJL2WmoUYSKf4w8iu7HK",
					"type": "arrow"
				}
			],
			"updated": 1681842356648,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 299,
			"versionNonce": 288328359,
			"isDeleted": false,
			"id": "6RZGabkV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 195.71383054377625,
			"y": 321.8855155050516,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 25.199981689453125,
			"height": 25,
			"seed": 1604928873,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842356648,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fin",
			"rawText": "Fin",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "XulUJOZXGhi4yKvrHYk5L",
			"originalText": "Fin",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 57,
			"versionNonce": 173225255,
			"isDeleted": false,
			"id": "QnRrdCzV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -34.37990668052774,
			"y": -203.52479953288073,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 49,
			"versionNonce": 1602442441,
			"isDeleted": false,
			"id": "rHqdDtXW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -36.078284645434934,
			"y": 100.72527440508293,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 126,
			"versionNonce": 307491047,
			"isDeleted": false,
			"id": "EG1cQD2A",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 92.51489070495296,
			"y": 293.5980217956341,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 18.439987182617188,
			"height": 25,
			"seed": 188252135,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842360949,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 172,
			"versionNonce": 1026583975,
			"isDeleted": false,
			"id": "1f79Xjkj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -0.7314725664125206,
			"y": 395.6862432938343,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 188252135,
			"groupIds": [
				"Gi6KKxkZO3zC23ndSXC7d"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "6J5YigvZDkmxsGh4IHyQL",
					"type": "arrow"
				}
			],
			"updated": 1681842440194,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 422,
			"versionNonce": 272769223,
			"isDeleted": false,
			"id": "6J5YigvZDkmxsGh4IHyQL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 37.80076045454146,
			"y": 407.6695126264641,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 53.98376575674067,
			"height": 0.18617013598759513,
			"seed": 722076391,
			"groupIds": [
				"Gi6KKxkZO3zC23ndSXC7d"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842440195,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "1f79Xjkj",
				"focus": -0.04851332976678099,
				"gap": 14.572256824664919
			},
			"endBinding": {
				"elementId": "WDXLxPSH",
				"focus": 0.006690104677518224,
				"gap": 5.202142230082416
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					53.98376575674067,
					0.18617013598759513
				]
			]
		},
		{
			"type": "text",
			"version": 154,
			"versionNonce": 1357877767,
			"isDeleted": false,
			"id": "WDXLxPSH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 96.98666844136454,
			"y": 395.57747429804533,
			"strokeColor": "#c92a2a",
			"backgroundColor": "#fa5252",
			"width": 69.25991821289062,
			"height": 25,
			"seed": 92790089,
			"groupIds": [
				"Gi6KKxkZO3zC23ndSXC7d"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "6J5YigvZDkmxsGh4IHyQL",
					"type": "arrow"
				}
			],
			"updated": 1681842437735,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Colisión",
			"rawText": "Colisión",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Colisión",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 550,
			"versionNonce": 179688071,
			"isDeleted": false,
			"id": "D4gdQGBSg_Q70gKNeAlp1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 57.79270961510093,
			"y": -273.37723452438655,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 237.66583704175423,
			"height": 141.4480643384095,
			"seed": 1853967271,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "qKi3kBSUPdHFfd12XVhWf",
				"focus": 0.3320121295075341,
				"gap": 1
			},
			"endBinding": {
				"elementId": "qKi3kBSUPdHFfd12XVhWf",
				"focus": 0.054310186974509296,
				"gap": 1.9477936846300423
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					105.10886780269897,
					-13.821333271471815
				],
				[
					91.43345836116771,
					-135.29136226975027
				],
				[
					-114.75743370481291,
					-141.4480643384095
				],
				[
					-132.55696923905526,
					-63.1132582332246
				]
			]
		},
		{
			"type": "arrow",
			"version": 465,
			"versionNonce": 36420969,
			"isDeleted": false,
			"id": "CrsScDhWRQ4GAaMmez04d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 63.43866588944303,
			"y": 26.376949652952874,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 95.45344395928807,
			"height": 149.13705334812158,
			"seed": 1510642761,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "F1nakk76YYM-_QMq3yH0E",
				"focus": 0.22099586410993796,
				"gap": 1
			},
			"endBinding": {
				"elementId": "1jL5K4vhNs5aqhrflTGGK",
				"focus": -0.423470275003777,
				"gap": 2.417878947706356
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					88.7816781303299,
					-8.578408257782023
				],
				[
					95.45344395928807,
					-137.2579268544671
				],
				[
					10.839232364298153,
					-149.13705334812158
				]
			]
		},
		{
			"type": "text",
			"version": 39,
			"versionNonce": 1434970535,
			"isDeleted": false,
			"id": "JlAKzfte",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 94.71546670743305,
			"y": -13.221261976196786,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 109,
			"versionNonce": 377628745,
			"isDeleted": false,
			"id": "QR49gAlC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 103.80585971207029,
			"y": -315.1393854880162,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 23.959976196289062,
			"height": 25,
			"seed": 2051400359,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842331922,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 1510,
			"versionNonce": 889317511,
			"isDeleted": false,
			"id": "WcJ7wkvFRxpuWeCjV3O86",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -223.3052930666779,
			"y": 735.0853032672784,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 104.4952392578125,
			"height": 857.6957699790637,
			"seed": 2102321545,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842578425,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "3nq7wru2VHarqINCYrjmE",
				"focus": -0.8568926785070157,
				"gap": 4.224352301096701
			},
			"endBinding": {
				"elementId": "1jL5K4vhNs5aqhrflTGGK",
				"focus": 0.873149507902515,
				"gap": 2.307723311031168
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-103.37925772522573,
					-86.94456665965208
				],
				[
					-103.47956914144345,
					-737.5605008140246
				],
				[
					1.0156701163690514,
					-857.6957699790637
				]
			]
		},
		{
			"type": "rectangle",
			"version": 940,
			"versionNonce": 2054300711,
			"isDeleted": false,
			"id": "LM_I4jY_7YEUNb5Muzo50",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.5606017147677,
			"y": 584.8784644537744,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 291.8419189453125,
			"height": 51.74267578125,
			"seed": 871542247,
			"groupIds": [
				"g2BzoZdTF1cq8fqx30Agt"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "48sCmMBA4h-zydeylqyiV",
					"type": "arrow"
				},
				{
					"id": "PlpZgUUtVF2Bkb2RMUvpu",
					"type": "arrow"
				}
			],
			"updated": 1681842554458,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1125,
			"versionNonce": 287320841,
			"isDeleted": false,
			"id": "a6TzFI4D",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -166.80954788584995,
			"y": 585.9685092514975,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 188.17982482910156,
			"height": 50,
			"seed": 551045735,
			"groupIds": [
				"g2BzoZdTF1cq8fqx30Agt"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681842556361,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Esperar intervalo\naleatorio (backoff)",
			"rawText": "Esperar intervalo\naleatorio (backoff)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Esperar intervalo\naleatorio (backoff)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 454,
			"versionNonce": 85362279,
			"isDeleted": false,
			"id": "PlpZgUUtVF2Bkb2RMUvpu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -73.93666873472561,
			"y": 637.6211402350244,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.7361848650373588,
			"height": 65.82559222382201,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681842554459,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "LM_I4jY_7YEUNb5Muzo50",
				"focus": 0.004319735885392721,
				"gap": 1
			},
			"endBinding": {
				"elementId": "o1JeKisq",
				"focus": -0.0002914411237216684,
				"gap": 5.640980650353072
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.7361848650373588,
					65.82559222382201
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#fa5252",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 775.1608565959011,
		"scrollY": 187.35590573048714,
		"zoom": {
			"value": 0.8185320288747125
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%