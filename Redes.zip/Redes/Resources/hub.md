---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^8cHVGHQP

B ^7ShYU0GD

C ^1ukm7DoB

D ^dTDfIyfn

E ^JL6NhCOD

F ^cykIXMKe

G ^eyNWa2IA

H ^QugMg4uL

HUB ^DBJ2665C

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 344,
			"versionNonce": 29845161,
			"isDeleted": false,
			"id": "0atNWSx1Yo_U7LE1XUnXD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.12442901247653,
			"y": -199.23887337110938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 338,
			"versionNonce": 1841722471,
			"isDeleted": false,
			"id": "8cHVGHQP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -145.26569488161715,
			"y": -188.44057930372657,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 696,
			"versionNonce": 257337737,
			"isDeleted": false,
			"id": "g8njt6eGEM6nZfetlhbey",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.5301195280332,
			"y": -177.54377550356347,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 578,
			"versionNonce": 904482695,
			"isDeleted": false,
			"id": "7ShYU0GD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -257.9374681608457,
			"y": -167.79255480043847,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 492,
			"versionNonce": 1941606505,
			"isDeleted": false,
			"id": "9QQv9xTMwqBx70XP3FFGy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -303.7997524988046,
			"y": -98.18439567945899,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 134709178,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 450,
			"versionNonce": 658753191,
			"isDeleted": false,
			"id": "1ukm7DoB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -285.9410183679452,
			"y": -87.38610161207617,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 557021306,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551724,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 874,
			"versionNonce": 884906825,
			"isDeleted": false,
			"id": "TqTYr8Lb6qb742AAzMfHT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.74223152869916,
			"y": -16.8643859237838,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 2113728742,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 824,
			"versionNonce": 1887590855,
			"isDeleted": false,
			"id": "dTDfIyfn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -259.0834709478026,
			"y": -5.271062162359158,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.599990844726562,
			"height": 25,
			"seed": 1480188966,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "D",
			"rawText": "D",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "D",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 371,
			"versionNonce": 314460713,
			"isDeleted": false,
			"id": "L7eOq2jQ6O_9LTTR96oVO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.3011105310312,
			"y": -154.1396492805332,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"seed": 179889254,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			]
		},
		{
			"type": "line",
			"version": 593,
			"versionNonce": 918653159,
			"isDeleted": false,
			"id": "DWwMr5ET0xN-4BzFb8le6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -228.53480336936138,
			"y": -133.35365142268276,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.669769287109375,
			"height": 19.737258911132812,
			"seed": 1732116966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					23.669769287109375,
					19.737258911132812
				]
			]
		},
		{
			"type": "line",
			"version": 420,
			"versionNonce": 916790537,
			"isDeleted": false,
			"id": "F_1IHui4-hCjGgpSPrRuC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -251.7118160974374,
			"y": -76.64972008131447,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.6435546875,
			"height": 0.6782379150390625,
			"seed": 2008008422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					39.6435546875,
					0.6782379150390625
				]
			]
		},
		{
			"type": "line",
			"version": 724,
			"versionNonce": 1200477191,
			"isDeleted": false,
			"id": "tK1fcQSbH88XcRypT34HT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -206.05507428159808,
			"y": -36.3016238941669,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.852935791015625,
			"height": 20.293563842773438,
			"seed": 207788006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-24.852935791015625,
					20.293563842773438
				]
			]
		},
		{
			"type": "rectangle",
			"version": 801,
			"versionNonce": 182696743,
			"isDeleted": false,
			"id": "QfL3aMtIcZpsXYB8En2wk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -162.12843322753912,
			"y": 2.9664083354906836,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 685,
			"versionNonce": 1386622665,
			"isDeleted": false,
			"id": "JL6NhCOD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -143.4009857177735,
			"y": 12.717629038615684,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "E",
			"rawText": "E",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "E",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 763,
			"versionNonce": 892321351,
			"isDeleted": false,
			"id": "O2eyk_XNs0cPNV9l8anx8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -41.43675231933601,
			"y": -19.293464101032754,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 646,
			"versionNonce": 1164406185,
			"isDeleted": false,
			"id": "cykIXMKe",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -22.84410095214851,
			"y": -9.542243397907725,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "F",
			"rawText": "F",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "F",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 773,
			"versionNonce": 961437031,
			"isDeleted": false,
			"id": "VmP7mQAmboW-fWIBZn_iT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.605636596679744,
			"y": -98.9905771381421,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 659,
			"versionNonce": 257806473,
			"isDeleted": false,
			"id": "eyNWa2IA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1.9870147705077557,
			"y": -89.10883275337648,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.779998779296875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "G",
			"rawText": "G",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "G",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 842,
			"versionNonce": 2056001671,
			"isDeleted": false,
			"id": "WA1W0JDtX2O2H6_q1MjoU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.04969787597661,
			"y": -175.8696054584546,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 725,
			"versionNonce": 1447352169,
			"isDeleted": false,
			"id": "QugMg4uL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -20.457046508789112,
			"y": -166.1183847553296,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.019989013671875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "H",
			"rawText": "H",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "H",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 380,
			"versionNonce": 1051029415,
			"isDeleted": false,
			"id": "G0IUUQuxRssE1CwNtCWn5",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.54194354325074,
			"y": -31.659910771554706,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"seed": 179889254,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			]
		},
		{
			"type": "line",
			"version": 667,
			"versionNonce": 2087191113,
			"isDeleted": false,
			"id": "lTAFK0v29omM3bK8vBRiu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -62.28477727845319,
			"y": -37.11495811334942,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.669769287109375,
			"height": 19.737258911132812,
			"seed": 1732116966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					23.669769287109375,
					19.737258911132812
				]
			]
		},
		{
			"type": "line",
			"version": 494,
			"versionNonce": 1606869703,
			"isDeleted": false,
			"id": "eEXMzWhTzkRYah3k0gb0K",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.7033407978714,
			"y": -77.35506083988716,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.6435546875,
			"height": 0.6782379150390625,
			"seed": 2008008422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					39.6435546875,
					0.6782379150390625
				]
			]
		},
		{
			"type": "line",
			"version": 838,
			"versionNonce": 245551401,
			"isDeleted": false,
			"id": "tuU2FgX76XU41jA7ZTt5h",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -39.756289954339216,
			"y": -134.4090197406676,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.852935791015625,
			"height": 20.293563842773438,
			"seed": 207788006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-24.852935791015625,
					20.293563842773438
				]
			]
		},
		{
			"id": "k6-We4Qiwqwi0_jz1Iat-",
			"type": "rectangle",
			"x": -211.9999662762578,
			"y": -119.50788321361011,
			"width": 154,
			"height": 87,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 1741061127,
			"version": 174,
			"versionNonce": 1934652585,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "DBJ2665C"
				}
			],
			"updated": 1681834555290,
			"link": null,
			"locked": false
		},
		{
			"id": "DBJ2665C",
			"type": "text",
			"x": -154.91995681580858,
			"y": -88.50788321361011,
			"width": 39.83998107910156,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1339016393,
			"version": 43,
			"versionNonce": 1298646855,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681834555246,
			"link": null,
			"locked": false,
			"text": "HUB",
			"rawText": "HUB",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "k6-We4Qiwqwi0_jz1Iat-",
			"originalText": "HUB",
			"lineHeight": 1.25
		},
		{
			"type": "ellipse",
			"version": 118,
			"versionNonce": 535729129,
			"isDeleted": true,
			"id": "Waqake79mMTFQXHx0V7w3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.47184753417974,
			"y": -129.97772923775148,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 127.6279296875,
			"height": 119.86566162109375,
			"seed": 15501417,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834551725,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 409.02546371278123,
		"scrollY": 275.5141889081902,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%