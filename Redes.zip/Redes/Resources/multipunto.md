---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^LbE79AmR

B ^TPvWrGzA

C ^XhGPogad

D ^5zJK4uPA

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "rectangle",
			"version": 70,
			"versionNonce": 399914234,
			"isDeleted": false,
			"id": "T8vNCgfAR3jiPDmf75Kn_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -320.11783710061786,
			"y": -272.062102619186,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681761279482,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 260,
			"versionNonce": 1653012006,
			"isDeleted": false,
			"id": "vZjCABG1Lur2yX8b8vBJK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -248.59864154397724,
			"y": -273.72270137406883,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681761416228,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 64,
			"versionNonce": 1401818406,
			"isDeleted": false,
			"id": "LbE79AmR",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -302.2591029697585,
			"y": -261.2638085518032,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681761362509,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 193,
			"versionNonce": 640116538,
			"isDeleted": false,
			"id": "TPvWrGzA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -230.9067164951491,
			"y": -262.63854915238915,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681761416228,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 153,
			"versionNonce": 1993020518,
			"isDeleted": false,
			"id": "VlZkznqG_ipTYW1_l_R2R",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -176.854684024446,
			"y": -272.1522935066372,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 134709178,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761424782,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 357,
			"versionNonce": 871701798,
			"isDeleted": false,
			"id": "3AaoMfeQ0IGDXYauG3A-t",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -105.33548846780536,
			"y": -271.4700883064419,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 2113728742,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761440501,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 150,
			"versionNonce": 1393792166,
			"isDeleted": false,
			"id": "XhGPogad",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.9959498935866,
			"y": -261.3539994392544,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 557021306,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681761432723,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 277,
			"versionNonce": 1490012538,
			"isDeleted": false,
			"id": "5zJK4uPA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -87.64356341897724,
			"y": -262.7287400398403,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.599990844726562,
			"height": 25,
			"seed": 1480188966,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681761434376,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "D",
			"rawText": "D",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "D",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "miChy0OXtC9_JeCeGZD55",
			"type": "line",
			"x": -340.5158931308913,
			"y": -192.13112193681297,
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 213195002,
			"version": 96,
			"versionNonce": 967473958,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761532659,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "GDrIGyJxTfYUDR9K13hg9",
			"type": "line",
			"x": -295.29451861917255,
			"y": -226.96287852860985,
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 179889254,
			"version": 98,
			"versionNonce": 1461240870,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761519363,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "hpP1p__-w7O3SwtvxoLEq",
			"type": "line",
			"x": -223.32250323831317,
			"y": -228.37495738603172,
			"width": 0.776641845703125,
			"height": 35.569854736328125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1732116966,
			"version": 79,
			"versionNonce": 1963599226,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761514557,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.776641845703125,
					35.569854736328125
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "N99TEHRYlQcnpPf5hp-wL",
			"type": "line",
			"x": -151.74840655862567,
			"y": -226.46007091142235,
			"width": 0.6461181640625,
			"height": 33.2056884765625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2008008422,
			"version": 50,
			"versionNonce": 234680230,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761524324,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.6461181640625,
					33.2056884765625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "cKNcyv8WgYZrUTYMBldH-",
			"type": "line",
			"x": -79.99462237893817,
			"y": -226.14342052079735,
			"width": 0.35302734375,
			"height": 32.165863037109375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 207788006,
			"version": 95,
			"versionNonce": 702683322,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761529794,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.35302734375,
					32.165863037109375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 520.9006129795241,
		"scrollY": 461.94441157914696,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%