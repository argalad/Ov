---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Emisor ^XF0v5o35

Receptor ^6a1kWlNn

Datagrama UDP ^IoJa5SBH

Datagrama UDP ^DP2LbadH

Datagrama UDP ^4mBBkBw3

Datagrama UDP ^uPDgNTz8

Datagrama UDP ^v3DFjgeP

Datagrama UDP ^8JzGSblE

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "line",
			"version": 69,
			"versionNonce": 140894064,
			"isDeleted": false,
			"id": "RjtQOjguB5i1S5nwr6QUx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.2734146118164,
			"y": -177.5260467529297,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.341796875,
			"height": 281.9563903808594,
			"seed": 891828112,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614335680,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.341796875,
					281.9563903808594
				]
			]
		},
		{
			"type": "line",
			"version": 129,
			"versionNonce": 559444336,
			"isDeleted": false,
			"id": "Cxl8Gel6bz4oXpq4DV-XA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.85415621903742,
			"y": -175.39886252212807,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.341796875,
			"height": 281.9563903808594,
			"seed": 420678000,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614341649,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.341796875,
					281.9563903808594
				]
			]
		},
		{
			"type": "arrow",
			"version": 67,
			"versionNonce": 102486416,
			"isDeleted": false,
			"id": "4uoEJIxfSSfz_hf5azB3Q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.75324249267578,
			"y": -150.5436248779297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 25651600,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948324,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 78,
			"versionNonce": 1466945392,
			"isDeleted": false,
			"id": "cyEojDg36wkUWSM638461",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.71334853012578,
			"y": -112.03641338873192,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 2116888976,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948324,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 106,
			"versionNonce": 1942691728,
			"isDeleted": false,
			"id": "16LiYktKyI1rslCG8OtcM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.29537978012578,
			"y": -78.44333477545067,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 92.3828125,
			"height": 10.289703369140625,
			"seed": 1001359728,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948324,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					92.3828125,
					10.289703369140625
				]
			]
		},
		{
			"type": "arrow",
			"version": 135,
			"versionNonce": 1503945072,
			"isDeleted": false,
			"id": "v7aaJuxR8mVRTN74YFMSF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.7263642771961,
			"y": -36.65167828131004,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 94.14385986328125,
			"height": 10.159515380859375,
			"seed": 1803867024,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948324,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					94.14385986328125,
					10.159515380859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 128,
			"versionNonce": 1247849872,
			"isDeleted": false,
			"id": "9DsdqiwmMODCap8PzxBmZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.32203688461797,
			"y": 6.338556093689961,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 1058062192,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948324,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 149,
			"versionNonce": 192328560,
			"isDeleted": false,
			"id": "mUkK9vA9I9rzWYgOhSJMF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.51998915512578,
			"y": 44.36135272454935,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 776256912,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "text",
			"version": 82,
			"versionNonce": 320109456,
			"isDeleted": false,
			"id": "XF0v5o35",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.90166473388672,
			"y": -209.30404663085938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 61.0599365234375,
			"height": 25,
			"seed": 840245648,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Emisor",
			"rawText": "Emisor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Emisor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 78,
			"versionNonce": 858703216,
			"isDeleted": false,
			"id": "6a1kWlNn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -13.554023742675781,
			"y": -206.16795349121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 86.31991577148438,
			"height": 25,
			"seed": 1327880560,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Receptor",
			"rawText": "Receptor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Receptor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "line",
			"version": 69,
			"versionNonce": 1881049488,
			"isDeleted": false,
			"id": "TBmSH9X6NcSzmseSdyYiM",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -25.91797637939454,
			"y": -83.61656188964844,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 40.211578369140625,
			"height": 32.431640625,
			"seed": 1949172592,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-40.211578369140625,
					32.431640625
				]
			]
		},
		{
			"type": "line",
			"version": 72,
			"versionNonce": 236230512,
			"isDeleted": false,
			"id": "SPPpNA6Eyl7DS6scXDJMH",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -35.81055450439454,
			"y": -51.59507751464844,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 25.107421875,
			"height": 31.334625244140625,
			"seed": 901941648,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-25.107421875,
					-31.334625244140625
				]
			]
		},
		{
			"type": "line",
			"version": 110,
			"versionNonce": 2092357520,
			"isDeleted": false,
			"id": "e4oLHDbcc21grG0PSWoQf",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.257943481695825,
			"y": -42.463121157884586,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 40.211578369140625,
			"height": 32.431640625,
			"seed": 977620368,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-40.211578369140625,
					32.431640625
				]
			]
		},
		{
			"type": "line",
			"version": 113,
			"versionNonce": 1886398832,
			"isDeleted": false,
			"id": "58a1TJNlWIspGti9X2-YN",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -33.150521606695825,
			"y": -10.441636782884586,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 25.107421875,
			"height": 31.334625244140625,
			"seed": 1566907280,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-25.107421875,
					-31.334625244140625
				]
			]
		},
		{
			"type": "text",
			"version": 138,
			"versionNonce": 756376976,
			"isDeleted": false,
			"id": "IoJa5SBH",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -311.05401611328125,
			"y": -163.318359375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 1928374160,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 213,
			"versionNonce": 1703508848,
			"isDeleted": false,
			"id": "DP2LbadH",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.94297790527344,
			"y": -126.73240661621094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 143473552,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 182,
			"versionNonce": 779236240,
			"isDeleted": false,
			"id": "4mBBkBw3",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.07318115234375,
			"y": -92.49021911621094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 1783930256,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 213,
			"versionNonce": 1336446320,
			"isDeleted": false,
			"id": "uPDgNTz8",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.34596252441406,
			"y": -49.37956237792969,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 1858347376,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 272,
			"versionNonce": 1191526800,
			"isDeleted": false,
			"id": "v3DFjgeP",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.4924621582031,
			"y": -7.6341094970703125,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 1015562096,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 308,
			"versionNonce": 1586778000,
			"isDeleted": false,
			"id": "8JzGSblE",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.81732177734375,
			"y": 31.001968383789062,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 143470960,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613950982,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#f08c00",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 326.65816370646155,
		"scrollY": 579.1953609649922,
		"zoom": {
			"value": 0.6000000000000001
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%