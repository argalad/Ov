---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
    OUI        NIC ^2EKgU931

3 bytes            3 bytes ^fPkcRe1K

b1 b2 b3 b4 b5 b6 b7 b8 ^5JDaTXTt

0: unicast
1: multicast ^VxKZleHx

0: global
1: local ^JSNAHDjW

bit menos
significativo ^WdVT04ZI

ID del
fabricante ^6shlVNsC

ID de tarjeta
o interfaz de red ^CyQJgdBB

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "rectangle",
			"version": 181,
			"versionNonce": 1992688861,
			"isDeleted": false,
			"id": "fS2we0l2wGXHHn5cji7jb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -393.6392364501953,
			"y": -211.30110931396484,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 391.8997802734375,
			"height": 54.973388671875,
			"seed": 386475710,
			"groupIds": [
				"c_NxRtRr2QhDGQETNjrPp"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203898052,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 81,
			"versionNonce": 1143931763,
			"isDeleted": false,
			"id": "C9NhujVa-4zYSiZY3AXCP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -197.05824279785156,
			"y": -212.96138763427734,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.7958984375,
			"height": 56.543792724609375,
			"seed": 1906755042,
			"groupIds": [
				"c_NxRtRr2QhDGQETNjrPp"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203898052,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.7958984375,
					56.543792724609375
				]
			]
		},
		{
			"type": "text",
			"version": 273,
			"versionNonce": 648425885,
			"isDeleted": false,
			"id": "2EKgU931",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -395.6072731534285,
			"y": -204.8203353881836,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 324.9756164550781,
			"height": 41.38012695312506,
			"seed": 1617097506,
			"groupIds": [
				"c_NxRtRr2QhDGQETNjrPp"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203901219,
			"link": null,
			"locked": false,
			"fontSize": 33.10410156250005,
			"fontFamily": 1,
			"text": "    OUI        NIC",
			"rawText": "    OUI        NIC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "    OUI        NIC",
			"lineHeight": 1.25,
			"baseline": 29
		},
		{
			"type": "text",
			"version": 102,
			"versionNonce": 1271582270,
			"isDeleted": false,
			"id": "fPkcRe1K",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -316.3868103027344,
			"y": -143.27654266357422,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 272.5198669433594,
			"height": 25,
			"seed": 582941566,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682158721480,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "3 bytes            3 bytes",
			"rawText": "3 bytes            3 bytes",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "3 bytes            3 bytes",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 65,
			"versionNonce": 774237118,
			"isDeleted": false,
			"id": "JEoz4-yHwuAA1GeT8s5uG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -335.5785217285156,
			"y": -211.52791595458984,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.9456787109375,
			"height": 55.48687744140625,
			"seed": 610952126,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682158634801,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.9456787109375,
					55.48687744140625
				]
			]
		},
		{
			"type": "line",
			"version": 187,
			"versionNonce": 1360366206,
			"isDeleted": false,
			"id": "Jhcd9nSaGqMHsGM04Vy_8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.0123596191406,
			"y": -157.79119110107422,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 206.1533203125,
			"height": 157.54727172851562,
			"seed": 536678142,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682158708784,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-206.1533203125,
					157.54727172851562
				]
			]
		},
		{
			"type": "line",
			"version": 115,
			"versionNonce": 1900425406,
			"isDeleted": false,
			"id": "EVfs3ZkijC_Fapwi803wi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.3345642089844,
			"y": -157.03377532958984,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.3480224609375,
			"height": 155.15097045898438,
			"seed": 1333267966,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682158714346,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					24.3480224609375,
					155.15097045898438
				]
			]
		},
		{
			"type": "rectangle",
			"version": 150,
			"versionNonce": 976640701,
			"isDeleted": false,
			"id": "qG5YkIzCGvCdBkhXr2fqH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -597.8556747436523,
			"y": -1.4547576904296875,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 291.27716064453125,
			"height": 46.17987060546875,
			"seed": 1542532798,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203910019,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 87,
			"versionNonce": 685559539,
			"isDeleted": false,
			"id": "yLfokxyusBmGsJYitQ4mf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -454.12183380126953,
			"y": -2.0929183959960938,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 1.84857177734375,
			"height": 47.450775146484375,
			"seed": 374176802,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203924524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.84857177734375,
					47.450775146484375
				]
			]
		},
		{
			"type": "line",
			"version": 77,
			"versionNonce": 190121117,
			"isDeleted": false,
			"id": "77mL4Ems8uNQ8HUd1YBOJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -522.0137634277344,
			"y": -1.3783187866210938,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.316650390625,
			"height": 46.004425048828125,
			"seed": 849531262,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203919007,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.316650390625,
					46.004425048828125
				]
			]
		},
		{
			"type": "line",
			"version": 62,
			"versionNonce": 1268290621,
			"isDeleted": false,
			"id": "10sr3dqA-pDH2DRzz0VKb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -560.3628845214844,
			"y": -0.6749801635742188,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.75738525390625,
			"height": 45.86322021484375,
			"seed": 288465662,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203915270,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.75738525390625,
					45.86322021484375
				]
			]
		},
		{
			"type": "line",
			"version": 35,
			"versionNonce": 249850109,
			"isDeleted": false,
			"id": "xCZ20RRZ3mlklnE1exS6_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -486.4588928222656,
			"y": -1.7292098999023438,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 1.0269775390625,
			"height": 48.220977783203125,
			"seed": 508047998,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203921595,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.0269775390625,
					48.220977783203125
				]
			]
		},
		{
			"type": "line",
			"version": 33,
			"versionNonce": 1856864893,
			"isDeleted": false,
			"id": "8Qdju7uSrqDPXnLD6wjch",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -380.5028610229492,
			"y": -2.2084579467773438,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 48.516265869140625,
			"seed": 985462462,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203929341,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					48.516265869140625
				]
			]
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 619477139,
			"isDeleted": false,
			"id": "kZZSdUxDND8rkc8pKEk_H",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -414.7114562988281,
			"y": -1.6735763549804688,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.29949951171875,
			"height": 46.95440673828125,
			"seed": 562345058,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203926966,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.29949951171875,
					46.95440673828125
				]
			]
		},
		{
			"type": "line",
			"version": 69,
			"versionNonce": 1379019485,
			"isDeleted": false,
			"id": "fWapGngCTyv_pu43NuL8k",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -341.5177917480469,
			"y": -2.0073471069335938,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 1.2452392578125,
			"height": 48.409271240234375,
			"seed": 1759416866,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203931838,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.2452392578125,
					48.409271240234375
				]
			]
		},
		{
			"type": "text",
			"version": 417,
			"versionNonce": 928026931,
			"isDeleted": false,
			"id": "5JDaTXTt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -584.1362992336601,
			"y": 8.563271055888677,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 272.940673828125,
			"height": 27.45839951983472,
			"seed": 1078782370,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "1O6bDBGxnapj5AZYD7iks",
					"type": "arrow"
				}
			],
			"updated": 1685203913186,
			"link": null,
			"locked": false,
			"fontSize": 21.966719615867778,
			"fontFamily": 1,
			"text": "b1 b2 b3 b4 b5 b6 b7 b8",
			"rawText": "b1 b2 b3 b4 b5 b6 b7 b8",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "b1 b2 b3 b4 b5 b6 b7 b8",
			"lineHeight": 1.25,
			"baseline": 19
		},
		{
			"type": "arrow",
			"version": 143,
			"versionNonce": 2114506814,
			"isDeleted": false,
			"id": "nW3g-Ru04Gqg2qK0jJd-V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -322.3466491699219,
			"y": 61.20197296142578,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 35.7431640625,
			"height": 66.4071044921875,
			"seed": 1943108350,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682159199366,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "VxKZleHx",
				"focus": 0.16606204029456037,
				"gap": 4.878173828125
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					1.77581787109375,
					66.4071044921875
				],
				[
					35.7431640625,
					65.96636962890625
				]
			]
		},
		{
			"type": "arrow",
			"version": 197,
			"versionNonce": 508517054,
			"isDeleted": false,
			"id": "fqj_qN5KBdj1dR70lpjvH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -359.1125183105469,
			"y": 61.32178497314453,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 65.2474365234375,
			"height": 133.38330078125,
			"seed": 1642493118,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682159242290,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "JSNAHDjW",
				"focus": 0.14601061792555614,
				"gap": 9.778800964355469
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.44500732421875,
					133.38330078125
				],
				[
					65.2474365234375,
					132.36697448930425
				]
			]
		},
		{
			"type": "text",
			"version": 98,
			"versionNonce": 1608112802,
			"isDeleted": false,
			"id": "VxKZleHx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -281.7253112792969,
			"y": 105.65735626220703,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 110.75990295410156,
			"height": 50,
			"seed": 1331561314,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "nW3g-Ru04Gqg2qK0jJd-V",
					"type": "arrow"
				}
			],
			"updated": 1682159199366,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "0: unicast\n1: multicast",
			"rawText": "0: unicast\n1: multicast",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "0: unicast\n1: multicast",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "text",
			"version": 114,
			"versionNonce": 972297314,
			"isDeleted": false,
			"id": "JSNAHDjW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -284.0862808227539,
			"y": 171.62500762939453,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 83.71994018554688,
			"height": 50,
			"seed": 1331561314,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "fqj_qN5KBdj1dR70lpjvH",
					"type": "arrow"
				}
			],
			"updated": 1682159242289,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "0: global\n1: local",
			"rawText": "0: global\n1: local",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "0: global\n1: local",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 90,
			"versionNonce": 741208787,
			"isDeleted": false,
			"id": "1O6bDBGxnapj5AZYD7iks",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -304.691162109375,
			"y": 22.17548845349354,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 26.889739990234375,
			"height": 2.2234611443158983,
			"seed": 1921002594,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685203913187,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "5JDaTXTt",
				"focus": 0.4710093800327696,
				"gap": 6.504463296160111
			},
			"endBinding": {
				"elementId": "WdVT04ZI",
				"focus": 0.2626100196398436,
				"gap": 3.47039794921875
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					26.889739990234375,
					-2.2234611443158983
				]
			]
		},
		{
			"type": "text",
			"version": 72,
			"versionNonce": 1640894206,
			"isDeleted": false,
			"id": "WdVT04ZI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -274.3310241699219,
			"y": -2.2354049682617188,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 113.67987060546875,
			"height": 50,
			"seed": 844816738,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "1O6bDBGxnapj5AZYD7iks",
					"type": "arrow"
				}
			],
			"updated": 1682159230536,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "bit menos\nsignificativo",
			"rawText": "bit menos\nsignificativo",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "bit menos\nsignificativo",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "text",
			"version": 115,
			"versionNonce": 547382078,
			"isDeleted": false,
			"id": "6shlVNsC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -347.8451843261719,
			"y": -282.0308151245117,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 101.159912109375,
			"height": 50,
			"seed": 592532222,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682159349307,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ID del\nfabricante",
			"rawText": "ID del\nfabricante",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ID del\nfabricante",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "text",
			"version": 136,
			"versionNonce": 690962850,
			"isDeleted": false,
			"id": "CyQJgdBB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.52120971679688,
			"y": -281.4616928100586,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 173.37985229492188,
			"height": 50,
			"seed": 757213182,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682159342391,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ID de tarjeta\no interfaz de red",
			"rawText": "ID de tarjeta\no interfaz de red",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ID de tarjeta\no interfaz de red",
			"lineHeight": 1.25,
			"baseline": 42
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#f08c00",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 774.5621032714844,
		"scrollY": 245.04825592041016,
		"zoom": {
			"value": 1.6
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%