---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
100 kHz ^6yGcjmR0

100 kHz ^e4yX0JXE

100 kHz ^e4MzDaXo

100 kHz ^2J0PjAx9

100 kHz ^y8zZ0jGq

Guard band
of 10 kHz ^p6o9dSUF

540 kHz ^qFOJOqpi

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"id": "Q8V1OTK0YWsndhrQpX6WS",
			"type": "line",
			"x": -408.8858362731172,
			"y": -167.4047899342813,
			"width": 118.64863954741384,
			"height": 0.45740587957973844,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 716226086,
			"version": 50,
			"versionNonce": 1836126522,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681749487225,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					118.64863954741384,
					-0.45740587957973844
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 224,
			"versionNonce": 579060922,
			"isDeleted": false,
			"id": "zUNo7ioUJcrft3Nr35sjp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.4760126955442,
			"y": -166.62939622537988,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 118.64863954741384,
			"height": 0.45740587957973844,
			"seed": 514457062,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749537891,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					118.64863954741384,
					-0.45740587957973844
				]
			]
		},
		{
			"id": "lKZFiA_1qPxwIHmjxCfLo",
			"type": "line",
			"x": -427.1513619258486,
			"y": -69.44919217866038,
			"width": 817.4417114257812,
			"height": 3.179351806640625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 267672634,
			"version": 335,
			"versionNonce": 1717862886,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681749959539,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					817.4417114257812,
					3.179351806640625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 845,
			"versionNonce": 25786234,
			"isDeleted": false,
			"id": "jUqXnJuM8DsLWIDrNCt6m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -250.73511169075465,
			"y": -70.04149348376856,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 122.45114733257888,
			"height": 0.8352622660037645,
			"seed": 862650982,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749959540,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					122.45114733257888,
					0.8352622660037645
				]
			]
		},
		{
			"type": "line",
			"version": 216,
			"versionNonce": 1046173094,
			"isDeleted": false,
			"id": "R2rdDQi6Rf4M_Z5Xkn2ua",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.08076733483493,
			"y": -167.98135720192835,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 117.74266736260785,
			"height": 0.26266163793104624,
			"seed": 1899264742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749567758,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					117.74266736260785,
					0.26266163793104624
				]
			]
		},
		{
			"type": "line",
			"version": 417,
			"versionNonce": 581875834,
			"isDeleted": false,
			"id": "Ik_SFHo7zym644sGfA5eA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.98672899327694,
			"y": -167.43316160051617,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 118.64863954741384,
			"height": 0.45740587957973844,
			"seed": 1183944314,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749570240,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					118.64863954741384,
					-0.45740587957973844
				]
			]
		},
		{
			"type": "line",
			"version": 507,
			"versionNonce": 2037388026,
			"isDeleted": false,
			"id": "sczjmP7J91RFz220ALBAm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 241.09050625865314,
			"y": -167.67806079587302,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 118.64863954741384,
			"height": 0.45740587957973844,
			"seed": 789750822,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749576052,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					118.64863954741384,
					-0.45740587957973844
				]
			]
		},
		{
			"id": "iNJyXCFFHg7_PJvAH1QxN",
			"type": "line",
			"x": -409.6294970355094,
			"y": -176.79606655106443,
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 596259238,
			"version": 40,
			"versionNonce": 1150390778,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681749582948,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 112,
			"versionNonce": 1135137722,
			"isDeleted": false,
			"id": "YKitVJcmDXTskrY0_Oy2q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -288.64859149353975,
			"y": -175.5694502787897,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 802856102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749593540,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 40,
			"versionNonce": 1150390778,
			"isDeleted": false,
			"id": "kYDr9nQ6Ra_6KfgEV5mGh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.14436533513452,
			"y": -177.59198698406985,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 1187699942,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749595956,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 67,
			"versionNonce": 2004160250,
			"isDeleted": false,
			"id": "xP9eqzWFDbO45-PThw_xO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -130.6481032122897,
			"y": -177.3945277302983,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 92949626,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749602328,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 52,
			"versionNonce": 700746810,
			"isDeleted": false,
			"id": "3PTfZkaK6-uJiliQr4hFK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.60781159052254,
			"y": -177.29278843881124,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 828568998,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749608442,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 40,
			"versionNonce": 1150390778,
			"isDeleted": false,
			"id": "-DaE6-5QzY1ZQRK7zd_2N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.234945009693035,
			"y": -177.59198698406985,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 734325862,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749610932,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 40,
			"versionNonce": 1150390778,
			"isDeleted": false,
			"id": "07mtS8hUdAj-cO5LgnOmk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 80.51080707865862,
			"y": -177.59198698406985,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 278590714,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749615257,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 49,
			"versionNonce": 2013128678,
			"isDeleted": false,
			"id": "zvRBcHaeTF_4n54FnfLuh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 201.64631354417577,
			"y": -177.76315902744267,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 309751718,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749621197,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 65,
			"versionNonce": 2143611706,
			"isDeleted": false,
			"id": "DiN8O8KXxDpxDp7I4bjRI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 239.41596265516708,
			"y": -176.95993637119278,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 2099343738,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749625105,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"type": "line",
			"version": 40,
			"versionNonce": 1150390778,
			"isDeleted": false,
			"id": "RBNS8Eep3LOuL0kiAcKWE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 358.4418415614171,
			"y": -177.59198698406985,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3570767106680819,
			"height": 18.639105435075436,
			"seed": 2076048742,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681749627239,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.3570767106680819,
					18.639105435075436
				]
			]
		},
		{
			"id": "6yGcjmR0",
			"type": "text",
			"x": -386.28047696546633,
			"y": -196.00768175176484,
			"width": 75.13995361328125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 258516730,
			"version": 100,
			"versionNonce": 214111354,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681749654923,
			"link": null,
			"locked": false,
			"text": "100 kHz",
			"rawText": "100 kHz",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "100 kHz",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 160,
			"versionNonce": 1002482810,
			"isDeleted": false,
			"id": "e4yX0JXE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -229.5681009299734,
			"y": -195.7111561254179,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 75.13995361328125,
			"height": 25,
			"seed": 1142559590,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681749662799,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "100 kHz",
			"rawText": "100 kHz",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "100 kHz",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 146,
			"versionNonce": 681565818,
			"isDeleted": false,
			"id": "e4MzDaXo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -66.0387114499087,
			"y": -196.03127499664632,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 75.13995361328125,
			"height": 25,
			"seed": 1598681126,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681749666339,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "100 kHz",
			"rawText": "100 kHz",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "100 kHz",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 144,
			"versionNonce": 464525242,
			"isDeleted": false,
			"id": "2J0PjAx9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 101.07205262606124,
			"y": -197.04260648910326,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 75.13995361328125,
			"height": 25,
			"seed": 414113318,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681749670822,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "100 kHz",
			"rawText": "100 kHz",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "100 kHz",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 117,
			"versionNonce": 756991526,
			"isDeleted": false,
			"id": "y8zZ0jGq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 257.8932575021387,
			"y": -196.03026475957736,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 75.13995361328125,
			"height": 25,
			"seed": 1221187814,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681749674114,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "100 kHz",
			"rawText": "100 kHz",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "100 kHz",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "Y_NiXarRU5ZHNwAgqb5KJ",
			"type": "line",
			"x": -411.5680948271256,
			"y": -69.85500125607516,
			"width": 123.00364832642806,
			"height": 54.919812432650815,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 472246950,
			"version": 1091,
			"versionNonce": 139116646,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750141138,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					106.50788534236393,
					0.622684873383605
				],
				[
					121.23600659509506,
					-1.9181876346982563
				],
				[
					123.00364832642806,
					-28.566515692349185
				],
				[
					100.34696935386764,
					-53.19340146821122
				],
				[
					24.16976515947244,
					-54.29712755926721
				],
				[
					3.827522339614456,
					-30.99234745420256
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": [
				3.083874932650872,
				-3.163557381465523
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 1186,
			"versionNonce": 1935033062,
			"isDeleted": false,
			"id": "nFv94nggdYrhEvQdfi8MV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.37921897864499,
			"y": -70.52300695532584,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 123.00364832642806,
			"height": 54.919812432650815,
			"seed": 261460518,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681750197122,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					106.50788534236393,
					0.622684873383605
				],
				[
					121.23600659509506,
					-1.9181876346982563
				],
				[
					123.00364832642806,
					-28.566515692349185
				],
				[
					100.34696935386764,
					-53.19340146821122
				],
				[
					24.16976515947244,
					-54.29712755926721
				],
				[
					3.827522339614456,
					-30.99234745420256
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1179,
			"versionNonce": 983103014,
			"isDeleted": false,
			"id": "g4zlPLz4ECq2Q78YN12x6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -90.89697389513213,
			"y": -69.10446573765347,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 123.00364832642806,
			"height": 54.919812432650815,
			"seed": 692938938,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681750201980,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					106.50788534236393,
					0.622684873383605
				],
				[
					121.23600659509506,
					-1.9181876346982563
				],
				[
					123.00364832642806,
					-28.566515692349185
				],
				[
					100.34696935386764,
					-53.19340146821122
				],
				[
					24.16976515947244,
					-54.29712755926721
				],
				[
					3.827522339614456,
					-30.99234745420256
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1190,
			"versionNonce": 1168327014,
			"isDeleted": false,
			"id": "9v7HXo0MymleHqAB8kiK0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 79.40466605637636,
			"y": -67.91103901351566,
			"strokeColor": "#ffffff",
			"backgroundColor": "#4c6ef5",
			"width": 123.00364832642806,
			"height": 54.919812432650815,
			"seed": 901347494,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681750206818,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					106.50788534236393,
					0.622684873383605
				],
				[
					121.23600659509506,
					-1.9181876346982563
				],
				[
					123.00364832642806,
					-28.566515692349185
				],
				[
					100.34696935386764,
					-53.19340146821122
				],
				[
					24.16976515947244,
					-54.29712755926721
				],
				[
					3.827522339614456,
					-30.99234745420256
				],
				[
					0,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 1199,
			"versionNonce": 1740776614,
			"isDeleted": false,
			"id": "jn7Saq1E2pICdTZAkSDPp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 238.13707109409125,
			"y": -66.13721004665159,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"width": 123.00364832642806,
			"height": 54.919812432650815,
			"seed": 122684346,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681750217925,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					106.50788534236393,
					0.622684873383605
				],
				[
					121.23600659509506,
					-1.9181876346982563
				],
				[
					123.00364832642806,
					-28.566515692349185
				],
				[
					100.34696935386764,
					-53.19340146821122
				],
				[
					24.16976515947244,
					-54.29712755926721
				],
				[
					3.827522339614456,
					-30.99234745420256
				],
				[
					0,
					0
				]
			]
		},
		{
			"id": "v2JJ4INh2GD0wMHWZLVzt",
			"type": "arrow",
			"x": -271.4506002208581,
			"y": -233.0811859327618,
			"width": 0.7819733728100573,
			"height": 62.68142543148372,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 44212198,
			"version": 365,
			"versionNonce": 57145062,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750279846,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.7819733728100573,
					62.68142543148372
				]
			],
			"lastCommittedPoint": [
				0.39875167681321955,
				79.99988692710565
			],
			"startBinding": {
				"elementId": "p6o9dSUF",
				"focus": 0.007147573677257188,
				"gap": 10.209259825656147
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "p6o9dSUF",
			"type": "text",
			"x": -328.8177434027137,
			"y": -293.29044575841795,
			"width": 114.679931640625,
			"height": 50,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 292843494,
			"version": 159,
			"versionNonce": 36793318,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "v2JJ4INh2GD0wMHWZLVzt",
					"type": "arrow"
				}
			],
			"updated": 1681750273167,
			"link": null,
			"locked": false,
			"text": "Guard band\nof 10 kHz",
			"rawText": "Guard band\nof 10 kHz",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 42,
			"containerId": null,
			"originalText": "Guard band\nof 10 kHz",
			"lineHeight": 1.25
		},
		{
			"id": "a7hugDdiispHR9XyIkzaU",
			"type": "line",
			"x": -412.68988195397276,
			"y": -23.093118272484105,
			"width": 778.7728309234939,
			"height": 3.956362318581,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1179920934,
			"version": 130,
			"versionNonce": 1941742394,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750295205,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					778.7728309234939,
					3.956362318581
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "GC4wfnY1Qgjpp7Md3L40f",
			"type": "line",
			"x": -410.90883325994673,
			"y": -34.589994867461655,
			"width": 0.6512733409250586,
			"height": 23.250761600351268,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 775800166,
			"version": 32,
			"versionNonce": 695332666,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750304884,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.6512733409250586,
					23.250761600351268
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "uez_tLXwJQl24Os0Jdf3x",
			"type": "line",
			"x": 365.98980158891527,
			"y": -31.546337852876434,
			"width": 1.6393686212186367,
			"height": 23.255248346635483,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1381185894,
			"version": 46,
			"versionNonce": 655818874,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750308755,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.6393686212186367,
					23.255248346635483
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "qFOJOqpi",
			"type": "text",
			"x": -83.6966197219275,
			"y": 1.3317174013241129,
			"width": 81.11993408203125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 976411686,
			"version": 45,
			"versionNonce": 2145221050,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681750332033,
			"link": null,
			"locked": false,
			"text": "540 kHz",
			"rawText": "540 kHz",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "540 kHz",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 732.126785358987,
		"scrollY": 506.31333122713306,
		"zoom": {
			"value": 0.9658438028785691
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%