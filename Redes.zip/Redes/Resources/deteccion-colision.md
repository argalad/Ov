---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^C8aSRN8h

B ^0WVk9BO1

A comienza a transmitir ^RwEuS10t

t = t ^LHhHlYxL

0 ^yqzPJTyg

A ^c8GMFmMx

B ^VmkyLjsf

B comienza a transmitir ^afxueJ4c

t = t + T - A ^Cm8j6wyJ

0 ^jBFgShYq

P ^aDnI8DgG

t ^K2JWvPwM

A ^xKuZlwdg

B ^kNO57HSO

B detecta colisión ^4nvrzyUJ

t = t + T ^wwlpsjAW

0 ^ghjeSCqe

P ^tv4SpAvG

A ^mexTzbus

B ^rGZJZwb1

A detecta colisión ^mefWL2H2

t = t + 2T ^WjXuqwUr

0 ^BoB2eCB2

P ^QlMg4qMF

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 353,
			"versionNonce": 547662701,
			"isDeleted": false,
			"id": "lQm_kX8CKEFH1HiJSxfjP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -168.78054316048997,
			"y": -71.39401703312686,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"Yn4nGmDHBczgsdCZmMb4S"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982674806,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 349,
			"versionNonce": 702533091,
			"isDeleted": false,
			"id": "C8aSRN8h",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -150.9218090296306,
			"y": -60.595722965744045,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"Yn4nGmDHBczgsdCZmMb4S"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 563,
			"versionNonce": 1060550093,
			"isDeleted": false,
			"id": "ChQk5tPQkaH9A7hg0MMze",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 65.02922113598436,
			"y": -71.8956889300941,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"8Y2GixmVEe5RG3Zm_1sCc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982674806,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 498,
			"versionNonce": 2098338179,
			"isDeleted": false,
			"id": "0WVk9BO1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 82.72114618481248,
			"y": -60.81153670841441,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"8Y2GixmVEe5RG3Zm_1sCc"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 147,
			"versionNonce": 668496941,
			"isDeleted": false,
			"id": "rzaCw0a8pfqHIydj0r89e",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -179.5924923669686,
			"y": -105.85870883062351,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"seed": 213195002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			]
		},
		{
			"id": "qgzR95ojeCUFjWPcPGZRb",
			"type": "line",
			"x": -143.8036791042869,
			"y": -106.22321485485892,
			"width": 0.40261907080395076,
			"height": 34.12727822667887,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1300570093,
			"version": 193,
			"versionNonce": 926544163,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.40261907080395076,
					34.12727822667887
				]
			],
			"lastCommittedPoint": [
				-0.5455255830982821,
				34.123258352915315
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "rlWs4ONMNHqttITURPsMS",
			"type": "line",
			"x": 90.6182743226783,
			"y": -72.39589099440124,
			"width": 0.726678322914438,
			"height": 33.75888550963319,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1068155117,
			"version": 78,
			"versionNonce": 1718838925,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.726678322914438,
					-33.75888550963319
				]
			],
			"lastCommittedPoint": [
				0.726678322914438,
				-33.75888550963319
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "RwEuS10t",
			"type": "text",
			"x": -143.53016867840978,
			"y": -188.1146148418162,
			"width": 234.4398193359375,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 919875875,
			"version": 361,
			"versionNonce": 846672493,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982743068,
			"link": null,
			"locked": false,
			"text": "A comienza a transmitir",
			"rawText": "A comienza a transmitir",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "A comienza a transmitir",
			"lineHeight": 1.25
		},
		{
			"id": "LHhHlYxL",
			"type": "text",
			"x": -214.31438970743878,
			"y": -157.22534887325648,
			"width": 54.939971923828125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 277700387,
			"version": 61,
			"versionNonce": 1304497389,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"text": "t = t",
			"rawText": "t = t",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "t = t",
			"lineHeight": 1.25
		},
		{
			"id": "yqzPJTyg",
			"type": "text",
			"x": -158.47633319479408,
			"y": -144.50888020963026,
			"width": 6.2126312255859375,
			"height": 11.29715481164176,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 2000320973,
			"version": 209,
			"versionNonce": 877937763,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"text": "0",
			"rawText": "0",
			"fontSize": 9.037723849313409,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 8,
			"containerId": null,
			"originalText": "0",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 642,
			"versionNonce": 817576365,
			"isDeleted": false,
			"id": "o6xugknoyr_GsuG0ghjwz",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -168.69270797141206,
			"y": 128.3804723086896,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"2i25ipxgu72nqeIjwQ5Fl"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 638,
			"versionNonce": 921715619,
			"isDeleted": false,
			"id": "c8GMFmMx",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -150.8339738405527,
			"y": 139.17876637607242,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"2i25ipxgu72nqeIjwQ5Fl"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 852,
			"versionNonce": 568425485,
			"isDeleted": false,
			"id": "HfcG2Cg1-0cjhO0Qb037R",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 65.11705632506226,
			"y": 127.87880041172235,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"o98mdMWfCdkxgIxf_RppP"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 787,
			"versionNonce": 68015939,
			"isDeleted": false,
			"id": "VmkyLjsf",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 82.80898137389039,
			"y": 138.96295263340204,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"o98mdMWfCdkxgIxf_RppP"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 436,
			"versionNonce": 1842377325,
			"isDeleted": false,
			"id": "Wqxvn9qLVSZ823-82CCFH",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -179.5046571778907,
			"y": 93.91578051119293,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"seed": 213195002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			]
		},
		{
			"type": "line",
			"version": 482,
			"versionNonce": 1803024099,
			"isDeleted": false,
			"id": "it_F2eoNOw2AKZ7YXZDo5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -143.715843915209,
			"y": 93.55127448695752,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.40261907080395076,
			"height": 34.12727822667887,
			"seed": 1300570093,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.40261907080395076,
					34.12727822667887
				]
			]
		},
		{
			"type": "line",
			"version": 367,
			"versionNonce": 558996685,
			"isDeleted": false,
			"id": "rFO5Bi7DjxB6BfRKmAahy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 90.70610951175621,
			"y": 127.3785983474152,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.726678322914438,
			"height": 33.75888550963319,
			"seed": 1068155117,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.726678322914438,
					-33.75888550963319
				]
			]
		},
		{
			"type": "text",
			"version": 729,
			"versionNonce": 1008392781,
			"isDeleted": false,
			"id": "afxueJ4c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -144.83125968404528,
			"y": 2.9432344155510464,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 235.8598175048828,
			"height": 25,
			"seed": 919875875,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982656401,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B comienza a transmitir",
			"rawText": "B comienza a transmitir",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B comienza a transmitir",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "PxMGdJr4fY9jcOSxtvgIw",
			"type": "arrow",
			"x": -141.9617022146243,
			"y": -116.51207942653456,
			"width": 32.09709282751737,
			"height": 0.6180053427243593,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1837447277,
			"version": 332,
			"versionNonce": 491448141,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982674806,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					32.09709282751737,
					-0.6180053427243593
				]
			],
			"lastCommittedPoint": [
				22.78774553729795,
				-0.6180053427243593
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "arrow",
			"version": 274,
			"versionNonce": 765188643,
			"isDeleted": false,
			"id": "yskVQAzeU5IyvvkkziSv3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 87.10277986291413,
			"y": 78.54181480269014,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 29.92706634327112,
			"height": 1.2147061591235229,
			"seed": 264010883,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-29.92706634327112,
					1.2147061591235229
				]
			]
		},
		{
			"id": "eCD5D53XabAreSgslqI4a",
			"type": "arrow",
			"x": -150.37579844647098,
			"y": 79.26565238947957,
			"width": 163.2491399143372,
			"height": 0.7250902081675434,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 129088355,
			"version": 202,
			"versionNonce": 1849724301,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					163.2491399143372,
					-0.7250902081675434
				]
			],
			"lastCommittedPoint": [
				156.03366848968057,
				-1.9929098450498657
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "text",
			"version": 848,
			"versionNonce": 2114100675,
			"isDeleted": false,
			"id": "Cm8j6wyJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -211.71875394808632,
			"y": 36.25319968705449,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 121.03041076660156,
			"height": 20.890928594913337,
			"seed": 277700387,
			"groupIds": [
				"MJQbiRXig3HgX3vIcqIhv"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 16.71274287593067,
			"fontFamily": 1,
			"text": "t = t + T - A",
			"rawText": "t = t + T - A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "t = t + T - A",
			"lineHeight": 1.25,
			"baseline": 15
		},
		{
			"type": "text",
			"version": 994,
			"versionNonce": 1330729965,
			"isDeleted": false,
			"id": "jBFgShYq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -164.5564118620531,
			"y": 48.85243716715185,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 5.1943817138671875,
			"height": 9.440322179827584,
			"seed": 2000320973,
			"groupIds": [
				"MJQbiRXig3HgX3vIcqIhv"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 7.552257743862067,
			"fontFamily": 1,
			"text": "0",
			"rawText": "0",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "0",
			"lineHeight": 1.25,
			"baseline": 6
		},
		{
			"type": "text",
			"version": 1028,
			"versionNonce": 135261539,
			"isDeleted": false,
			"id": "aDnI8DgG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -129.14558275037015,
			"y": 48.47309249804147,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 4.99053955078125,
			"height": 9.440322179827586,
			"seed": 2000320973,
			"groupIds": [
				"MJQbiRXig3HgX3vIcqIhv"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 7.552257743862069,
			"fontFamily": 1,
			"text": "P",
			"rawText": "P",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "P",
			"lineHeight": 1.25,
			"baseline": 6
		},
		{
			"type": "text",
			"version": 1004,
			"versionNonce": 859459149,
			"isDeleted": false,
			"id": "K2JWvPwM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -88.67440132622488,
			"y": 47.81587365986307,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 4.2657318115234375,
			"height": 9.440322179827584,
			"seed": 2000320973,
			"groupIds": [
				"MJQbiRXig3HgX3vIcqIhv"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982034759,
			"link": null,
			"locked": false,
			"fontSize": 7.552257743862067,
			"fontFamily": 1,
			"text": "t",
			"rawText": "t",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "t",
			"lineHeight": 1.25,
			"baseline": 6
		},
		{
			"type": "rectangle",
			"version": 590,
			"versionNonce": 760490669,
			"isDeleted": false,
			"id": "PwMhC1XsGFX85IFhgRB9W",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -169.0040662043974,
			"y": 328.66123315488124,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"7Xzg52Kwsphx8_9ZVFGEK"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 586,
			"versionNonce": 559604387,
			"isDeleted": false,
			"id": "xKuZlwdg",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -151.14533207353801,
			"y": 339.45952722226406,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"7Xzg52Kwsphx8_9ZVFGEK"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 800,
			"versionNonce": 1614040333,
			"isDeleted": false,
			"id": "uIRsbLIkm7hxQ6ZRDvAuj",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 64.80569809207694,
			"y": 328.15956125791405,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"Wi1-JZ0tn4FasfGtC2ZR3"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 735,
			"versionNonce": 634164803,
			"isDeleted": false,
			"id": "kNO57HSO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 82.49762314090506,
			"y": 339.24371347959374,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"Wi1-JZ0tn4FasfGtC2ZR3"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 384,
			"versionNonce": 1537287021,
			"isDeleted": false,
			"id": "dtQ27GeII8sh_z97fXSeh",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -179.81601541087602,
			"y": 294.1965413573846,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"seed": 213195002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			]
		},
		{
			"type": "line",
			"version": 430,
			"versionNonce": 84334051,
			"isDeleted": false,
			"id": "dXgsUH4ELi7x1wNKyPcD_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -144.02720214819433,
			"y": 293.83203533314924,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.40261907080395076,
			"height": 34.12727822667887,
			"seed": 1300570093,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.40261907080395076,
					34.12727822667887
				]
			]
		},
		{
			"type": "line",
			"version": 315,
			"versionNonce": 1407462861,
			"isDeleted": false,
			"id": "Tc4ikGt6HeqETlfU5jkl6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 90.39475127877088,
			"y": 327.6593591936069,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.726678322914438,
			"height": 33.75888550963319,
			"seed": 1068155117,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.726678322914438,
					-33.75888550963319
				]
			]
		},
		{
			"type": "text",
			"version": 627,
			"versionNonce": 1847075203,
			"isDeleted": false,
			"id": "4nvrzyUJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -127.33857738481598,
			"y": 208.34211394210888,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 180.19984436035156,
			"height": 25,
			"seed": 919875875,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B detecta colisión",
			"rawText": "B detecta colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B detecta colisión",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 414,
			"versionNonce": 941026349,
			"isDeleted": false,
			"id": "wwlpsjAW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -218.9540035657619,
			"y": 239.97297650174235,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 103.51995849609375,
			"height": 25,
			"seed": 277700387,
			"groupIds": [
				"-PcSiyOvz1elqBRhSQdTr"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "t = t + T",
			"rawText": "t = t + T",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "t = t + T",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 557,
			"versionNonce": 708770083,
			"isDeleted": false,
			"id": "ghjeSCqe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.1159470531172,
			"y": 252.88092701567749,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 6.2126312255859375,
			"height": 11.29715481164176,
			"seed": 2000320973,
			"groupIds": [
				"-PcSiyOvz1elqBRhSQdTr"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 9.037723849313409,
			"fontFamily": 1,
			"text": "0",
			"rawText": "0",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "0",
			"lineHeight": 1.25,
			"baseline": 8
		},
		{
			"type": "text",
			"version": 603,
			"versionNonce": 1478680205,
			"isDeleted": false,
			"id": "tv4SpAvG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -118.34883970551678,
			"y": 251.81972771350914,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 5.9688262939453125,
			"height": 11.29715481164176,
			"seed": 2000320973,
			"groupIds": [
				"-PcSiyOvz1elqBRhSQdTr"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"fontSize": 9.037723849313409,
			"fontFamily": 1,
			"text": "P",
			"rawText": "P",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "P",
			"lineHeight": 1.25,
			"baseline": 8
		},
		{
			"type": "arrow",
			"version": 509,
			"versionNonce": 1458166979,
			"isDeleted": false,
			"id": "9BhfvQyI2Tx30PraG1Zej",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -152.17286059646563,
			"y": 281.8267659274943,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 195.2436892530468,
			"height": 0.764604744404096,
			"seed": 129088355,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					195.2436892530468,
					-0.764604744404096
				]
			]
		},
		{
			"type": "arrow",
			"version": 347,
			"versionNonce": 1254196461,
			"isDeleted": false,
			"id": "BsWOELkgOgpw-GNND0jUb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 95.29761919377137,
			"y": 280.8587554971574,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 44.02016520689881,
			"height": 1.6189335789120491,
			"seed": 264010883,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-44.02016520689881,
					1.6189335789120491
				]
			]
		},
		{
			"id": "nRxgN2HRn_5iLeX0dRLA7",
			"type": "line",
			"x": 34.74865111565879,
			"y": 267.31047493435824,
			"width": 30.027907729728298,
			"height": 32.70156759213356,
			"angle": 0,
			"strokeColor": "#ff0000",
			"backgroundColor": "#ffff00",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 677326595,
			"version": 2079,
			"versionNonce": 1605848163,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982697127,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					8.98020087972965,
					12.157852768049286
				],
				[
					-1.0007349133541639,
					14.123131694500799
				],
				[
					10.049909773653518,
					15.426852985109164
				],
				[
					-1.2120311721437922,
					24.62433485304638
				],
				[
					10.623635992854261,
					18.666290964573992
				],
				[
					13.920039718769509,
					29.864823618858342
				],
				[
					14.911984138468917,
					18.445516714567535
				],
				[
					27.769661304440323,
					27.324256452096083
				],
				[
					17.164370234653695,
					15.28302260857304
				],
				[
					28.24508050293534,
					11.348572653120943
				],
				[
					16.584009285718288,
					12.44627863529784
				],
				[
					28.815876557584506,
					2.3252263362687065
				],
				[
					14.723428049574288,
					10.589812251051955
				],
				[
					12.480564988182149,
					-2.8367439732752158
				],
				[
					11.629509159047092,
					11.650216144980638
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": [
				0.1732310332430984,
				-0.29483089516668315
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "rectangle",
			"version": 710,
			"versionNonce": 666140653,
			"isDeleted": false,
			"id": "p7xn07ZzrxAH9ggiBX8Rs",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -169.9866862506129,
			"y": 528.1048682828233,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"s4UtaUW6A_SShbjLrgEt2"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 706,
			"versionNonce": 1002799459,
			"isDeleted": false,
			"id": "mexTzbus",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -152.12795211975353,
			"y": 538.9031623502061,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"s4UtaUW6A_SShbjLrgEt2"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 920,
			"versionNonce": 1851259469,
			"isDeleted": false,
			"id": "72JzxxiRlncWhUfHe_M4x",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 63.82307804586142,
			"y": 527.603196385856,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"u2yUZELwM2TVWjEZGXR1G"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 855,
			"versionNonce": 1056267523,
			"isDeleted": false,
			"id": "rGZJZwb1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.51500309468955,
			"y": 538.6873486075357,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"u2yUZELwM2TVWjEZGXR1G"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 504,
			"versionNonce": 1532831917,
			"isDeleted": false,
			"id": "vpEjPYVWK7sLL0FvKeG6F",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -180.79863545709154,
			"y": 493.6401764853266,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"seed": 213195002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			]
		},
		{
			"type": "line",
			"version": 550,
			"versionNonce": 1927857315,
			"isDeleted": false,
			"id": "NGS_k2IxgHpBNQjZ3patl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -145.00982219440985,
			"y": 493.2756704610912,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.40261907080395076,
			"height": 34.12727822667887,
			"seed": 1300570093,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.40261907080395076,
					34.12727822667887
				]
			]
		},
		{
			"type": "line",
			"version": 435,
			"versionNonce": 544049933,
			"isDeleted": false,
			"id": "g2tkgzL9AsdNj_ZZVN2yf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 89.41213123255537,
			"y": 527.1029943215489,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.726678322914438,
			"height": 33.75888550963319,
			"seed": 1068155117,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.726678322914438,
					-33.75888550963319
				]
			]
		},
		{
			"type": "text",
			"version": 832,
			"versionNonce": 256784451,
			"isDeleted": false,
			"id": "mefWL2H2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -125.89275498353138,
			"y": 411.5757631622202,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 178.77984619140625,
			"height": 25,
			"seed": 919875875,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A detecta colisión",
			"rawText": "A detecta colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A detecta colisión",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 537,
			"versionNonce": 2114101613,
			"isDeleted": false,
			"id": "WjXuqwUr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.55365991135946,
			"y": 439.4166116296843,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 117.75994873046875,
			"height": 25,
			"seed": 277700387,
			"groupIds": [
				"leMWyM734NxSerr_I2eEs"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "t = t + 2T",
			"rawText": "t = t + 2T",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "t = t + 2T",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 678,
			"versionNonce": 1376008163,
			"isDeleted": false,
			"id": "BoB2eCB2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.9070852490237,
			"y": 452.32456214361935,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 6.2126312255859375,
			"height": 11.29715481164176,
			"seed": 2000320973,
			"groupIds": [
				"leMWyM734NxSerr_I2eEs"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 9.037723849313409,
			"fontFamily": 1,
			"text": "0",
			"rawText": "0",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "0",
			"lineHeight": 1.25,
			"baseline": 8
		},
		{
			"type": "text",
			"version": 724,
			"versionNonce": 1768287181,
			"isDeleted": false,
			"id": "QlMg4qMF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -119.1399779014233,
			"y": 451.2633628414511,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 5.9688262939453125,
			"height": 11.29715481164176,
			"seed": 2000320973,
			"groupIds": [
				"leMWyM734NxSerr_I2eEs"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982884051,
			"link": null,
			"locked": false,
			"fontSize": 9.037723849313409,
			"fontFamily": 1,
			"text": "P",
			"rawText": "P",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "P",
			"lineHeight": 1.25,
			"baseline": 8
		},
		{
			"type": "arrow",
			"version": 782,
			"versionNonce": 858257891,
			"isDeleted": false,
			"id": "xnC8iij-BNMbG7kkC3Ti6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -153.15548064268117,
			"y": 481.2704010554363,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.55970773244735,
			"height": 0.7706738997229081,
			"seed": 129088355,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982904177,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					37.55970773244735,
					-0.7706738997229081
				]
			]
		},
		{
			"type": "arrow",
			"version": 593,
			"versionNonce": 897124355,
			"isDeleted": false,
			"id": "Pw44vzVHaJqm9C5AUfXYm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 94.31499914755585,
			"y": 480.3023906250993,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 188.15501758487505,
			"height": 2.998777716201971,
			"seed": 264010883,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681982916556,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-188.15501758487505,
					2.998777716201971
				]
			]
		},
		{
			"type": "line",
			"version": 2270,
			"versionNonce": 523804675,
			"isDeleted": false,
			"id": "aciJp7cte_bJutNnpf8kK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -120.30424532099875,
			"y": 469.5411312113692,
			"strokeColor": "#ff0000",
			"backgroundColor": "#ffff00",
			"width": 30.027907729728298,
			"height": 32.70156759213356,
			"seed": 677326595,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982910177,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					8.98020087972965,
					12.157852768049286
				],
				[
					-1.0007349133541639,
					14.123131694500799
				],
				[
					10.049909773653518,
					15.426852985109164
				],
				[
					-1.2120311721437922,
					24.62433485304638
				],
				[
					10.623635992854261,
					18.666290964573992
				],
				[
					13.920039718769509,
					29.864823618858342
				],
				[
					14.911984138468917,
					18.445516714567535
				],
				[
					27.769661304440323,
					27.324256452096083
				],
				[
					17.164370234653695,
					15.28302260857304
				],
				[
					28.24508050293534,
					11.348572653120943
				],
				[
					16.584009285718288,
					12.44627863529784
				],
				[
					28.815876557584506,
					2.3252263362687065
				],
				[
					14.723428049574288,
					10.589812251051955
				],
				[
					12.480564988182149,
					-2.8367439732752158
				],
				[
					11.629509159047092,
					11.650216144980638
				],
				[
					0,
					0
				]
			]
		},
		{
			"id": "veWUHkkId7wA1yurL1Ess",
			"type": "line",
			"x": -259.377679928467,
			"y": -12.579026594368145,
			"width": 453.2570476805709,
			"height": 0.17931102633924922,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 30,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1871290125,
			"version": 283,
			"versionNonce": 1050954477,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681982947743,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					453.2570476805709,
					0.17931102633924922
				]
			],
			"lastCommittedPoint": [
				453.2570476805709,
				0.17931102633924922
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 283,
			"versionNonce": 1961546509,
			"isDeleted": false,
			"id": "vF9IiIMvHpkFGY7YhrAaz",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 30,
			"angle": 0,
			"x": -260.10672416552046,
			"y": 189.64129623019812,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 453.2570476805709,
			"height": 0.17931102633924922,
			"seed": 1871290125,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982942894,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					453.2570476805709,
					0.17931102633924922
				]
			]
		},
		{
			"type": "line",
			"version": 285,
			"versionNonce": 301629837,
			"isDeleted": false,
			"id": "s_2dsuewnw37bLB0n2gbt",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dotted",
			"roughness": 1,
			"opacity": 30,
			"angle": 0,
			"x": -259.3964595887796,
			"y": 391.35643602445987,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 453.2570476805709,
			"height": 0.17931102633924922,
			"seed": 1871290125,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681982936889,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					453.2570476805709,
					0.17931102633924922
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "dotted",
		"currentItemRoughness": 1,
		"currentItemOpacity": 30,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 618.5097095718456,
		"scrollY": 224.31831824776077,
		"zoom": {
			"value": 0.9314318486342489
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%