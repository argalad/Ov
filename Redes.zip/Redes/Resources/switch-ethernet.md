---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^8cHVGHQP

B ^7ShYU0GD

C ^1ukm7DoB

D ^dTDfIyfn

E ^JL6NhCOD

F ^cykIXMKe

G ^eyNWa2IA

H ^QugMg4uL

SWITCH ^DBJ2665C

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 468,
			"versionNonce": 303392073,
			"isDeleted": false,
			"id": "0atNWSx1Yo_U7LE1XUnXD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.12442901247653,
			"y": -199.23887337110938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 467,
			"versionNonce": 832919977,
			"isDeleted": false,
			"id": "8cHVGHQP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -145.26569488161715,
			"y": -188.44057930372657,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"BxeWMruWHVJoFY-zRi_Uw"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "EdMynwi6xZXVjYc1OFIzI",
					"type": "arrow"
				}
			],
			"updated": 1681839433007,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 697,
			"versionNonce": 1856754729,
			"isDeleted": false,
			"id": "g8njt6eGEM6nZfetlhbey",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.5301195280332,
			"y": -177.54377550356347,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 579,
			"versionNonce": 29990631,
			"isDeleted": false,
			"id": "7ShYU0GD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -257.9374681608457,
			"y": -167.79255480043847,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"QjBo4G8yiBfBo1YtZvMta"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 494,
			"versionNonce": 1893845705,
			"isDeleted": false,
			"id": "9QQv9xTMwqBx70XP3FFGy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -303.7997524988046,
			"y": -98.18439567945899,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 134709178,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "-uRADn7H4ha1c6VeVenJa",
					"type": "arrow"
				}
			],
			"updated": 1681839560674,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 451,
			"versionNonce": 1696803335,
			"isDeleted": false,
			"id": "1ukm7DoB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -285.9410183679452,
			"y": -87.38610161207617,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 557021306,
			"groupIds": [
				"QUE0h17YcrDbzbbArIHOX"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 875,
			"versionNonce": 1367449065,
			"isDeleted": false,
			"id": "TqTYr8Lb6qb742AAzMfHT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -276.74223152869916,
			"y": -16.8643859237838,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 2113728742,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 826,
			"versionNonce": 1840632073,
			"isDeleted": false,
			"id": "dTDfIyfn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -259.0834709478026,
			"y": -5.271062162359158,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.599990844726562,
			"height": 25,
			"seed": 1480188966,
			"groupIds": [
				"N8ZD54asP7x1sZ3Memq7L"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "PnzT4miGj-0g04MW0rMOz",
					"type": "arrow"
				}
			],
			"updated": 1681839641783,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "D",
			"rawText": "D",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "D",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 802,
			"versionNonce": 1402280585,
			"isDeleted": false,
			"id": "QfL3aMtIcZpsXYB8En2wk",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -162.12843322753912,
			"y": 2.9664083354906836,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 687,
			"versionNonce": 2015112553,
			"isDeleted": false,
			"id": "JL6NhCOD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -143.4009857177735,
			"y": 12.717629038615684,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WUehu1uk_Yp2TktJwt476"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "PrEkF8zUUvw3uoKd2wd2l",
					"type": "arrow"
				}
			],
			"updated": 1681839547831,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "E",
			"rawText": "E",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "E",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 764,
			"versionNonce": 1761796457,
			"isDeleted": false,
			"id": "O2eyk_XNs0cPNV9l8anx8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -41.43675231933601,
			"y": -19.293464101032754,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414111,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 648,
			"versionNonce": 449365993,
			"isDeleted": false,
			"id": "cykIXMKe",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -22.84410095214851,
			"y": -9.542243397907725,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.479995727539062,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"ZoCpfUzQrmMquxPOlooso"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "PnzT4miGj-0g04MW0rMOz",
					"type": "arrow"
				}
			],
			"updated": 1681839641783,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "F",
			"rawText": "F",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "F",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 776,
			"versionNonce": 1643501607,
			"isDeleted": false,
			"id": "VmP7mQAmboW-fWIBZn_iT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.605636596679744,
			"y": -98.9905771381421,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839501871,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 660,
			"versionNonce": 1055111367,
			"isDeleted": false,
			"id": "eyNWa2IA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1.9870147705077557,
			"y": -89.10883275337648,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.779998779296875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"F6fjgYDXS_gLU-q2Ie6hG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681839414112,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "G",
			"rawText": "G",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "G",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 843,
			"versionNonce": 1558600489,
			"isDeleted": false,
			"id": "WA1W0JDtX2O2H6_q1MjoU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.04969787597661,
			"y": -175.8696054584546,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681839414112,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 729,
			"versionNonce": 1543674407,
			"isDeleted": false,
			"id": "QugMg4uL",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -20.457046508789112,
			"y": -166.1183847553296,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 11.019989013671875,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"WJzmInvOpTHVk3_a_Mv-e"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "Fhikf_dduNGUfRHjH564z",
					"type": "arrow"
				}
			],
			"updated": 1681839479796,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "H",
			"rawText": "H",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "H",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 187,
			"versionNonce": 1684910057,
			"isDeleted": false,
			"id": "k6-We4Qiwqwi0_jz1Iat-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -211.9999662762578,
			"y": -119.50788321361011,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 154,
			"height": 87,
			"seed": 1741061127,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "DBJ2665C"
				},
				{
					"id": "TavgFI1UlOU46BO1nrp0P",
					"type": "arrow"
				},
				{
					"id": "EdMynwi6xZXVjYc1OFIzI",
					"type": "arrow"
				},
				{
					"id": "xBLf_NZvU_-kH7LG70qCQ",
					"type": "arrow"
				},
				{
					"id": "vEptADTC6CCXrbqOBLXdO",
					"type": "arrow"
				},
				{
					"id": "cnJbgka64E1SOT308avUI",
					"type": "arrow"
				},
				{
					"id": "-uRADn7H4ha1c6VeVenJa",
					"type": "arrow"
				}
			],
			"updated": 1681839560674,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 50,
			"versionNonce": 1527593577,
			"isDeleted": false,
			"id": "DBJ2665C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -173.97993911561326,
			"y": -88.50788321361011,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 77.95994567871094,
			"height": 25,
			"seed": 1339016393,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681839598392,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SWITCH",
			"rawText": "SWITCH",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "k6-We4Qiwqwi0_jz1Iat-",
			"originalText": "SWITCH",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 197,
			"versionNonce": 323533991,
			"isDeleted": false,
			"id": "TavgFI1UlOU46BO1nrp0P",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -228.0670883412566,
			"y": -129.09334654718828,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 21.19454821245975,
			"height": 15.235766220541052,
			"seed": 1489442727,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839601142,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"gap": 18.709182739257812,
				"focus": 0.23837504094019923
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					7.15487536089725,
					2.7429836277676145
				],
				[
					21.19454821245975,
					15.235766220541052
				]
			]
		},
		{
			"type": "arrow",
			"version": 253,
			"versionNonce": 808191305,
			"isDeleted": false,
			"id": "EdMynwi6xZXVjYc1OFIzI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.65327132996873,
			"y": -154.47035803660816,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 7.507659912109375,
			"height": 33.93098449707031,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839601142,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "8cHVGHQP",
				"focus": 0.6649990700287836,
				"gap": 8.970221267118404
			},
			"endBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"gap": 1.0314903259277344,
				"focus": 0.1752743104164815
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					3.8148193359375,
					11.369522094726562
				],
				[
					-3.692840576171875,
					21.4959716796875
				],
				[
					1.55975341796875,
					33.93098449707031
				]
			]
		},
		{
			"type": "arrow",
			"version": 465,
			"versionNonce": 111875657,
			"isDeleted": false,
			"id": "Fhikf_dduNGUfRHjH564z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -36.24216940404403,
			"y": -134.58972989238868,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.32867431640625,
			"height": 22.253372192382812,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839484162,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QugMg4uL",
				"focus": -0.3662606196168135,
				"gap": 15.785122895254915
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-9.83758544921875,
					6.0977020263671875
				],
				[
					-15.47528076171875,
					16.008056640625
				],
				[
					-24.32867431640625,
					22.253372192382812
				]
			]
		},
		{
			"type": "arrow",
			"version": 731,
			"versionNonce": 1014534087,
			"isDeleted": false,
			"id": "xBLf_NZvU_-kH7LG70qCQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.526563022702497,
			"y": -77.86861478008396,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 40.31317138671876,
			"height": 5.808868408203125,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839601142,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"gap": 1.16023186683654,
				"focus": -0.16859918631674015
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-14.95751953125,
					-2.554595947265625
				],
				[
					-24.1639404296875,
					3.2542724609375
				],
				[
					-40.31317138671876,
					1.5212249755859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 1057,
			"versionNonce": 1357804585,
			"isDeleted": false,
			"id": "vEptADTC6CCXrbqOBLXdO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -40.023741704375254,
			"y": -24.041627449351942,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.898207060514757,
			"height": 12.35463567777623,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839601142,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"gap": 19.87013176918029,
				"focus": 0.4266614933204755
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-5.799879423796007,
					-1.5157227139090423
				],
				[
					-16.240797392546007,
					-0.5122742275809173
				],
				[
					-23.898207060514757,
					-12.35463567777623
				]
			]
		},
		{
			"type": "arrow",
			"version": 300,
			"versionNonce": 1893098119,
			"isDeleted": false,
			"id": "PrEkF8zUUvw3uoKd2wd2l",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.888939889459,
			"y": -32.65889798320896,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 7.507659912109375,
			"height": 33.93098449707031,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839547831,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "JL6NhCOD",
				"focus": 0.8690887937486218,
				"gap": 11.44554252475433
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					3.8148193359375,
					11.369522094726562
				],
				[
					-3.692840576171875,
					21.4959716796875
				],
				[
					1.55975341796875,
					33.93098449707031
				]
			]
		},
		{
			"type": "arrow",
			"version": 593,
			"versionNonce": 2049868007,
			"isDeleted": false,
			"id": "cnJbgka64E1SOT308avUI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -204.84666189965563,
			"y": -38.0708242527402,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 23.65572567279125,
			"height": 23.122023385537794,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839672302,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"focus": -0.18335337575928226,
				"gap": 17.559082346407706
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-9.83758544921875,
					6.0977020263671875
				],
				[
					-15.47528076171875,
					16.008056640625
				],
				[
					-23.65572567279125,
					23.122023385537794
				]
			]
		},
		{
			"type": "arrow",
			"version": 789,
			"versionNonce": 1363150601,
			"isDeleted": false,
			"id": "-uRADn7H4ha1c6VeVenJa",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -212.9999662762578,
			"y": -76.76013787718838,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.66902228355406,
			"height": 5.808868408203125,
			"seed": 470465543,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681839601143,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "k6-We4Qiwqwi0_jz1Iat-",
				"gap": 1,
				"focus": -0.221874422115816
			},
			"endBinding": {
				"elementId": "9QQv9xTMwqBx70XP3FFGy",
				"focus": -0.0817129962168848,
				"gap": 1.099758079617743
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-14.313370428085307,
					-2.444581670838218
				],
				[
					-23.519791326522807,
					3.364286737364907
				],
				[
					-39.66902228355406,
					1.6312392520133443
				]
			]
		},
		{
			"id": "PnzT4miGj-0g04MW0rMOz",
			"type": "arrow",
			"x": -250.80158675965623,
			"y": -16.914968632311286,
			"width": 235.60626220703125,
			"height": 43.70013427734375,
			"angle": 0,
			"strokeColor": "#00fffb",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1743686151,
			"version": 754,
			"versionNonce": 2071396809,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681839663700,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					20.971771240234375,
					-35.129119873046875
				],
				[
					67.2479248046875,
					-43.70013427734375
				],
				[
					111.64126586914062,
					-43.051849365234375
				],
				[
					160.76513671875,
					-42.777984619140625
				],
				[
					202.9697265625,
					-30.989105224609375
				],
				[
					233.76202392578125,
					-21.3333740234375
				],
				[
					235.60626220703125,
					-3.684295654296875
				]
			],
			"lastCommittedPoint": [
				235.60626220703125,
				-3.684295654296875
			],
			"startBinding": {
				"elementId": "dTDfIyfn",
				"focus": -0.9128199181771844,
				"gap": 11.643906469952128
			},
			"endBinding": {
				"elementId": "cykIXMKe",
				"focus": 0.6202458878220927,
				"gap": 11.057020888700436
			},
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#00fffb",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 454.2680632000859,
		"scrollY": 253.18570151194996,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%