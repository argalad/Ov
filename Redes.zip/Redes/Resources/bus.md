---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^8cHVGHQP

B ^7ShYU0GD

C ^1ukm7DoB

D ^dTDfIyfn

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 71,
			"versionNonce": 2032953673,
			"isDeleted": false,
			"id": "0atNWSx1Yo_U7LE1XUnXD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -217.66129424685153,
			"y": -95.03677070997657,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681833980491,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 351,
			"versionNonce": 1959850537,
			"isDeleted": false,
			"id": "g8njt6eGEM6nZfetlhbey",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -146.5080553190488,
			"y": 22.154588754249033,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834010584,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 65,
			"versionNonce": 1682069545,
			"isDeleted": false,
			"id": "8cHVGHQP",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -199.80256011599215,
			"y": -84.23847664259375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681833980491,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 284,
			"versionNonce": 848126183,
			"isDeleted": false,
			"id": "7ShYU0GD",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -128.81613027022067,
			"y": 33.23874097592872,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834010584,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 154,
			"versionNonce": 410479369,
			"isDeleted": false,
			"id": "9QQv9xTMwqBx70XP3FFGy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -74.3981411706796,
			"y": -95.12696159742774,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 134709178,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681833980492,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 416,
			"versionNonce": 818541065,
			"isDeleted": false,
			"id": "TqTYr8Lb6qb742AAzMfHT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -1.5223523783085398,
			"y": 16.715722718794325,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 2113728742,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681834028419,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 151,
			"versionNonce": 1850155497,
			"isDeleted": false,
			"id": "1ukm7DoB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.53940703982022,
			"y": -84.32866753004492,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 557021306,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681833980492,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 366,
			"versionNonce": 1398112391,
			"isDeleted": false,
			"id": "dTDfIyfn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 16.13640820258803,
			"y": 28.309046480218967,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 15.599990844726562,
			"height": 25,
			"seed": 1480188966,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681834034462,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "D",
			"rawText": "D",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "D",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 97,
			"versionNonce": 582810825,
			"isDeleted": false,
			"id": "cUzI_qqQBdqC5KZsql3Jp",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -238.05935027712496,
			"y": -15.105790027603518,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 304.7862548828125,
			"height": 0.021392822265625,
			"seed": 213195002,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681833980492,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					304.7862548828125,
					0.021392822265625
				]
			]
		},
		{
			"type": "line",
			"version": 99,
			"versionNonce": 825544775,
			"isDeleted": false,
			"id": "L7eOq2jQ6O_9LTTR96oVO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.8379757654062,
			"y": -49.93754661940039,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.07061767578125,
			"height": 33.09228515625,
			"seed": 179889254,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681833980492,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.07061767578125,
					33.09228515625
				]
			]
		},
		{
			"type": "line",
			"version": 147,
			"versionNonce": 1134889383,
			"isDeleted": false,
			"id": "DWwMr5ET0xN-4BzFb8le6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -120.78528119564007,
			"y": -14.942869562331198,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.776641845703125,
			"height": 35.569854736328125,
			"seed": 1732116966,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834004785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.776641845703125,
					35.569854736328125
				]
			]
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 1457598311,
			"isDeleted": false,
			"id": "F_1IHui4-hCjGgpSPrRuC",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -49.29186370485928,
			"y": -49.43473900221289,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.6461181640625,
			"height": 33.2056884765625,
			"seed": 2008008422,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681833980492,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.6461181640625,
					33.2056884765625
				]
			]
		},
		{
			"type": "line",
			"version": 177,
			"versionNonce": 302080039,
			"isDeleted": false,
			"id": "tK1fcQSbH88XcRypT34HT",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": 23.04410502732362,
			"y": -16.13432653088566,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.35302734375,
			"height": 32.165863037109375,
			"seed": 207788006,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681834023286,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.35302734375,
					32.165863037109375
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 252.87470035453583,
		"scrollY": 181.0686553489781,
		"zoom": {
			"value": 2.712717131422297
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%