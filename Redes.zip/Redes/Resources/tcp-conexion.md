---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Cliente
(conexión activa) ^6wGYbTU5

Servidor
(conexión pasiva) ^SmpBEj2Z

Envío de segmento (SYN)
(SEQ = X) ^S47q7Ir2

Envío de segmento (ACK)
(SEQ=X+1, ACK=y+1) ^10CcRiAt

Envío de segmento (SYN, ACK)
(SEQ=y, ACK=x+1) ^uc8FAv8Y

SYN ^abURTrR7

SYN + ACK ^sjkfUIpo

ACK ^yhi5qZ2n

Conexión Establecida ^Iv4Hs8R5

Mensajes en la red ^s7HmcFJs

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "line",
			"version": 247,
			"versionNonce": 1000356240,
			"isDeleted": false,
			"id": "RYilpKBTbSbtrkUbOgmV2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.5585708618164,
			"y": -176.51368713378906,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 4.6354217529296875,
			"height": 304.4302978515625,
			"seed": 1458263440,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.6354217529296875,
					304.4302978515625
				]
			]
		},
		{
			"type": "line",
			"version": 244,
			"versionNonce": 2026235760,
			"isDeleted": false,
			"id": "JDOStvwAsw3WCHHD5Ij2I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.30470954235177,
			"y": -175.68969236794393,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 4.6354217529296875,
			"height": 304.4302978515625,
			"seed": 1937621360,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.6354217529296875,
					304.4302978515625
				]
			]
		},
		{
			"type": "text",
			"version": 137,
			"versionNonce": 1283622800,
			"isDeleted": false,
			"id": "6wGYbTU5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -215.75191497802734,
			"y": -233.2180938720703,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 165.35986328125,
			"height": 50,
			"seed": 847250320,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Cliente\n(conexión activa)",
			"rawText": "Cliente\n(conexión activa)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cliente\n(conexión activa)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 202,
			"versionNonce": 410483056,
			"isDeleted": false,
			"id": "SmpBEj2Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 0.907440185546875,
			"y": -230.6373748779297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.73985290527344,
			"height": 50,
			"seed": 1660513680,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Servidor\n(conexión pasiva)",
			"rawText": "Servidor\n(conexión pasiva)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Servidor\n(conexión pasiva)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 68,
			"versionNonce": 1743459728,
			"isDeleted": false,
			"id": "S47q7Ir2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -335.33292388916016,
			"y": -155.39842224121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 192.4158935546875,
			"height": 40,
			"seed": 428913552,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "FIwLGyJ_gJZJbl7pvEsAU",
					"type": "arrow"
				}
			],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Envío de segmento (SYN)\n(SEQ = X)",
			"rawText": "Envío de segmento (SYN)\n(SEQ = X)",
			"textAlign": "right",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Envío de segmento (SYN)\n(SEQ = X)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 157,
			"versionNonce": 893870448,
			"isDeleted": false,
			"id": "10CcRiAt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.17374420166016,
			"y": 47.03059387207031,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 194.7358856201172,
			"height": 40,
			"seed": 2078676336,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "XtegPDH1pRM4JfrrFGwgv",
					"type": "arrow"
				}
			],
			"updated": 1685617850714,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Envío de segmento (ACK)\n(SEQ=X+1, ACK=y+1)",
			"rawText": "Envío de segmento (ACK)\n(SEQ=X+1, ACK=y+1)",
			"textAlign": "right",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Envío de segmento (ACK)\n(SEQ=X+1, ACK=y+1)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 454,
			"versionNonce": 978995568,
			"isDeleted": false,
			"id": "uc8FAv8Y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 85.42171478271484,
			"y": -64.42835998535156,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 235.1358642578125,
			"height": 40,
			"seed": 1772521360,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "FIwLGyJ_gJZJbl7pvEsAU",
					"type": "arrow"
				},
				{
					"id": "cyxRkKD0EyDsqf8vJsK7o",
					"type": "arrow"
				}
			],
			"updated": 1685617861199,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Envío de segmento (SYN, ACK)\n(SEQ=y, ACK=x+1)",
			"rawText": "Envío de segmento (SYN, ACK)\n(SEQ=y, ACK=x+1)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Envío de segmento (SYN, ACK)\n(SEQ=y, ACK=x+1)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "arrow",
			"version": 267,
			"versionNonce": 758094704,
			"isDeleted": false,
			"id": "FIwLGyJ_gJZJbl7pvEsAU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.0468521118164,
			"y": -137.2785767325697,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 214.1929523270852,
			"height": 59.79589060282541,
			"seed": 120972176,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "abURTrR7"
				}
			],
			"updated": 1685617861200,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "S47q7Ir2",
				"focus": -0.6780663395924144,
				"gap": 10.87017822265625
			},
			"endBinding": {
				"elementId": "uc8FAv8Y",
				"focus": -0.012899468865701246,
				"gap": 13.459014892578125
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					214.1929523270852,
					59.79589060282541
				]
			]
		},
		{
			"type": "text",
			"version": 10,
			"versionNonce": 741274000,
			"isDeleted": false,
			"id": "abURTrR7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.937591552734375,
			"y": -117.69694519042969,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 28.287979125976562,
			"height": 20,
			"seed": 1155390864,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "SYN",
			"rawText": "SYN",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "FIwLGyJ_gJZJbl7pvEsAU",
			"originalText": "SYN",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 298,
			"versionNonce": 360193936,
			"isDeleted": false,
			"id": "XtegPDH1pRM4JfrrFGwgv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -136.2063904388668,
			"y": 52.502519143191165,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 212.50650024414062,
			"height": 59.208984375,
			"seed": 1989346672,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "yhi5qZ2n"
				}
			],
			"updated": 1685617850714,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "10CcRiAt",
				"focus": -0.9029985419854438,
				"gap": 3.231468142676164
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					212.50650024414062,
					59.208984375
				]
			]
		},
		{
			"type": "text",
			"version": 11,
			"versionNonce": 712654736,
			"isDeleted": false,
			"id": "yhi5qZ2n",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -45.25712591249962,
			"y": 72.10701133069117,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 30.60797119140625,
			"height": 20,
			"seed": 803752304,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792563,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "ACK",
			"rawText": "ACK",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "XtegPDH1pRM4JfrrFGwgv",
			"originalText": "ACK",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 289,
			"versionNonce": 868094864,
			"isDeleted": false,
			"id": "cyxRkKD0EyDsqf8vJsK7o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 77.606156284255,
			"y": -51.766591728073934,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 212.50650024414062,
			"height": 59.030188752124474,
			"seed": 717133712,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "sjkfUIpo"
				}
			],
			"updated": 1685617861200,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "uc8FAv8Y",
				"focus": 0.8007759727216851,
				"gap": 7.815558498459865
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-212.50650024414062,
					59.030188752124474
				]
			]
		},
		{
			"type": "text",
			"version": 76,
			"versionNonce": 506187152,
			"isDeleted": false,
			"id": "sjkfUIpo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -71.09506899650674,
			"y": -32.34089516344946,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 84.89595031738281,
			"height": 20,
			"seed": 926345616,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792563,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "SYN + ACK",
			"rawText": "SYN + ACK",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "cyxRkKD0EyDsqf8vJsK7o",
			"originalText": "SYN + ACK",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 82,
			"versionNonce": 1687760272,
			"isDeleted": false,
			"id": "Iv4Hs8R5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -133.3756332397461,
			"y": 143.07814025878906,
			"strokeColor": "#2f9e44",
			"backgroundColor": "transparent",
			"width": 204.75982666015625,
			"height": 25,
			"seed": 31092624,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617881345,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Conexión Establecida",
			"rawText": "Conexión Establecida",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Conexión Establecida",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 92,
			"versionNonce": 1734974352,
			"isDeleted": false,
			"id": "s7HmcFJs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -99.1425552368164,
			"y": -165.72071838378906,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 150.367919921875,
			"height": 20,
			"seed": 909576592,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617908296,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Mensajes en la red",
			"rawText": "Mensajes en la red",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Mensajes en la red",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 111,
			"versionNonce": 706793872,
			"isDeleted": false,
			"id": "Q8hft3CaNnvtTAHkvOBz9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -191.40614227967347,
			"y": -165.23877086968943,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"seed": 1554294160,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633175249,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 164,
			"versionNonce": 2135623056,
			"isDeleted": false,
			"id": "GlwaLE6x-hZzdV84V0sWT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 230.7207040338031,
			"y": -76.78987446160838,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 95.13001641664675,
			"height": 41.646181876097614,
			"seed": 1328553872,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633195120,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 153,
			"versionNonce": 1255899536,
			"isDeleted": false,
			"id": "5mdGwMXuPGr5YdVP4wXgp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.63408188538637,
			"y": 37.261219593567404,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"seed": 1760809872,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633226424,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#f08c00",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 374.3737564086914,
		"scrollY": 246.96206665039062,
		"zoom": {
			"value": 1.6
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%