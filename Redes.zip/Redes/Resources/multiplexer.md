---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
MUX ^8CFDhQkh

DEMUX ^F8zro1tt

1 link, n channels ^Qua4T5HG

n outputs ^PsuQYRbX

n inputs ^KJq4WlUe

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "line",
			"version": 347,
			"versionNonce": 648068070,
			"isDeleted": false,
			"id": "jDEHIphrcvLDKE7H67C9C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -322.8439016047421,
			"y": -274.0599145502733,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 235.88012497394578,
			"height": 4.538036212772113,
			"seed": 430916070,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					235.88012497394578,
					4.538036212772113
				]
			]
		},
		{
			"type": "line",
			"version": 232,
			"versionNonce": 2133357606,
			"isDeleted": false,
			"id": "W00oJsdSNlnVEYduT3wPc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -379.46158006350953,
			"y": -342.2166519861218,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3680419921875,
			"height": 133.61865234375,
			"seed": 756504570,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3680419921875,
					133.61865234375
				]
			]
		},
		{
			"type": "line",
			"version": 172,
			"versionNonce": 1021626682,
			"isDeleted": false,
			"id": "lHZS19qw3jBP_c6jM6bSH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -379.1399581866338,
			"y": -209.4581070642468,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 54.62677001953125,
			"height": 40.612762451171875,
			"seed": 1619831526,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					54.62677001953125,
					-40.612762451171875
				]
			]
		},
		{
			"type": "line",
			"version": 275,
			"versionNonce": 127074150,
			"isDeleted": false,
			"id": "0wYQF0UmlysN1wdJssnwL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -379.02869109679006,
			"y": -338.2841568689343,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.02935791015625,
			"height": 36.432098388671875,
			"seed": 282694374,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					52.02935791015625,
					36.432098388671875
				]
			]
		},
		{
			"type": "line",
			"version": 170,
			"versionNonce": 782995962,
			"isDeleted": false,
			"id": "HbpRqixWgJEVuxNnQtIMb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -324.5643310097151,
			"y": -301.10482230045034,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.59478759765625,
			"height": 52.65838623046875,
			"seed": 1186434234,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.59478759765625,
					52.65838623046875
				]
			]
		},
		{
			"type": "line",
			"version": 172,
			"versionNonce": 285876902,
			"isDeleted": false,
			"id": "dt5AmZkQ6omoepvl84D64",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -427.5745858429595,
			"y": -318.4910365250844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 450067834,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 234,
			"versionNonce": 1981498042,
			"isDeleted": false,
			"id": "7oRB91nFftSDd0Rb38UGp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -427.5084902772667,
			"y": -302.83071022155247,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1147164218,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 217,
			"versionNonce": 2117787110,
			"isDeleted": false,
			"id": "BVmolznamj917yd6vH0Cb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -426.7201975885434,
			"y": -290.89026277359255,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 321318458,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 232,
			"versionNonce": 1037491066,
			"isDeleted": false,
			"id": "zze93djDTeGSh4-sVyNcI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.08783117118065,
			"y": -279.8769426965068,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1218997542,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 232,
			"versionNonce": 1412575526,
			"isDeleted": false,
			"id": "UD0grVlufOmxp3Eh057Jf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.0875862511264,
			"y": -267.5402320951456,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 93946342,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 205,
			"versionNonce": 1679907898,
			"isDeleted": false,
			"id": "0HgpdlMjs_P5ltFXHtIJu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.00025475751556,
			"y": -251.90432590372097,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 580595366,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 240,
			"versionNonce": 1851595878,
			"isDeleted": false,
			"id": "I10rBjQcYMFWNXgmlLA_w",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.1668353829488,
			"y": -238.75544290835217,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 353033082,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "text",
			"version": 222,
			"versionNonce": 115197178,
			"isDeleted": false,
			"id": "8CFDhQkh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -367.37313155554864,
			"y": -283.61433333595426,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 33.0194091796875,
			"height": 19.866480381111476,
			"seed": 1572837818,
			"groupIds": [
				"iDDxvRzTi724F0P6iyhu_"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681748940524,
			"link": null,
			"locked": false,
			"fontSize": 15.89318430488918,
			"fontFamily": 1,
			"text": "MUX",
			"rawText": "MUX",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "MUX",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 392,
			"versionNonce": 1881952038,
			"isDeleted": false,
			"id": "O422vTzXOOA_Pk_5kVweT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -85.596114069546,
			"y": -299.1463853683938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.59478759765625,
			"height": 52.65838623046875,
			"seed": 832652794,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.59478759765625,
					52.65838623046875
				]
			]
		},
		{
			"type": "line",
			"version": 454,
			"versionNonce": 853548602,
			"isDeleted": false,
			"id": "MLC9zjRCEGXToUwUSU7dn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -31.382221653895556,
			"y": -337.4286063315084,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3680419921875,
			"height": 133.61865234375,
			"seed": 771412006,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3680419921875,
					133.61865234375
				]
			]
		},
		{
			"type": "line",
			"version": 254,
			"versionNonce": 23296614,
			"isDeleted": false,
			"id": "0STWhcN1rATVSm_yPsCtw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -85.51405984142383,
			"y": -248.46779822425714,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.51617788391502,
			"height": 42.61836368795997,
			"seed": 1603758694,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					52.51617788391502,
					42.61836368795997
				]
			]
		},
		{
			"type": "line",
			"version": 256,
			"versionNonce": 1416906490,
			"isDeleted": false,
			"id": "kJRnzutrdsYCk-W8PEtcA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -85.48208028006155,
			"y": -297.09357849585587,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 57.044399800229655,
			"height": 39.171883673876096,
			"seed": 406396794,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					57.044399800229655,
					-39.171883673876096
				]
			]
		},
		{
			"type": "line",
			"version": 417,
			"versionNonce": 286473638,
			"isDeleted": false,
			"id": "Q1a-VMeqhUK8ocPa8qA6c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -29.831567335187707,
			"y": -310.03225155819035,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1759207526,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 480,
			"versionNonce": 721770426,
			"isDeleted": false,
			"id": "xM3VeL3NYDaXO6hF6e9ab",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -28.820990063352063,
			"y": -294.6736317728502,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 760594682,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 463,
			"versionNonce": 1953011942,
			"isDeleted": false,
			"id": "kOanV9lkcrwa9IQGQhFIU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -29.56092853566107,
			"y": -281.49932957471344,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1285448614,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 464,
			"versionNonce": 1454788730,
			"isDeleted": false,
			"id": "QOcHBcg4jCeYL0eF7TxDz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -28.662001959599046,
			"y": -270.48600949762766,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 497521082,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 491,
			"versionNonce": 1391496230,
			"isDeleted": false,
			"id": "jJkW41Qr_LwMslTjKHuKo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -30.17039459624126,
			"y": -257.51644297051047,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 530513638,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 443,
			"versionNonce": 2068459834,
			"isDeleted": false,
			"id": "M3AHv7n7AbyDaV0Qpg_-F",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -29.61449605037202,
			"y": -242.51339270484192,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1828801146,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 475,
			"versionNonce": 1519916902,
			"isDeleted": false,
			"id": "nAMqxj4sp8slYB9RCKu1Q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -29.337071606124844,
			"y": -229.3645097094731,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1449800230,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "text",
			"version": 380,
			"versionNonce": 1277426170,
			"isDeleted": false,
			"id": "F8zro1tt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -83.55169039003744,
			"y": -276.9363095637454,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 49.695159912109375,
			"height": 17.598307444796674,
			"seed": 791510010,
			"groupIds": [
				"cN46jP62FYPKzxwAZUHBZ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"fontSize": 14.07864595583734,
			"fontFamily": 1,
			"text": "DEMUX",
			"rawText": "DEMUX",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DEMUX",
			"lineHeight": 1.25,
			"baseline": 12
		},
		{
			"type": "text",
			"version": 131,
			"versionNonce": 1940667046,
			"isDeleted": false,
			"id": "Qua4T5HG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -287.6752712052985,
			"y": -294.2186369225307,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 157.61990356445312,
			"height": 25,
			"seed": 300284966,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1 link, n channels",
			"rawText": "1 link, n channels",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1 link, n channels",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 38,
			"versionNonce": 407284410,
			"isDeleted": false,
			"id": "PsuQYRbX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.30333268697541,
			"y": -281.8285687379337,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 96.45989990234375,
			"height": 25,
			"seed": 104921658,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "n outputs",
			"rawText": "n outputs",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "n outputs",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 61,
			"versionNonce": 1960441318,
			"isDeleted": false,
			"id": "KJq4WlUe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -513.2896420847267,
			"y": -284.30362583991314,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 76.43992614746094,
			"height": 25,
			"seed": 461067770,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1681748927461,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "n inputs",
			"rawText": "n inputs",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "n inputs",
			"lineHeight": 1.25,
			"baseline": 17
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 533.9722551066565,
		"scrollY": 502.0971728441757,
		"zoom": {
			"value": 1.85
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%