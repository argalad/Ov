---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
MUX ^S3ahEEWN

DEMUX ^vSw3VdSx

1 ^xQHDcKYe

2 ^6FqqP7el

3 ^BkLmVUTM

4 ^pyXRaz2h

4 ^Q47fwLxO

3 ^1AHFFscV

2 ^J1iEbVBI

1 ^tCovtl7O

4 ^IjFc8cMY

3 ^EbnNwqI4

2 ^SxUDL3ss

1 ^hixpVbTM

Data flow ^QeDisy4J

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "line",
			"version": 291,
			"versionNonce": 1821275686,
			"isDeleted": false,
			"id": "Wc4Ewi8orwyIZNpPahhEK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -361.4372659540838,
			"y": -150.72336768983385,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3680419921875,
			"height": 133.61865234375,
			"seed": 592588922,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3680419921875,
					133.61865234375
				]
			]
		},
		{
			"type": "line",
			"version": 231,
			"versionNonce": 1113057082,
			"isDeleted": false,
			"id": "ApVwXFCpl6KWtfcs3lr4c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -361.11564407720806,
			"y": -17.96482276795885,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 54.62677001953125,
			"height": 40.612762451171875,
			"seed": 377662502,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					54.62677001953125,
					-40.612762451171875
				]
			]
		},
		{
			"type": "line",
			"version": 334,
			"versionNonce": 485015910,
			"isDeleted": false,
			"id": "GvHjm7BC_RLaqenVoEOXe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -361.0043769873643,
			"y": -146.79087257264635,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.02935791015625,
			"height": 36.432098388671875,
			"seed": 157946170,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					52.02935791015625,
					36.432098388671875
				]
			]
		},
		{
			"type": "line",
			"version": 229,
			"versionNonce": 336261114,
			"isDeleted": false,
			"id": "cSkAkI-N1fCH-SptHKn25",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -306.54001690028934,
			"y": -109.61153800416238,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.59478759765625,
			"height": 52.65838623046875,
			"seed": 652621670,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.59478759765625,
					52.65838623046875
				]
			]
		},
		{
			"type": "line",
			"version": 376,
			"versionNonce": 978822310,
			"isDeleted": false,
			"id": "M1jIyLsBY5KkNKWhJ28eM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -408.31929017345294,
			"y": -133.73952465399978,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1206815418,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "text",
			"version": 281,
			"versionNonce": 1943986362,
			"isDeleted": false,
			"id": "S3ahEEWN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -349.34881744612284,
			"y": -92.1210490396663,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 33.0194091796875,
			"height": 19.866480381111476,
			"seed": 240407654,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"fontSize": 15.89318430488918,
			"fontFamily": 1,
			"text": "MUX",
			"rawText": "MUX",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "MUX",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 548,
			"versionNonce": 1720197094,
			"isDeleted": false,
			"id": "p6VQuNjiTDnW9yxSOwlgq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -409.1721840268995,
			"y": -98.90491947119402,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 111679398,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 586,
			"versionNonce": 1031190906,
			"isDeleted": false,
			"id": "o3n_ZbY-YIJ1Vgc6pJlR-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -407.990935775157,
			"y": -67.35198202251357,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1955242170,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 514,
			"versionNonce": 92746534,
			"isDeleted": false,
			"id": "W1KIxJqFXyDAugt05Xpf0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -408.40455630028646,
			"y": -36.72337589051645,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 2096025958,
			"groupIds": [
				"ZFoMd3m4Zy3K9eg4ntQIQ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "rectangle",
			"version": 138,
			"versionNonce": 1612020282,
			"isDeleted": false,
			"id": "iQo_thWyEmZ83FxaDKwTH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.4412380342485,
			"y": -110.39407683635147,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 1072016934,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 174,
			"versionNonce": 1908530790,
			"isDeleted": false,
			"id": "nH6w-FbfquGnx45cGZRsT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -284.3449703340532,
			"y": -110.79444457316788,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 975779238,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 206,
			"versionNonce": 1788748538,
			"isDeleted": false,
			"id": "dJf25NJXy3wQqVSySnAMX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -260.2810054903032,
			"y": -110.68833495402725,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 1141784122,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 227,
			"versionNonce": 805642662,
			"isDeleted": false,
			"id": "0OQdbERbqpHGgyXQY7rFJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -236.8142391328813,
			"y": -110.17864562297257,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 1050944058,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 195,
			"versionNonce": 395555770,
			"isDeleted": false,
			"id": "zlhH2prwd1pb92t3Z3MbG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -213.26812707233444,
			"y": -109.53187133098038,
			"strokeColor": "#ffffff",
			"backgroundColor": "#be4bdb",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 2009557734,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 249,
			"versionNonce": 595459302,
			"isDeleted": false,
			"id": "BorDDLhj8hyrPAgC0i3M7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.52276574420944,
			"y": -108.81867553019913,
			"strokeColor": "#ffffff",
			"backgroundColor": "#be4bdb",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 124090042,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 354,
			"versionNonce": 1494822010,
			"isDeleted": false,
			"id": "mpucYh3xsEXmz5qfwyxI1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -142.31024133014694,
			"y": -106.36280394816788,
			"strokeColor": "#ffffff",
			"backgroundColor": "#be4bdb",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 94026682,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 287,
			"versionNonce": 1102671910,
			"isDeleted": false,
			"id": "ponfSXjtBO6aI3Oyts17a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -165.91583215045944,
			"y": -108.00596190715225,
			"strokeColor": "#ffffff",
			"backgroundColor": "#be4bdb",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 1129018598,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 334,
			"versionNonce": 1693551930,
			"isDeleted": false,
			"id": "2MZwHns3OsPM_qNeF0b09",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -117.92913781452194,
			"y": -106.92396117473038,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 1142887654,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 379,
			"versionNonce": 1185184614,
			"isDeleted": false,
			"id": "cGJSYXzMU3BvUAA_FbgPu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -94.43243371295944,
			"y": -107.42621947551163,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 525108134,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 388,
			"versionNonce": 1082119674,
			"isDeleted": false,
			"id": "YzLLNiGHPRpqjupXyWNZc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -70.91497765827194,
			"y": -106.85969115519913,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 245322490,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 420,
			"versionNonce": 1754013350,
			"isDeleted": false,
			"id": "dnqAMoZJEnS4L-00ZiZ3Q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -46.64770470905319,
			"y": -106.91744567180069,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 21.836151123046875,
			"height": 54.27372741699219,
			"seed": 814987258,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681759050507,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 507,
			"versionNonce": 1288111802,
			"isDeleted": false,
			"id": "eyHPbS2K_AlemyMgQTMfP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.821121750195168,
			"y": -105.40590211981868,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.59478759765625,
			"height": 52.65838623046875,
			"seed": 312034490,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.59478759765625,
					52.65838623046875
				]
			]
		},
		{
			"type": "line",
			"version": 569,
			"versionNonce": 203250150,
			"isDeleted": false,
			"id": "wzrFixOUzBLbIRKTy8XQT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 30.392770665455267,
			"y": -143.68812308293326,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3680419921875,
			"height": 133.61865234375,
			"seed": 1914043366,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3680419921875,
					133.61865234375
				]
			]
		},
		{
			"type": "line",
			"version": 369,
			"versionNonce": 1382686586,
			"isDeleted": false,
			"id": "GAEo7CgQOLFvpPxlHY6Ov",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.739067522073007,
			"y": -54.72731497568202,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.51617788391502,
			"height": 42.61836368795997,
			"seed": 1598332282,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					52.51617788391502,
					42.61836368795997
				]
			]
		},
		{
			"type": "line",
			"version": 371,
			"versionNonce": 2019896614,
			"isDeleted": false,
			"id": "6K6I7N0fJoEzofggRN0IJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.70708796071073,
			"y": -103.35309524728075,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 57.044399800229655,
			"height": 39.171883673876096,
			"seed": 452562726,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					57.044399800229655,
					-39.171883673876096
				]
			]
		},
		{
			"type": "line",
			"version": 532,
			"versionNonce": 229384250,
			"isDeleted": false,
			"id": "IJCnqqOoSzy1ImQsEUzpW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 31.943424984163137,
			"y": -116.29176830961524,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1451679290,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 595,
			"versionNonce": 181442662,
			"isDeleted": false,
			"id": "9yU6_mMscb65kCAbHubWC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.954002255998724,
			"y": -100.93314852427505,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1619573350,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 578,
			"versionNonce": 980420858,
			"isDeleted": false,
			"id": "4lth2cytdDl7dp68S9BOD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.214063783689774,
			"y": -87.75884632613833,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1430456058,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 579,
			"versionNonce": 1798085542,
			"isDeleted": false,
			"id": "IYHBUTEn_okZYaMOyga4l",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 33.11299035975174,
			"y": -76.74552624905255,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 1502641574,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 606,
			"versionNonce": 540596666,
			"isDeleted": false,
			"id": "wlIVd7ov8TwE366MQ4y1C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 31.604597723109585,
			"y": -63.77595972193535,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 603723706,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 558,
			"versionNonce": 1067857638,
			"isDeleted": false,
			"id": "pjQVEkSw0pkRlCW2WGTaE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.160496268978825,
			"y": -48.7729094562668,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 993908966,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "line",
			"version": 590,
			"versionNonce": 506040954,
			"isDeleted": false,
			"id": "IjNxBQGFSYmWJlOXGzVZy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 32.437920713226,
			"y": -35.624026460897994,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.99942364028129,
			"height": 0.4513351770166878,
			"seed": 47517818,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					46.99942364028129,
					0.4513351770166878
				]
			]
		},
		{
			"type": "text",
			"version": 495,
			"versionNonce": 1623878182,
			"isDeleted": false,
			"id": "vSw3VdSx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -21.776698070686614,
			"y": -83.19582631517028,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 49.695159912109375,
			"height": 17.598307444796674,
			"seed": 220056614,
			"groupIds": [
				"EPuJqvJk3I3c798F2rEop"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759050508,
			"link": null,
			"locked": false,
			"fontSize": 14.07864595583734,
			"fontFamily": 1,
			"text": "DEMUX",
			"rawText": "DEMUX",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DEMUX",
			"lineHeight": 1.25,
			"baseline": 12
		},
		{
			"id": "xQHDcKYe",
			"type": "text",
			"x": -229.00501256381108,
			"y": -94.65986716659262,
			"width": 5.4199981689453125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 384971258,
			"version": 700,
			"versionNonce": 1712691450,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759097085,
			"link": null,
			"locked": false,
			"text": "1",
			"rawText": "1",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"id": "6FqqP7el",
			"type": "text",
			"x": -255.69794469271733,
			"y": -94.67911612899496,
			"width": 14.239990234375,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 128932282,
			"version": 181,
			"versionNonce": 992656506,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759093735,
			"link": null,
			"locked": false,
			"text": "2",
			"rawText": "2",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "2",
			"lineHeight": 1.25
		},
		{
			"id": "BkLmVUTM",
			"type": "text",
			"x": -279.25641637240483,
			"y": -94.88451468856528,
			"width": 13.6199951171875,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1389367930,
			"version": 165,
			"versionNonce": 891892454,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759089893,
			"link": null,
			"locked": false,
			"text": "3",
			"rawText": "3",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "3",
			"lineHeight": 1.25
		},
		{
			"id": "pyXRaz2h",
			"type": "text",
			"x": -302.83200841342045,
			"y": -95.0514153233309,
			"width": 12.79998779296875,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 316388154,
			"version": 248,
			"versionNonce": 1819516326,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759085118,
			"link": null,
			"locked": false,
			"text": "4",
			"rawText": "4",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "4",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 270,
			"versionNonce": 122754426,
			"isDeleted": false,
			"id": "Q47fwLxO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -208.79120641146733,
			"y": -94.09624564559653,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 12.79998779296875,
			"height": 25,
			"seed": 223363174,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759100789,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "4",
			"rawText": "4",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "4",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 173,
			"versionNonce": 18932410,
			"isDeleted": false,
			"id": "1AHFFscV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -184.22547154818608,
			"y": -93.68888175399496,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 13.6199951171875,
			"height": 25,
			"seed": 2138337210,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759104139,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "3",
			"rawText": "3",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "3",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 243,
			"versionNonce": 1871518054,
			"isDeleted": false,
			"id": "J1iEbVBI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -162.05994420443608,
			"y": -92.62006461532309,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 14.239990234375,
			"height": 25,
			"seed": 1376271162,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759107385,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2",
			"rawText": "2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 758,
			"versionNonce": 1836110694,
			"isDeleted": false,
			"id": "tCovtl7O",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -135.20939641390873,
			"y": -92.0924309483309,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 1162803366,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759110719,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 278,
			"versionNonce": 1592834682,
			"isDeleted": false,
			"id": "IjFc8cMY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -112.14914708529545,
			"y": -91.39884269149496,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 12.79998779296875,
			"height": 25,
			"seed": 628803750,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759114899,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "4",
			"rawText": "4",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "4",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 267,
			"versionNonce": 49769894,
			"isDeleted": false,
			"id": "EbnNwqI4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -88.5471573392017,
			"y": -92.0494621983309,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 13.6199951171875,
			"height": 25,
			"seed": 797266618,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759118702,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "3",
			"rawText": "3",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "3",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 261,
			"versionNonce": 2129499194,
			"isDeleted": false,
			"id": "SxUDL3ss",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -65.87982945834233,
			"y": -92.41448295028403,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 14.239990234375,
			"height": 25,
			"seed": 233571686,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759122275,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "2",
			"rawText": "2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 836,
			"versionNonce": 546862010,
			"isDeleted": false,
			"id": "hixpVbTM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.10798650179936,
			"y": -91.83300101669028,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 1594078074,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1681759125626,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "uYqH3QnD11sdjYHZHEcUv",
			"type": "arrow",
			"x": -282.47455602084233,
			"y": -133.9447716465731,
			"width": 235.33029174804688,
			"height": 2.973968505859375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1669721210,
			"version": 164,
			"versionNonce": 519185062,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759153555,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					235.33029174804688,
					2.973968505859375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "QeDisy4J",
			"type": "text",
			"x": -218.39075475131108,
			"y": -160.95598685653403,
			"width": 101.81993103027344,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ced4da",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 447955642,
			"version": 207,
			"versionNonce": 1452224698,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681759174630,
			"link": null,
			"locked": false,
			"text": "Data flow",
			"rawText": "Data flow",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "Data flow",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#ced4da",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 670.6700546089196,
		"scrollY": 432.47243362273423,
		"zoom": {
			"value": 1.1497234845547601
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%