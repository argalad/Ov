---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "ellipse",
			"version": 292,
			"versionNonce": 1381368486,
			"isDeleted": false,
			"id": "iDP2XjtmzKXvUyEzZayaa",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.7002258300781,
			"y": -202.22943878173828,
			"strokeColor": "#a61e4d",
			"backgroundColor": "#e64980",
			"width": 29.08917236328125,
			"height": 49.324981689453125,
			"seed": 118923238,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760426655,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 180,
			"versionNonce": 826146554,
			"isDeleted": false,
			"id": "vIXbzdoxlc5zXXGYymulO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.3798522949219,
			"y": -202.8713150024414,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 334.3931884765625,
			"height": 1.369293212890625,
			"seed": 542816358,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-1.369293212890625
				]
			]
		},
		{
			"type": "line",
			"version": 296,
			"versionNonce": 148964774,
			"isDeleted": false,
			"id": "e27EBtfEZhYAJkim5oXqh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.1886965088546,
			"y": -154.79639297202232,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 334.3931884765625,
			"height": 0.06414794921875,
			"seed": 1481859450,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-0.06414794921875
				]
			]
		},
		{
			"type": "line",
			"version": 180,
			"versionNonce": 903352250,
			"isDeleted": false,
			"id": "aEQ2K2Bx-_odtuxsKFtHV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.934600830078125,
			"y": -205.92227935791016,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 14.1124267578125,
			"height": 49.03826904296875,
			"seed": 666854842,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.98699951171875,
					26.975311279296875
				],
				[
					-1.12542724609375,
					49.03826904296875
				]
			]
		},
		{
			"type": "arrow",
			"version": 218,
			"versionNonce": 1678588154,
			"isDeleted": false,
			"id": "GOnyQY9cSP8IypiMirK5C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -327.6921691894531,
			"y": -179.21440887451172,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 382.040771484375,
			"height": 1.5447540283203125,
			"seed": 1174045094,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760729500,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					382.040771484375,
					-1.5447540283203125
				]
			]
		},
		{
			"type": "ellipse",
			"version": 456,
			"versionNonce": 1915206394,
			"isDeleted": true,
			"id": "whQjyCwpogKHo37Ej-UCF",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -305.00887870036524,
			"y": -307.2147478436685,
			"strokeColor": "#a61e4d",
			"backgroundColor": "#e64980",
			"width": 31.249697949467773,
			"height": 52.988471445963484,
			"seed": 1543207994,
			"groupIds": [
				"qvuqeN16qOglkje6SidXX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681760718700,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 344,
			"versionNonce": 1904282022,
			"isDeleted": true,
			"id": "ckbXGc8q8O0b5ivc_oYt6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -287.47635020395836,
			"y": -307.9042978166762,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 359.22940693364245,
			"height": 1.470994044543576,
			"seed": 280296550,
			"groupIds": [
				"qvuqeN16qOglkje6SidXX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681760718700,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					359.22940693364245,
					-1.470994044543576
				]
			]
		},
		{
			"type": "line",
			"version": 460,
			"versionNonce": 707414970,
			"isDeleted": true,
			"id": "Pph4-OYYkdTwL-vaETuR0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -287.2709967995612,
			"y": -256.2587310871404,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 359.22940693364245,
			"height": 0.06891237784730207,
			"seed": 1047782650,
			"groupIds": [
				"qvuqeN16qOglkje6SidXX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681760718700,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					359.22940693364245,
					-0.06891237784730207
				]
			]
		},
		{
			"type": "line",
			"version": 344,
			"versionNonce": 490530022,
			"isDeleted": true,
			"id": "-6Rb43Uaj5EFQGtUc2YC7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 73.81701850882524,
			"y": -311.1818649255755,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 15.160591989626537,
			"height": 52.68046393412933,
			"seed": 2128904102,
			"groupIds": [
				"qvuqeN16qOglkje6SidXX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681760718700,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					13.95157644716564,
					28.97883511580979
				],
				[
					-1.2090155424608973,
					52.68046393412933
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#e64980",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 451.1027156406569,
		"scrollY": 392.3770707283169,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%