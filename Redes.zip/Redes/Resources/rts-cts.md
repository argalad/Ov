---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
DIFS ^Pw0wjRd3

RTS ^6agPEXGQ

SIFS ^OXeuzb47

CTS ^DUXXgBpT

SIFS ^nxvpAVYu

Data ^ZhlzJpWi

SIFS ^ChtPJGL8

ACK ^UPjLTQWA

Time ^YwgOWQPK

Time ^rWCVKypW

Origen ^Y9Kz8q3R

Destino ^YxcmDtxB

1 ^g8Oja0Vj

2 ^zrbxh8Zf

3 ^ISr8l34j

4 ^6VGQVjWd

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "rectangle",
			"version": 1316,
			"versionNonce": 1402830013,
			"isDeleted": false,
			"id": "6W7gFgAAStzMXEB22MKtB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -345.6716918945313,
			"y": -208.91101837158203,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 144248573,
			"groupIds": [
				"np2WdC2IAKYhWdn41cJad"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1541,
			"versionNonce": 1553168787,
			"isDeleted": false,
			"id": "-ANh_0RpOLoD4ovIEXRIM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -365.0773315429688,
			"y": -170.45919036865234,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 804792157,
			"groupIds": [
				"np2WdC2IAKYhWdn41cJad"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1374,
			"versionNonce": 61398301,
			"isDeleted": false,
			"id": "do6Ge9musW6ugT2IH3ZPW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -336.75408935546875,
			"y": -201.54671478271484,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1620390845,
			"groupIds": [
				"np2WdC2IAKYhWdn41cJad"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1339,
			"versionNonce": 229953331,
			"isDeleted": false,
			"id": "8F5ovFmKQ_8YixxdTQZB6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -355.47937011718756,
			"y": -162.00798797607422,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 647083037,
			"groupIds": [
				"np2WdC2IAKYhWdn41cJad"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1309,
			"versionNonce": 1881747837,
			"isDeleted": false,
			"id": "ofvChmtsq9CtxNEIdilgs",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -290.66839599609375,
			"y": -163.42864227294922,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 232728701,
			"groupIds": [
				"np2WdC2IAKYhWdn41cJad"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1416,
			"versionNonce": 1733980371,
			"isDeleted": false,
			"id": "EbnAXReknfG-3MI-OZ2Oi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -48.47845458984375,
			"y": -208.04117584228516,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 1238742707,
			"groupIds": [
				"9z5OMj800Vpz_ENy8Eec6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1641,
			"versionNonce": 643824093,
			"isDeleted": false,
			"id": "Yn1as_P-UuSihKIxBZ6KA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -67.88409423828125,
			"y": -169.58934783935547,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 1307732051,
			"groupIds": [
				"9z5OMj800Vpz_ENy8Eec6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1474,
			"versionNonce": 1796922995,
			"isDeleted": false,
			"id": "HX9JGFOBqgbEEWVfcGmYB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.56085205078125,
			"y": -200.67687225341797,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 986179059,
			"groupIds": [
				"9z5OMj800Vpz_ENy8Eec6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1439,
			"versionNonce": 257865277,
			"isDeleted": false,
			"id": "nnNp24p3waSZTFVNwIf4u",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -58.2861328125,
			"y": -161.13814544677734,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 391950227,
			"groupIds": [
				"9z5OMj800Vpz_ENy8Eec6"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1409,
			"versionNonce": 599562259,
			"isDeleted": false,
			"id": "-5PIQgqVxfDY-Ji3MVkB0",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 6.52484130859375,
			"y": -162.55879974365234,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 1172784435,
			"groupIds": [
				"9z5OMj800Vpz_ENy8Eec6"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 269,
			"versionNonce": 1980163741,
			"isDeleted": false,
			"id": "WYy990SaGyTfpnsYdjTHM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -320.4348449707031,
			"y": -106.570556640625,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.37225341796875,
			"height": 353.89727783203125,
			"seed": 1165594611,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.37225341796875,
					353.89727783203125
				]
			]
		},
		{
			"type": "line",
			"version": 326,
			"versionNonce": 2134252979,
			"isDeleted": false,
			"id": "09BM-IlDCKcX2DpY6lAFf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.952239027246833,
			"y": -108.61130422452462,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 1.3564453125,
			"height": 354.8686218261719,
			"seed": 1595488413,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.3564453125,
					354.8686218261719
				]
			]
		},
		{
			"type": "line",
			"version": 242,
			"versionNonce": 1292503805,
			"isDeleted": false,
			"id": "t4w2LoWGDbPeAx1vDq1hp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -366.9199523925781,
			"y": -104.54400634765625,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 35.25531005859375,
			"height": 0.2396240234375,
			"seed": 1750726867,
			"groupIds": [
				"NmvR8x5DBcDtUJWbDmvuM"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.25531005859375,
					0.2396240234375
				]
			]
		},
		{
			"type": "arrow",
			"version": 343,
			"versionNonce": 1756229459,
			"isDeleted": false,
			"id": "wI-yxffJteN9X-1rCyBfR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -348.2771301269531,
			"y": -103.80636596679688,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.15960693359375,
			"height": 59.834442138671875,
			"seed": 192548371,
			"groupIds": [
				"NmvR8x5DBcDtUJWbDmvuM"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.51348876953125,
					32.0203857421875
				],
				[
					0.6461181640625,
					59.834442138671875
				]
			]
		},
		{
			"type": "line",
			"version": 335,
			"versionNonce": 887726941,
			"isDeleted": false,
			"id": "ruQiZkuwiFUDlTwAdZ2Ke",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -364.9569055203162,
			"y": -41.70867086984217,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 35.25531005859375,
			"height": 0.2396240234375,
			"seed": 1106581757,
			"groupIds": [
				"NmvR8x5DBcDtUJWbDmvuM"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907476,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					35.25531005859375,
					0.2396240234375
				]
			]
		},
		{
			"type": "text",
			"version": 78,
			"versionNonce": 578456819,
			"isDeleted": false,
			"id": "Pw0wjRd3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -423.1273498535156,
			"y": -84.65179443359375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.13996887207031,
			"height": 25,
			"seed": 1462096061,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DIFS",
			"rawText": "DIFS",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DIFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 280,
			"versionNonce": 327249299,
			"isDeleted": false,
			"id": "tM6cUlSNUaE5peV1Qa7Vy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -319.8582865397135,
			"y": -38.861907958984375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 303.7763468424479,
			"height": 30.5498046875,
			"seed": 1127108989,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6agPEXGQ"
				}
			],
			"updated": 1685177912336,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					303.7763468424479,
					30.5498046875
				]
			]
		},
		{
			"type": "text",
			"version": 51,
			"versionNonce": 1612871315,
			"isDeleted": false,
			"id": "6agPEXGQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -188.78023529052734,
			"y": -35.878753662109375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 41.79997253417969,
			"height": 25,
			"seed": 1089296915,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "RTS",
			"rawText": "RTS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "tM6cUlSNUaE5peV1Qa7Vy",
			"originalText": "RTS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 380,
			"versionNonce": 39071773,
			"isDeleted": false,
			"id": "2Zdsc7h59lBzNo1SJqWA_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -5.100039010241006,
			"y": -8.473113627870525,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 669543133,
			"groupIds": [
				"S9IdDMmoPZJttmcscwveZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "arrow",
			"version": 482,
			"versionNonce": 542911539,
			"isDeleted": false,
			"id": "ueniW1YA10vgwwMcaXWeG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 5.505179413317093,
			"y": -8.053497045917986,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.6596578909036693,
			"height": 34.037621508756615,
			"seed": 145819453,
			"groupIds": [
				"S9IdDMmoPZJttmcscwveZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.29210494426930733,
					18.215224066617445
				],
				[
					0.367552946634362,
					34.037621508756615
				]
			]
		},
		{
			"type": "line",
			"version": 473,
			"versionNonce": 1139942525,
			"isDeleted": false,
			"id": "WSVkzOK7RLuJ_P6JkyT2q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -3.983333580162042,
			"y": 27.271606134249005,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 317134749,
			"groupIds": [
				"S9IdDMmoPZJttmcscwveZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "text",
			"version": 120,
			"versionNonce": 1192111571,
			"isDeleted": false,
			"id": "OXeuzb47",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 23.363861083984375,
			"y": -2.4542236328125,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.69996643066406,
			"height": 25,
			"seed": 1975590387,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SIFS",
			"rawText": "SIFS",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SIFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 252,
			"versionNonce": 445811933,
			"isDeleted": false,
			"id": "DWMFirdzsW-LHkugFZnMz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.813079717969515,
			"y": 28.813887053858487,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 303.59661865234375,
			"height": 30.13330078125,
			"seed": 953874867,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "DUXXgBpT"
				}
			],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-303.59661865234375,
					30.13330078125
				]
			]
		},
		{
			"type": "text",
			"version": 105,
			"versionNonce": 2001664883,
			"isDeleted": false,
			"id": "DUXXgBpT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -187.17137134394608,
			"y": 31.380537444483487,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 41.119964599609375,
			"height": 25,
			"seed": 1364675411,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "CTS",
			"rawText": "CTS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "DWMFirdzsW-LHkugFZnMz",
			"originalText": "CTS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 483,
			"versionNonce": 633792829,
			"isDeleted": false,
			"id": "iQfvcd6ckzqhLPP6_q7Un",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -350.47094861070104,
			"y": 59.962069321962716,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 536607453,
			"groupIds": [
				"px1wIMB6j-dWAZ2bgfpMk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "arrow",
			"version": 585,
			"versionNonce": 761599251,
			"isDeleted": false,
			"id": "acSBHv5iQ0G8qb9jYhRpz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -339.86573018714296,
			"y": 60.381685903915255,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.6596578909036693,
			"height": 34.037621508756615,
			"seed": 1473419069,
			"groupIds": [
				"px1wIMB6j-dWAZ2bgfpMk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.29210494426930733,
					18.215224066617445
				],
				[
					0.367552946634362,
					34.037621508756615
				]
			]
		},
		{
			"type": "line",
			"version": 576,
			"versionNonce": 384874909,
			"isDeleted": false,
			"id": "-qAhUorT1S0I-hmZWc2jm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -349.35424318062206,
			"y": 95.70678908408226,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 659990429,
			"groupIds": [
				"px1wIMB6j-dWAZ2bgfpMk"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "text",
			"version": 182,
			"versionNonce": 415693491,
			"isDeleted": false,
			"id": "nxvpAVYu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -407.0864028930664,
			"y": 66.6956787109375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.69996643066406,
			"height": 25,
			"seed": 1191041469,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SIFS",
			"rawText": "SIFS",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SIFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 258,
			"versionNonce": 2000780797,
			"isDeleted": false,
			"id": "OBLGa-8uO_Lp-eRqqvX6j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -318.9472950842511,
			"y": 98.18778842104598,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 303.59661865234375,
			"height": 30.13330078125,
			"seed": 506297981,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "ZhlzJpWi"
				}
			],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					303.59661865234375,
					30.13330078125
				]
			]
		},
		{
			"type": "text",
			"version": 104,
			"versionNonce": 907750483,
			"isDeleted": false,
			"id": "ZhlzJpWi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -193.9389714148175,
			"y": 100.75443881167098,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 53.57997131347656,
			"height": 25,
			"seed": 139634397,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Data",
			"rawText": "Data",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "OBLGa-8uO_Lp-eRqqvX6j",
			"originalText": "Data",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 459,
			"versionNonce": 767211101,
			"isDeleted": false,
			"id": "ENTK1Dadp8FXEQBhXPypb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -4.429430165005538,
			"y": 128.13327293524395,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 199302621,
			"groupIds": [
				"YahNdkX36npHpvNq2YgSY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "arrow",
			"version": 561,
			"versionNonce": 691546611,
			"isDeleted": false,
			"id": "sfetbNOJK4v1oWKo8jDDC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 6.17578825855256,
			"y": 128.5528895171965,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.6596578909036693,
			"height": 34.037621508756615,
			"seed": 1897617981,
			"groupIds": [
				"YahNdkX36npHpvNq2YgSY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.29210494426930733,
					18.215224066617445
				],
				[
					0.367552946634362,
					34.037621508756615
				]
			]
		},
		{
			"type": "line",
			"version": 552,
			"versionNonce": 1160635069,
			"isDeleted": false,
			"id": "tiiXwFsd_9FYXRB-wpHId",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -3.312724734926576,
			"y": 163.87799269736348,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 20.05545396691669,
			"height": 0.1363133259480923,
			"seed": 1083116189,
			"groupIds": [
				"YahNdkX36npHpvNq2YgSY"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					20.05545396691669,
					0.1363133259480923
				]
			]
		},
		{
			"type": "text",
			"version": 198,
			"versionNonce": 1462006675,
			"isDeleted": false,
			"id": "ChtPJGL8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 24.03446992921984,
			"y": 134.15216293030198,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 46.69996643066406,
			"height": 25,
			"seed": 1525526269,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SIFS",
			"rawText": "SIFS",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SIFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 326,
			"versionNonce": 1916568349,
			"isDeleted": false,
			"id": "WP_erfSDl1XqgVA4GBi5S",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -15.261393979378056,
			"y": 166.05198194045573,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 303.59661865234375,
			"height": 30.13330078125,
			"seed": 1155528723,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "UPjLTQWA"
				}
			],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-303.59661865234375,
					30.13330078125
				]
			]
		},
		{
			"type": "text",
			"version": 182,
			"versionNonce": 1075218739,
			"isDeleted": false,
			"id": "UPjLTQWA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -186.18969292957337,
			"y": 168.61863233108073,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 38.259979248046875,
			"height": 25,
			"seed": 1693285811,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ACK",
			"rawText": "ACK",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "WP_erfSDl1XqgVA4GBi5S",
			"originalText": "ACK",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 79,
			"versionNonce": 1498945405,
			"isDeleted": false,
			"id": "YwgOWQPK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -341.7154235839844,
			"y": 258.8577880859375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 44.05995178222656,
			"height": 25,
			"seed": 1673368563,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Time",
			"rawText": "Time",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Time",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 87,
			"versionNonce": 427092691,
			"isDeleted": false,
			"id": "rWCVKypW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -35.117828369140625,
			"y": 258.5230712890625,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 44.05995178222656,
			"height": 25,
			"seed": 650809747,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Time",
			"rawText": "Time",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Time",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 59,
			"versionNonce": 348266461,
			"isDeleted": false,
			"id": "Y9Kz8q3R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -349.9893493652344,
			"y": -249.52322387695312,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 57.79994201660156,
			"height": 25,
			"seed": 1911838557,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Origen",
			"rawText": "Origen",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Origen",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 65,
			"versionNonce": 668342387,
			"isDeleted": false,
			"id": "YxcmDtxB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -58.467681884765625,
			"y": -249.08209228515625,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 73.49992370605469,
			"height": 25,
			"seed": 1049039773,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907477,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Destino",
			"rawText": "Destino",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Destino",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "g8Oja0Vj",
			"type": "text",
			"x": -310.0793709720763,
			"y": -27.687474568684877,
			"width": 4.33599853515625,
			"height": 20,
			"angle": 0,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 926520787,
			"version": 228,
			"versionNonce": 500455731,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685177917604,
			"link": null,
			"locked": false,
			"text": "1",
			"rawText": "1",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 14,
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"id": "QSwBolP-WQ46Xu_R3CL-q",
			"type": "ellipse",
			"x": -315.8685555423888,
			"y": -29.546035766601562,
			"width": 16.77685546875,
			"height": 21.800496419270843,
			"angle": 0,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1924220627,
			"version": 279,
			"versionNonce": 455034749,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1685177917604,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 158,
			"versionNonce": 580357277,
			"isDeleted": false,
			"id": "zrbxh8Zf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -33.17454512572215,
			"y": 39.040125528971345,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 11.391998291015625,
			"height": 20,
			"seed": 1066948019,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "2",
			"rawText": "2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 245,
			"versionNonce": 501929907,
			"isDeleted": false,
			"id": "w_dEtcGpZOdzHQ0_ZPEDL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -36.824244018951276,
			"y": 36.83069356282547,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 16.77685546875,
			"height": 21.800496419270843,
			"seed": 1342777171,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 255,
			"versionNonce": 748024061,
			"isDeleted": false,
			"id": "ISr8l34j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -312.2754972741596,
			"y": 108.17025248209634,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 10.89599609375,
			"height": 20,
			"seed": 1814401213,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "3",
			"rawText": "3",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "3",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 294,
			"versionNonce": 79391059,
			"isDeleted": false,
			"id": "m6ZZ2vtAeNsHaxt41SAMp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -315.8196053470763,
			"y": 106.48002624511716,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 16.77685546875,
			"height": 21.800496419270843,
			"seed": 2047766813,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 226,
			"versionNonce": 1174980957,
			"isDeleted": false,
			"id": "6VGQVjWd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -31.688705281972148,
			"y": 174.38395690917972,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 10.239990234375,
			"height": 20,
			"seed": 915508253,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "4",
			"rawText": "4",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "4",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 298,
			"versionNonce": 315148019,
			"isDeleted": false,
			"id": "CWMud5pi1vr2mQAVN8bkG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -35.16148360228465,
			"y": 171.97192891438797,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 16.77685546875,
			"height": 21.800496419270843,
			"seed": 1076101245,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685177907478,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#e03131",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 605.2771859134825,
		"scrollY": 269.3344268798828,
		"zoom": {
			"value": 1.5
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%