---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Trama disponible
para transmitir ^VyS0oLZh

¿Medio libre? ^bAJUgfDX

Esperar DIFS ^qpqLBucP

¿Medio sigue libre? ^SvNB42jM

Transmitir trama ^VIOx7bR4

Sí ^ZjcGKGBi

Esperar a que medio quede libre ^5NB1kztM

Esperar DIFS ^p9nnpTe7

¿Medio sigue libre? ^wB6Mv7nG

Periodo de contingencia (intervalo aleatorio) mientras medio siga libre ^hLWX0VOt

Transmitir trama ^jbUvGa2a

No ^sfWs4enI

No ^4le1AbWg

No ^40F3lnzL

Detener cuenta si medio ocupado ^qVKAOhvE

Escuchar medio ^qnO5BY9f

Sí ^VTP4mbOF

Sí ^7JqU15GH

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.26",
	"elements": [
		{
			"type": "rectangle",
			"version": 503,
			"versionNonce": 2049724444,
			"isDeleted": false,
			"id": "ZtxeOa2RKkzdPV3R8zDAl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -481.8113213560055,
			"y": -428.06722500292364,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 80,
			"seed": 871542247,
			"groupIds": [
				"-f3LgreyPH8DLAy5wae7G"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "VyS0oLZh"
				},
				{
					"id": "4nhEFC4zjR-Bv_5QTVRJu",
					"type": "arrow"
				},
				{
					"id": "2BtINMdQtnwsHI_CVRvDC",
					"type": "arrow"
				}
			],
			"updated": 1682335866917,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 92,
			"versionNonce": 554941220,
			"isDeleted": false,
			"id": "VyS0oLZh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -448.97327051372037,
			"y": -423.06722500292364,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 226.3238983154297,
			"height": 70,
			"seed": 157669540,
			"groupIds": [
				"-f3LgreyPH8DLAy5wae7G"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335866918,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Trama disponible\npara transmitir",
			"rawText": "Trama disponible\npara transmitir",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZtxeOa2RKkzdPV3R8zDAl",
			"originalText": "Trama disponible\npara transmitir",
			"lineHeight": 1.25,
			"baseline": 59
		},
		{
			"type": "diamond",
			"version": 824,
			"versionNonce": 1061010076,
			"isDeleted": false,
			"id": "CXy34UrrUjphhmHw4FH5z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -472.45694958550285,
			"y": -152.6433888765476,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 275,
			"height": 160,
			"seed": 429827495,
			"groupIds": [
				"sbqFsiKM7JZRYiaoomMAm"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "cuzo4eB_ZXQoPLdxTfOe8",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "bAJUgfDX"
				},
				{
					"id": "WkjdB79P8aH7GNe7_3cK2",
					"type": "arrow"
				},
				{
					"id": "P0EwGwO6xoaME8XoJhkvT",
					"type": "arrow"
				}
			],
			"updated": 1682335882633,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 115,
			"versionNonce": 1667887132,
			"isDeleted": false,
			"id": "bAJUgfDX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -386.7309287725146,
			"y": -107.64338887654759,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 104.04795837402344,
			"height": 70,
			"seed": 1781750820,
			"groupIds": [
				"sbqFsiKM7JZRYiaoomMAm"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335882634,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "¿Medio \nlibre?",
			"rawText": "¿Medio libre?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "CXy34UrrUjphhmHw4FH5z",
			"originalText": "¿Medio libre?",
			"lineHeight": 1.25,
			"baseline": 59
		},
		{
			"type": "rectangle",
			"version": 587,
			"versionNonce": 2101277852,
			"isDeleted": false,
			"id": "QaOWF4dsj3xzGgUDzPVb-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -480.4118009790662,
			"y": -265.8486441893663,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 52,
			"seed": 871542247,
			"groupIds": [
				"lMPm5-6kNYUa65CIP18Pc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "cuzo4eB_ZXQoPLdxTfOe8",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "qnO5BY9f"
				}
			],
			"updated": 1682335858050,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 18,
			"versionNonce": 1766749596,
			"isDeleted": false,
			"id": "qnO5BY9f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -438.0397611841443,
			"y": -257.3486441893663,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 207.25592041015625,
			"height": 35,
			"seed": 1966304796,
			"groupIds": [
				"lMPm5-6kNYUa65CIP18Pc"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335869311,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Escuchar medio",
			"rawText": "Escuchar medio",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "QaOWF4dsj3xzGgUDzPVb-",
			"originalText": "Escuchar medio",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "rectangle",
			"version": 709,
			"versionNonce": 906628636,
			"isDeleted": false,
			"id": "4xhfLs8R34T3tz0n1dIg2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -479.0653081195125,
			"y": 70.8218544732108,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 52,
			"seed": 871542247,
			"groupIds": [
				"9uB95WK7V63IcEsJQv84e"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "qpqLBucP"
				},
				{
					"id": "WkjdB79P8aH7GNe7_3cK2",
					"type": "arrow"
				},
				{
					"id": "lBplCzVcQGZg1MvKKbrSA",
					"type": "arrow"
				}
			],
			"updated": 1682335895344,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 135,
			"versionNonce": 1270700196,
			"isDeleted": false,
			"id": "qpqLBucP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -428.13926747009845,
			"y": 79.3218544732108,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 190.14791870117188,
			"height": 35,
			"seed": 553612708,
			"groupIds": [
				"9uB95WK7V63IcEsJQv84e"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335895345,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Esperar DIFS",
			"rawText": "Esperar DIFS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "4xhfLs8R34T3tz0n1dIg2",
			"originalText": "Esperar DIFS",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "diamond",
			"version": 761,
			"versionNonce": 948155172,
			"isDeleted": false,
			"id": "WYXTI5N3BZbDpPX7ZXTmC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -469.8757766261303,
			"y": 216.27881748431292,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 275,
			"height": 230,
			"seed": 429827495,
			"groupIds": [
				"mC1BAXpAXJeApiHY47RFq"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "SvNB42jM"
				},
				{
					"id": "lBplCzVcQGZg1MvKKbrSA",
					"type": "arrow"
				},
				{
					"id": "xtokIYH4VMUEQatxwrA1W",
					"type": "arrow"
				}
			],
			"updated": 1682336082686,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 226,
			"versionNonce": 1197108644,
			"isDeleted": false,
			"id": "SvNB42jM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -384.149755813142,
			"y": 278.7788174843129,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 104.04795837402344,
			"height": 105,
			"seed": 1539035428,
			"groupIds": [
				"mC1BAXpAXJeApiHY47RFq"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335945085,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "¿Medio \nsigue \nlibre?",
			"rawText": "¿Medio sigue libre?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "WYXTI5N3BZbDpPX7ZXTmC",
			"originalText": "¿Medio sigue libre?",
			"lineHeight": 1.25,
			"baseline": 94
		},
		{
			"type": "arrow",
			"version": 498,
			"versionNonce": 1326393380,
			"isDeleted": false,
			"id": "4nhEFC4zjR-Bv_5QTVRJu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.818699540842,
			"y": -346.74302700203845,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.6664636662478642,
			"height": 80.50734572734683,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072126,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ZtxeOa2RKkzdPV3R8zDAl",
				"gap": 1.3241980008851897,
				"focus": -0.009121201727290343
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.6664636662478642,
					80.50734572734683
				]
			]
		},
		{
			"type": "arrow",
			"version": 756,
			"versionNonce": 1425536548,
			"isDeleted": false,
			"id": "cuzo4eB_ZXQoPLdxTfOe8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.31057466237615,
			"y": -211.43650468167795,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.5391587845753065,
			"height": 55.44986770435247,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072128,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "QaOWF4dsj3xzGgUDzPVb-",
				"gap": 2.412139507688369,
				"focus": -0.006065108356246596
			},
			"endBinding": {
				"elementId": "CXy34UrrUjphhmHw4FH5z",
				"gap": 3.460400393974366,
				"focus": -0.023317801606199035
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.5391587845753065,
					55.44986770435247
				]
			]
		},
		{
			"type": "arrow",
			"version": 896,
			"versionNonce": 643666340,
			"isDeleted": false,
			"id": "WkjdB79P8aH7GNe7_3cK2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.5807918539624,
			"y": 8.28316676722261,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.420899198095924,
			"height": 55.60947412745646,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072129,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "CXy34UrrUjphhmHw4FH5z",
				"gap": 1,
				"focus": -0.0071903803794921214
			},
			"endBinding": {
				"elementId": "4xhfLs8R34T3tz0n1dIg2",
				"gap": 6.929213578531744,
				"focus": -0.014949841755163125
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.420899198095924,
					55.60947412745646
				]
			]
		},
		{
			"type": "arrow",
			"version": 1114,
			"versionNonce": 970487972,
			"isDeleted": false,
			"id": "lBplCzVcQGZg1MvKKbrSA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -332.66734112817926,
			"y": 123.8218544732108,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8719964879080635,
			"height": 90.87639457073851,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072130,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "4xhfLs8R34T3tz0n1dIg2",
				"gap": 1,
				"focus": -0.004492618512715834
			},
			"endBinding": {
				"elementId": "WYXTI5N3BZbDpPX7ZXTmC",
				"gap": 1.9626692976717308,
				"focus": -0.01659781547519986
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.8719964879080635,
					90.87639457073851
				]
			]
		},
		{
			"type": "rectangle",
			"version": 942,
			"versionNonce": 1909671068,
			"isDeleted": false,
			"id": "cj_oA7UCXV76_khSBbWvZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -472.45803833007807,
			"y": 532.8245854722735,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 52,
			"seed": 871542247,
			"groupIds": [
				"u-fSFQ22g4k6gl_dISx-i"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "xtokIYH4VMUEQatxwrA1W",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "VIOx7bR4"
				},
				{
					"id": "xCKmEZb9h5xyJ7QsA_l6R",
					"type": "arrow"
				}
			],
			"updated": 1682335967040,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 221,
			"versionNonce": 968079900,
			"isDeleted": false,
			"id": "VIOx7bR4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -444.6039886474609,
			"y": 541.3245854722735,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 236.29190063476562,
			"height": 35,
			"seed": 1963826716,
			"groupIds": [
				"u-fSFQ22g4k6gl_dISx-i"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335969351,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Transmitir trama",
			"rawText": "Transmitir trama",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "cj_oA7UCXV76_khSBbWvZ",
			"originalText": "Transmitir trama",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "arrow",
			"version": 1320,
			"versionNonce": 962632860,
			"isDeleted": false,
			"id": "xtokIYH4VMUEQatxwrA1W",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -329.9175699867586,
			"y": 445.87883610000324,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.315111397787291,
			"height": 82.76342696451297,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072131,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "WYXTI5N3BZbDpPX7ZXTmC",
				"gap": 1.2702587849751903,
				"focus": -0.004539289277326567
			},
			"endBinding": {
				"elementId": "cj_oA7UCXV76_khSBbWvZ",
				"gap": 4.1823224077572965,
				"focus": -0.011370720932245547
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					1.315111397787291,
					82.76342696451297
				]
			]
		},
		{
			"type": "arrow",
			"version": 1229,
			"versionNonce": 2147093284,
			"isDeleted": false,
			"id": "xCKmEZb9h5xyJ7QsA_l6R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -327.0709967196646,
			"y": 585.8245854722735,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 298.6464487605212,
			"height": 88.83399673742258,
			"seed": 1065470876,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072131,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "cj_oA7UCXV76_khSBbWvZ",
				"gap": 1,
				"focus": -0.07388508139952965
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "dot",
			"points": [
				[
					0,
					0
				],
				[
					-38.62345553966418,
					84.96682949116064
				],
				[
					-298.6464487605212,
					88.83399673742258
				]
			]
		},
		{
			"type": "text",
			"version": 163,
			"versionNonce": 748441892,
			"isDeleted": false,
			"id": "ZjcGKGBi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -394.40815373915234,
			"y": 14.08848430688829,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 25.81597900390625,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335950150,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "arrow",
			"version": 549,
			"versionNonce": 484092188,
			"isDeleted": false,
			"id": "P0EwGwO6xoaME8XoJhkvT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -200.3666061065145,
			"y": -76.14461790161309,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 333.25520408153443,
			"height": 267.1589490772073,
			"seed": 828988068,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072132,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "CXy34UrrUjphhmHw4FH5z",
				"gap": 1.5630339082691194,
				"focus": -0.16005236644901197
			},
			"endBinding": {
				"elementId": "sRtzRbWioA-ZYFZndOzQo",
				"gap": 3.7461056480884736,
				"focus": 0.020614786655562614
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					301.65327602435116,
					20.850444214068744
				],
				[
					333.25520408153443,
					267.1589490772073
				]
			]
		},
		{
			"type": "rectangle",
			"version": 789,
			"versionNonce": 527041308,
			"isDeleted": false,
			"id": "sRtzRbWioA-ZYFZndOzQo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -10.614235307742035,
			"y": 194.76043682368265,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 80,
			"seed": 871542247,
			"groupIds": [
				"tsUCtbufW9b22QyyF_2Hi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "P0EwGwO6xoaME8XoJhkvT",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "5NB1kztM"
				},
				{
					"id": "m4zUA4zxFSWCM_b0Dv4tc",
					"type": "arrow"
				},
				{
					"id": "jdbtlsAU2NXgDuagU9T_V",
					"type": "arrow"
				},
				{
					"id": "cyLaCWBnzBYR-SmfgI3Ii",
					"type": "arrow"
				}
			],
			"updated": 1682335989672,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 96,
			"versionNonce": 931474972,
			"isDeleted": false,
			"id": "5NB1kztM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 19.661811445187652,
			"y": 199.76043682368265,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 231.44790649414062,
			"height": 70,
			"seed": 828804636,
			"groupIds": [
				"tsUCtbufW9b22QyyF_2Hi"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335935628,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Esperar a que \nmedio quede libre",
			"rawText": "Esperar a que medio quede libre",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "sRtzRbWioA-ZYFZndOzQo",
			"originalText": "Esperar a que medio quede libre",
			"lineHeight": 1.25,
			"baseline": 59
		},
		{
			"type": "arrow",
			"version": 803,
			"versionNonce": 2047831708,
			"isDeleted": false,
			"id": "m4zUA4zxFSWCM_b0Dv4tc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 131.174174558613,
			"y": 277.75422003838685,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.1403636275363453,
			"height": 67.15925154903977,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072133,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "sRtzRbWioA-ZYFZndOzQo",
				"gap": 2.9937832147041945,
				"focus": 0.023735853468712462
			},
			"endBinding": {
				"elementId": "6gWPIqmW2exVFzuvXHA1c",
				"gap": 6.321627468019983,
				"focus": -0.013308482682827522
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.1403636275363453,
					67.15925154903977
				]
			]
		},
		{
			"type": "rectangle",
			"version": 801,
			"versionNonce": 2025215524,
			"isDeleted": false,
			"id": "6gWPIqmW2exVFzuvXHA1c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.566096181896,
			"y": 351.2350990554466,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 52,
			"seed": 871542247,
			"groupIds": [
				"8n7297B2CTbvfOKKJM8wl"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "p9nnpTe7"
				},
				{
					"id": "m4zUA4zxFSWCM_b0Dv4tc",
					"type": "arrow"
				},
				{
					"id": "2B5stZTslLZ8L0ElBdggx",
					"type": "arrow"
				}
			],
			"updated": 1682335858052,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 91,
			"versionNonce": 401571108,
			"isDeleted": false,
			"id": "p9nnpTe7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 36.35994446751806,
			"y": 359.7350990554466,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 190.14791870117188,
			"height": 35,
			"seed": 1963826716,
			"groupIds": [
				"8n7297B2CTbvfOKKJM8wl"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335938790,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Esperar DIFS",
			"rawText": "Esperar DIFS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "6gWPIqmW2exVFzuvXHA1c",
			"originalText": "Esperar DIFS",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "arrow",
			"version": 850,
			"versionNonce": 1258387356,
			"isDeleted": false,
			"id": "2B5stZTslLZ8L0ElBdggx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 132.8944339001274,
			"y": 405.02811553255094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.8473777763257431,
			"height": 67.78245582623776,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072134,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "6gWPIqmW2exVFzuvXHA1c",
				"gap": 1.793016477104345,
				"focus": -0.012356124871945848
			},
			"endBinding": {
				"elementId": "Lk-ob4llyGEUTbD848LZj",
				"gap": 1.6426607256882377,
				"focus": -0.016908841780449355
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.8473777763257431,
					67.78245582623776
				]
			]
		},
		{
			"type": "diamond",
			"version": 654,
			"versionNonce": 2108429212,
			"isDeleted": false,
			"id": "Lk-ob4llyGEUTbD848LZj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -4.583062678023964,
			"y": 474.203999132583,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 275,
			"height": 230,
			"seed": 429827495,
			"groupIds": [
				"tLcbB8u2Dvjz3epcze79o"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "wB6Mv7nG"
				},
				{
					"id": "2B5stZTslLZ8L0ElBdggx",
					"type": "arrow"
				},
				{
					"id": "3nxlZ6PkRu8sazCWqJL-s",
					"type": "arrow"
				}
			],
			"updated": 1682335942021,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 116,
			"versionNonce": 293962788,
			"isDeleted": false,
			"id": "wB6Mv7nG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.14295813496432,
			"y": 536.703999132583,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 104.04795837402344,
			"height": 105,
			"seed": 1539035428,
			"groupIds": [
				"tLcbB8u2Dvjz3epcze79o"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335942021,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "¿Medio \nsigue \nlibre?",
			"rawText": "¿Medio sigue libre?",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Lk-ob4llyGEUTbD848LZj",
			"originalText": "¿Medio sigue libre?",
			"lineHeight": 1.25,
			"baseline": 94
		},
		{
			"type": "arrow",
			"version": 943,
			"versionNonce": 1808089244,
			"isDeleted": false,
			"id": "3nxlZ6PkRu8sazCWqJL-s",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 130.81063462801114,
			"y": 703.7460144627391,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.2754163690655105,
			"height": 71.0334104379964,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072135,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Lk-ob4llyGEUTbD848LZj",
				"gap": 1,
				"focus": 0.01167071212229293
			},
			"endBinding": {
				"elementId": "Peb20v4Y9OuXOzjU7XGaD",
				"gap": 7.519218639979158,
				"focus": -0.034440457363187314
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.2754163690655105,
					71.0334104379964
				]
			]
		},
		{
			"type": "rectangle",
			"version": 895,
			"versionNonce": 828231076,
			"isDeleted": false,
			"id": "Peb20v4Y9OuXOzjU7XGaD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -10.81192539550193,
			"y": 782.2986435407147,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 185,
			"seed": 871542247,
			"groupIds": [
				"snSS4GX2uF9GJnaIm0-gi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "hLWX0VOt"
				},
				{
					"id": "3nxlZ6PkRu8sazCWqJL-s",
					"type": "arrow"
				},
				{
					"id": "YKV7RaSWZYoW3LY_h1Ws0",
					"type": "arrow"
				},
				{
					"id": "xkU9pBRUeRDog4GMGkWv1",
					"type": "arrow"
				}
			],
			"updated": 1682336053255,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 251,
			"versionNonce": 1198257060,
			"isDeleted": false,
			"id": "hLWX0VOt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -5.133870585931618,
			"y": 787.2986435407147,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 280.6438903808594,
			"height": 175,
			"seed": 1963826716,
			"groupIds": [
				"snSS4GX2uF9GJnaIm0-gi"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682336010857,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Periodo de \ncontingencia \n(intervalo aleatorio)\nmientras medio siga \nlibre",
			"rawText": "Periodo de contingencia (intervalo aleatorio) mientras medio siga libre",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "Peb20v4Y9OuXOzjU7XGaD",
			"originalText": "Periodo de contingencia (intervalo aleatorio) mientras medio siga libre",
			"lineHeight": 1.25,
			"baseline": 164
		},
		{
			"type": "arrow",
			"version": 1229,
			"versionNonce": 758459940,
			"isDeleted": false,
			"id": "YKV7RaSWZYoW3LY_h1Ws0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 133.15992582148652,
			"y": 970.3314533453045,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0370393970256373,
			"height": 80.22143398715866,
			"seed": 1638671657,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072135,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Peb20v4Y9OuXOzjU7XGaD",
				"gap": 3.0328098045897605,
				"focus": 0.014189323305891078
			},
			"endBinding": {
				"elementId": "9LhUpYKiqxNlY5KqCHyiW",
				"gap": 8.402700567054353,
				"focus": -0.003561275678496877
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0.0370393970256373,
					80.22143398715866
				]
			]
		},
		{
			"type": "rectangle",
			"version": 899,
			"versionNonce": 506013468,
			"isDeleted": false,
			"id": "9LhUpYKiqxNlY5KqCHyiW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -12.267161556098756,
			"y": 1058.9555878995175,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 52,
			"seed": 871542247,
			"groupIds": [
				"58pPqLDWUd9eW9y5fvdOj"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "jbUvGa2a"
				},
				{
					"id": "YKV7RaSWZYoW3LY_h1Ws0",
					"type": "arrow"
				},
				{
					"id": "2BtINMdQtnwsHI_CVRvDC",
					"type": "arrow"
				}
			],
			"updated": 1682336021550,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 175,
			"versionNonce": 1455860892,
			"isDeleted": false,
			"id": "jbUvGa2a",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.586888126518431,
			"y": 1067.4555878995175,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 236.29190063476562,
			"height": 35,
			"seed": 1963826716,
			"groupIds": [
				"58pPqLDWUd9eW9y5fvdOj"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682336022534,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Transmitir trama",
			"rawText": "Transmitir trama",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9LhUpYKiqxNlY5KqCHyiW",
			"originalText": "Transmitir trama",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "arrow",
			"version": 2714,
			"versionNonce": 1318532636,
			"isDeleted": false,
			"id": "2BtINMdQtnwsHI_CVRvDC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 138.3131055328861,
			"y": 1112.947145512325,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 768.8544578345231,
			"height": 1647.4202872050478,
			"seed": 1667550876,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072136,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "9LhUpYKiqxNlY5KqCHyiW",
				"gap": 1.9915576128075827,
				"focus": -0.13439863759279536
			},
			"endBinding": {
				"elementId": "ZtxeOa2RKkzdPV3R8zDAl",
				"gap": 4.3257849382429185,
				"focus": 0.8781200313466072
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-85.38320587350123,
					139.05451761221389
				],
				[
					-697.3926280269689,
					30.864745113027993
				],
				[
					-768.8544578345231,
					-1327.0569994989307
				],
				[
					-624.4502118271346,
					-1508.3657695928339
				]
			]
		},
		{
			"type": "text",
			"version": 139,
			"versionNonce": 426797860,
			"isDeleted": false,
			"id": "sfWs4enI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -188.69109863490473,
			"y": -149.5598401885223,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 33.54399108886719,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335858052,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 221,
			"versionNonce": 1712372900,
			"isDeleted": false,
			"id": "4le1AbWg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -175.68611646819477,
			"y": 258.1113502244194,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 33.54399108886719,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335998983,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 174,
			"versionNonce": 234841764,
			"isDeleted": false,
			"id": "40F3lnzL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 274.0017836223233,
			"y": 471.51612569263585,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 33.54399108886719,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335858052,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "No",
			"rawText": "No",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "No",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "arrow",
			"version": 732,
			"versionNonce": 1724158500,
			"isDeleted": false,
			"id": "jdbtlsAU2NXgDuagU9T_V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 263.3598307749078,
			"y": 535.1069583562665,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 125.5552489098688,
			"height": 352.9115485459645,
			"seed": 1184321956,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072132,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "sRtzRbWioA-ZYFZndOzQo",
				"gap": 6.055570383205861,
				"focus": -0.4926247943549498
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					55.41563383839707
				],
				[
					113.7549252288785,
					26.070308737637223
				],
				[
					125.5552489098688,
					-268.9331552211568
				],
				[
					24.08150430055605,
					-297.4959147075674
				]
			]
		},
		{
			"type": "rectangle",
			"version": 914,
			"versionNonce": 924612900,
			"isDeleted": false,
			"id": "3-sSW153Q7eEgj2ieLJiH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 469.3570005672541,
			"y": 670.9102139608133,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 292,
			"height": 85,
			"seed": 871542247,
			"groupIds": [
				"rvM_d6ifDd6note8aTrcG"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "qVKAOhvE"
				},
				{
					"id": "-YXMDOP3T36M4O9snicAF",
					"type": "arrow"
				},
				{
					"id": "xkU9pBRUeRDog4GMGkWv1",
					"type": "arrow"
				}
			],
			"updated": 1682336053256,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 303,
			"versionNonce": 1602547108,
			"isDeleted": false,
			"id": "qVKAOhvE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 482.9030515926447,
			"y": 678.4102139608133,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 264.90789794921875,
			"height": 70,
			"seed": 1963826716,
			"groupIds": [
				"rvM_d6ifDd6note8aTrcG"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682336035382,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Detener cuenta si \nmedio ocupado",
			"rawText": "Detener cuenta si medio ocupado",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "3-sSW153Q7eEgj2ieLJiH",
			"originalText": "Detener cuenta si medio ocupado",
			"lineHeight": 1.25,
			"baseline": 59
		},
		{
			"type": "arrow",
			"version": 477,
			"versionNonce": 1915996580,
			"isDeleted": false,
			"id": "-YXMDOP3T36M4O9snicAF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 613.2152678900336,
			"y": 669.9102139608133,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 234.7301663077851,
			"height": 423.30275423524455,
			"seed": 1354622620,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682336072136,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "3-sSW153Q7eEgj2ieLJiH",
				"gap": 1,
				"focus": 0.0024336408595644235
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "dot",
			"points": [
				[
					0,
					0
				],
				[
					-21.61412623234878,
					-375.63569426590175
				],
				[
					-234.7301663077851,
					-423.30275423524455
				]
			]
		},
		{
			"type": "text",
			"version": 189,
			"versionNonce": 592383780,
			"isDeleted": false,
			"id": "VTP4mbOF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -401.2120495372744,
			"y": 451.9687879625151,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 25.81597900390625,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682335955650,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"id": "cyLaCWBnzBYR-SmfgI3Ii",
			"type": "arrow",
			"x": -205.45247821103163,
			"y": 333.4466474595853,
			"width": 189.56905806717603,
			"height": 105.6334228515625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1042246820,
			"version": 145,
			"versionNonce": 1226801436,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682336082686,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					115.59225142655106,
					-0.95849609375
				],
				[
					118.39938033280106,
					-98.624267578125
				],
				[
					189.56905806717603,
					-105.6334228515625
				]
			],
			"lastCommittedPoint": [
				178.7200927734375,
				-105.6334228515625
			],
			"startBinding": null,
			"endBinding": {
				"elementId": "sRtzRbWioA-ZYFZndOzQo",
				"focus": 0.4017184327437513,
				"gap": 5.269184836113567
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "xkU9pBRUeRDog4GMGkWv1",
			"type": "arrow",
			"x": 287.186989656763,
			"y": 877.3168485709039,
			"width": 329.4471733159644,
			"height": 120.02867530628748,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1225254692,
			"version": 173,
			"versionNonce": 1392644764,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682336072136,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					293.63224124240446,
					-4.161042715669055
				],
				[
					329.4471733159644,
					-120.02867530628748
				]
			],
			"lastCommittedPoint": [
				329.4471733159644,
				-120.02867530628748
			],
			"startBinding": {
				"elementId": "Peb20v4Y9OuXOzjU7XGaD",
				"gap": 5.99891505226492,
				"focus": 0.04940491687982064
			},
			"endBinding": {
				"elementId": "3-sSW153Q7eEgj2ieLJiH",
				"gap": 1.3779593038030953,
				"focus": -0.09325265634126038
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "text",
			"version": 241,
			"versionNonce": 1050524,
			"isDeleted": false,
			"id": "7JqU15GH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 67.98855822594305,
			"y": 713.1675605024866,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 25.81597900390625,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682336074149,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Sí",
			"rawText": "Sí",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Sí",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 179,
			"versionNonce": 27793188,
			"isDeleted": true,
			"id": "Mi7bvWnC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 73.06015304023845,
			"y": 606.2647651801893,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14,
			"height": 35,
			"seed": 106916772,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682336077408,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "",
			"rawText": "",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "",
			"lineHeight": 1.25,
			"baseline": 24
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#228be6",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1305.8879371913195,
		"scrollY": 620.9747147561246,
		"zoom": {
			"value": 0.4216384416818619
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%