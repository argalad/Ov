---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^LbE79AmR

B ^TPvWrGzA

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "rectangle",
			"version": 73,
			"versionNonce": 86296250,
			"isDeleted": false,
			"id": "T8vNCgfAR3jiPDmf75Kn_",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -320.11783710061786,
			"y": -272.062102619186,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 865502694,
			"groupIds": [
				"sM47f67ctDk23roqxuUNA",
				"CEkQuwOc-0Hm-ZXK72yUP"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681761748864,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 68,
			"versionNonce": 1635490278,
			"isDeleted": false,
			"id": "LbE79AmR",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -302.2591029697585,
			"y": -261.2638085518032,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 832698874,
			"groupIds": [
				"sM47f67ctDk23roqxuUNA",
				"CEkQuwOc-0Hm-ZXK72yUP"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "De-FkccfRNLjJsHh7rvtF",
					"type": "arrow"
				}
			],
			"updated": 1681761748864,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 332,
			"versionNonce": 957341562,
			"isDeleted": false,
			"id": "vZjCABG1Lur2yX8b8vBJK",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -321.1419459873366,
			"y": -154.35339290238915,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 529477542,
			"groupIds": [
				"6rfbYWMg0BBUtJFuCOqCL",
				"CEkQuwOc-0Hm-ZXK72yUP"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "De-FkccfRNLjJsHh7rvtF",
					"type": "arrow"
				}
			],
			"updated": 1681761748864,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 212,
			"versionNonce": 133917990,
			"isDeleted": false,
			"id": "TPvWrGzA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -303.4500209385085,
			"y": -143.26924068070946,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1503625446,
			"groupIds": [
				"6rfbYWMg0BBUtJFuCOqCL",
				"CEkQuwOc-0Hm-ZXK72yUP"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681761748864,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "De-FkccfRNLjJsHh7rvtF",
			"type": "arrow",
			"x": -295.8006831699538,
			"y": -227.17608958818016,
			"width": 0.11553955078125,
			"height": 71.74952697753906,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"CEkQuwOc-0Hm-ZXK72yUP"
			],
			"roundness": {
				"type": 2
			},
			"seed": 435579302,
			"version": 301,
			"versionNonce": 429514810,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761748864,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.11553955078125,
					71.74952697753906
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "LbE79AmR",
				"focus": 0.01015400953661361,
				"gap": 9.087718963623047
			},
			"endBinding": {
				"elementId": "vZjCABG1Lur2yX8b8vBJK",
				"focus": 0.006889503423351878,
				"gap": 1.0731697082519531
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "line",
			"version": 185,
			"versionNonce": 998779002,
			"isDeleted": true,
			"id": "jeyEfMup5XITbnqAjNLBt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -271.5630885654616,
			"y": -250.72231990434227,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 131.75936889648438,
			"height": 0.8322601318359375,
			"seed": 999022822,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681761687209,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					131.75936889648438,
					0.8322601318359375
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 476.9006129795241,
		"scrollY": 334.94441157914696,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%