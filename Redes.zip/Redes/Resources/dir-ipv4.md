---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Identificador de red ^OhSn4JSJ

000...000 ^R9GJOItC

Red ^yasmdZ5j

Host ^TWIrKsQb

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"id": "KDJsbq_-cdiswgqNtnoa-",
			"type": "rectangle",
			"x": -413.396728515625,
			"y": -139.86151123046875,
			"width": 323,
			"height": 66,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 313692563,
			"version": 190,
			"versionNonce": 714359293,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "OhSn4JSJ"
				}
			],
			"updated": 1685208365147,
			"link": null,
			"locked": false
		},
		{
			"id": "OhSn4JSJ",
			"type": "text",
			"x": -351.9066390991211,
			"y": -119.36151123046875,
			"width": 200.0198211669922,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 896774877,
			"version": 26,
			"versionNonce": 713619315,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685208349346,
			"link": null,
			"locked": false,
			"text": "Identificador de red",
			"rawText": "Identificador de red",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "KDJsbq_-cdiswgqNtnoa-",
			"originalText": "Identificador de red",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 489,
			"versionNonce": 1520496531,
			"isDeleted": false,
			"id": "sCYXBRmiCXdVhrBiH-H7-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -89.96420288085938,
			"y": -140.61483764648438,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 196,
			"height": 66,
			"seed": 1401299411,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "R9GJOItC"
				}
			],
			"updated": 1685208371801,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 336,
			"versionNonce": 1285892147,
			"isDeleted": false,
			"id": "R9GJOItC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -41.46417999267578,
			"y": -120.11483764648438,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 98.99995422363281,
			"height": 25,
			"seed": 413691763,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685208341764,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "000...000",
			"rawText": "000...000",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "sCYXBRmiCXdVhrBiH-H7-",
			"originalText": "000...000",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"id": "yasmdZ5j",
			"type": "text",
			"x": -269.9642028808594,
			"y": -170.54013061523438,
			"width": 35.879974365234375,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 131752925,
			"version": 62,
			"versionNonce": 1849691165,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685208389842,
			"link": null,
			"locked": false,
			"text": "Red",
			"rawText": "Red",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "Red",
			"lineHeight": 1.25
		},
		{
			"id": "TWIrKsQb",
			"type": "text",
			"x": -15.708587646484375,
			"y": -172.2484130859375,
			"width": 44.25994873046875,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 233092349,
			"version": 38,
			"versionNonce": 1845049075,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685208387003,
			"link": null,
			"locked": false,
			"text": "Host",
			"rawText": "Host",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "Host",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#228be6",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 643.62109375,
		"scrollY": 429.7525634765625,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%