---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Cliente
(conexión activa) ^6wGYbTU5

Servidor
(conexión pasiva) ^SmpBEj2Z

Envío de segmento (SYN)
(SEQ = X) ^S47q7Ir2

Recepción de segmento (RST)
(SEQ=empty, ACK=x+1) ^10CcRiAt

Envío de segmento (RST)
(SEQ=empty, ACK=X+1) ^uc8FAv8Y

SYN ^abURTrR7

RST ^sjkfUIpo

Fin de Conexión
(Abrupta) ^Iv4Hs8R5

Mensajes en la red ^s7HmcFJs

Recepción del segmento (SYN)
(SEQ=x) ^M9zApkuH

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "line",
			"version": 343,
			"versionNonce": 712935792,
			"isDeleted": false,
			"id": "RYilpKBTbSbtrkUbOgmV2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.3914660418671,
			"y": -176.68490639558325,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 3.523881520990045,
			"height": 225.43013203266975,
			"seed": 1458263440,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633061779,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-3.523881520990045,
					225.43013203266975
				]
			]
		},
		{
			"type": "line",
			"version": 354,
			"versionNonce": 1390721936,
			"isDeleted": false,
			"id": "JDOStvwAsw3WCHHD5Ij2I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.07644896763122,
			"y": -175.6931314066398,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 2.0358893111508536,
			"height": 227.73446841102606,
			"seed": 1937621360,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633068705,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.0358893111508536,
					227.73446841102606
				]
			]
		},
		{
			"type": "text",
			"version": 137,
			"versionNonce": 1283622800,
			"isDeleted": false,
			"id": "6wGYbTU5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -215.75191497802734,
			"y": -233.2180938720703,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 165.35986328125,
			"height": 50,
			"seed": 847250320,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Cliente\n(conexión activa)",
			"rawText": "Cliente\n(conexión activa)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cliente\n(conexión activa)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 202,
			"versionNonce": 410483056,
			"isDeleted": false,
			"id": "SmpBEj2Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 0.907440185546875,
			"y": -230.6373748779297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.73985290527344,
			"height": 50,
			"seed": 1660513680,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617792562,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Servidor\n(conexión pasiva)",
			"rawText": "Servidor\n(conexión pasiva)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Servidor\n(conexión pasiva)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 73,
			"versionNonce": 1344287632,
			"isDeleted": false,
			"id": "S47q7Ir2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -335.1609164639435,
			"y": -155.22641481599427,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 192.4158935546875,
			"height": 40,
			"seed": 428913552,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "FIwLGyJ_gJZJbl7pvEsAU",
					"type": "arrow"
				}
			],
			"updated": 1685633103397,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Envío de segmento (SYN)\n(SEQ = X)",
			"rawText": "Envío de segmento (SYN)\n(SEQ = X)",
			"textAlign": "right",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Envío de segmento (SYN)\n(SEQ = X)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 243,
			"versionNonce": 2133701520,
			"isDeleted": false,
			"id": "10CcRiAt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -371.1769059476504,
			"y": -10.048560001836563,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 229.19989013671875,
			"height": 40,
			"seed": 2078676336,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685633021414,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Recepción de segmento (RST)\n(SEQ=empty, ACK=x+1)",
			"rawText": "Recepción de segmento (RST)\n(SEQ=empty, ACK=x+1)",
			"textAlign": "right",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Recepción de segmento (RST)\n(SEQ=empty, ACK=x+1)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 516,
			"versionNonce": 1599496560,
			"isDeleted": false,
			"id": "uc8FAv8Y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 85.27427984681492,
			"y": -61.179313778141676,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 197.56790161132812,
			"height": 40,
			"seed": 1772521360,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "FIwLGyJ_gJZJbl7pvEsAU",
					"type": "arrow"
				}
			],
			"updated": 1685633079123,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Envío de segmento (RST)\n(SEQ=empty, ACK=X+1)",
			"rawText": "Envío de segmento (RST)\n(SEQ=empty, ACK=X+1)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Envío de segmento (RST)\n(SEQ=empty, ACK=X+1)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "arrow",
			"version": 319,
			"versionNonce": 319588752,
			"isDeleted": false,
			"id": "FIwLGyJ_gJZJbl7pvEsAU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.0468521118164,
			"y": -137.10656930735306,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 211.06405535409658,
			"height": 50.518419279603506,
			"seed": 120972176,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "abURTrR7"
				}
			],
			"updated": 1685633093241,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "S47q7Ir2",
				"focus": -0.6383886263716677,
				"gap": 10.698170797439616
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					211.06405535409658,
					50.518419279603506
				]
			]
		},
		{
			"type": "text",
			"version": 11,
			"versionNonce": 1262023568,
			"isDeleted": false,
			"id": "abURTrR7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -39.937591552734375,
			"y": -117.52493776521305,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 28.287979125976562,
			"height": 20,
			"seed": 1155390864,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685632957070,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "SYN",
			"rawText": "SYN",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "FIwLGyJ_gJZJbl7pvEsAU",
			"originalText": "SYN",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 357,
			"versionNonce": 1157334384,
			"isDeleted": false,
			"id": "cyxRkKD0EyDsqf8vJsK7o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 78.10579690036056,
			"y": -49.96947257459257,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 213.0061408602462,
			"height": 57.23306959864311,
			"seed": 717133712,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "sjkfUIpo"
				}
			],
			"updated": 1685633145840,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "JVxZBJ1eEK6RF7GSdRAUy",
				"focus": 1.0143440132693444,
				"gap": 4.489064304581419
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-213.0061408602462,
					57.23306959864311
				]
			]
		},
		{
			"type": "text",
			"version": 80,
			"versionNonce": 1878032240,
			"isDeleted": false,
			"id": "sjkfUIpo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -45.4408048970739,
			"y": -31.271029477548808,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 33.43998718261719,
			"height": 20,
			"seed": 926345616,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685632994849,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "RST",
			"rawText": "RST",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "cyxRkKD0EyDsqf8vJsK7o",
			"originalText": "RST",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 220,
			"versionNonce": 199956880,
			"isDeleted": false,
			"id": "Iv4Hs8R5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -101.22933959613863,
			"y": 46.5874523296572,
			"strokeColor": "#e03131",
			"backgroundColor": "transparent",
			"width": 147.7998809814453,
			"height": 50,
			"seed": 31092624,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685633074542,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Fin de Conexión\n(Abrupta)",
			"rawText": "Fin de Conexión\n(Abrupta)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Fin de Conexión\n(Abrupta)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "text",
			"version": 92,
			"versionNonce": 1734974352,
			"isDeleted": false,
			"id": "s7HmcFJs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -99.1425552368164,
			"y": -165.72071838378906,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 150.367919921875,
			"height": 20,
			"seed": 909576592,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617908296,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Mensajes en la red",
			"rawText": "Mensajes en la red",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Mensajes en la red",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "text",
			"version": 652,
			"versionNonce": 937085296,
			"isDeleted": false,
			"id": "M9zApkuH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 85.72142908084265,
			"y": -106.5227803149514,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 228.25587463378906,
			"height": 40,
			"seed": 1195926896,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685632964559,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Recepción del segmento (SYN)\n(SEQ=x)",
			"rawText": "Recepción del segmento (SYN)\n(SEQ=x)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Recepción del segmento (SYN)\n(SEQ=x)",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"id": "dt1xlF3NTuWmGsywlCGMX",
			"type": "ellipse",
			"x": -192.48608136292933,
			"y": -165.41303882587667,
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"angle": 0,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 49496464,
			"version": 59,
			"versionNonce": 122853264,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685633130365,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 105,
			"versionNonce": 1204610960,
			"isDeleted": false,
			"id": "TnbZEo34cZiHZRvqF3Med",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 266.58021001582114,
			"y": -116.9104644119484,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"seed": 1849238928,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633137380,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 97,
			"versionNonce": 2023456656,
			"isDeleted": false,
			"id": "xtTBWMO70vf5ys84pB4al",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 232.6346470346869,
			"y": -70.259900600377,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"seed": 1256813968,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685633142166,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 94,
			"versionNonce": 1048430992,
			"isDeleted": false,
			"id": "JVxZBJ1eEK6RF7GSdRAUy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -192.6201294114203,
			"y": -21.481845544500203,
			"strokeColor": "#ffec99",
			"backgroundColor": "transparent",
			"width": 58.16308221254519,
			"height": 34.480654532347614,
			"seed": 371527056,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "cyxRkKD0EyDsqf8vJsK7o",
					"type": "arrow"
				}
			],
			"updated": 1685633145840,
			"link": null,
			"locked": false
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffec99",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 510.5196133596619,
		"scrollY": 342.01824555527907,
		"zoom": {
			"value": 1.1922632103916047
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%