---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Repetidor ^5ndQpCKW

Repetidor ^c7f6AHa0

Dominio de colisión ^tUfRZoc3

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.1",
	"elements": [
		{
			"type": "ellipse",
			"version": 748,
			"versionNonce": 759189579,
			"isDeleted": false,
			"id": "UoCEomYmYTyx0_jt_3Wkd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.1485515842606,
			"y": -406.52124199887623,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 1534.9111862478521,
			"height": 905.2051168699129,
			"seed": 2035219390,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 805,
			"versionNonce": 31714789,
			"isDeleted": false,
			"id": "-oMizb63vwG16B47gTJPc",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -285.0381164550781,
			"y": -121.94845543598524,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 382.14337158203125,
			"height": 2.6829833984375,
			"seed": 938903102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					382.14337158203125,
					-2.6829833984375
				]
			]
		},
		{
			"type": "rectangle",
			"version": 271,
			"versionNonce": 1896222443,
			"isDeleted": false,
			"id": "EIBmAF6d3pRlK-lnGY9LW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -245.61917114257812,
			"y": -244.4971004555165,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"Mi6sQO6zdwHVrJtsQgrbJ",
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 494,
			"versionNonce": 358017349,
			"isDeleted": false,
			"id": "kJWmN_0baDQkjZKKlxICw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -265.0248107910156,
			"y": -206.0452724525868,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"Mi6sQO6zdwHVrJtsQgrbJ",
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 279,
			"versionNonce": 1054538123,
			"isDeleted": false,
			"id": "AYY8EH5ZVzW7n-j_Eyye2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -236.70156860351562,
			"y": -237.1327968666493,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"Mi6sQO6zdwHVrJtsQgrbJ",
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 294,
			"versionNonce": 1804826789,
			"isDeleted": false,
			"id": "2RI0hpAgVaUNwIIjJz_gs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.42684936523438,
			"y": -197.59407006000868,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"Mi6sQO6zdwHVrJtsQgrbJ",
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 263,
			"versionNonce": 1677299755,
			"isDeleted": false,
			"id": "jRbJlHslOWgCuHwnihMIe",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -190.61587524414062,
			"y": -199.01472435688368,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"Mi6sQO6zdwHVrJtsQgrbJ",
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 319,
			"versionNonce": 507976709,
			"isDeleted": false,
			"id": "hKe0sVOFeVDU_EyBFtSgo",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.25765991210938,
			"y": -179.71606407856336,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"lm4TLttcX0SJuRpjj3dri"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 650,
			"versionNonce": 575427275,
			"isDeleted": false,
			"id": "hxc7eVgRjg7iNuxtgRBrU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -112.29852294921875,
			"y": -245.58276404643664,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"r5TA5AIhGXbwcqrLGy0jE",
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 873,
			"versionNonce": 896488293,
			"isDeleted": false,
			"id": "3q_ClYMISuFb_RdG8qgx5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.70416259765625,
			"y": -207.13093604350695,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"r5TA5AIhGXbwcqrLGy0jE",
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 658,
			"versionNonce": 443400555,
			"isDeleted": false,
			"id": "-p_Gw1h65C1jLrBkY9o-x",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -103.38092041015625,
			"y": -238.21846045756945,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"r5TA5AIhGXbwcqrLGy0jE",
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 673,
			"versionNonce": 1566154437,
			"isDeleted": false,
			"id": "wHgQ5RoGcFMv1_fRoLisu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -122.106201171875,
			"y": -198.67973365092882,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"r5TA5AIhGXbwcqrLGy0jE",
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 642,
			"versionNonce": 1973967883,
			"isDeleted": false,
			"id": "Kjh_IrULHhP0ibCfZcMFy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -57.29522705078125,
			"y": -200.10038794780382,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"r5TA5AIhGXbwcqrLGy0jE",
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 698,
			"versionNonce": 1554218533,
			"isDeleted": false,
			"id": "VeU8LPxwbomuLrbYE214L",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -86.93701171875,
			"y": -180.8017276694835,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"U39wfnGlMejLcoDGIbo_u"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 827,
			"versionNonce": 1341563563,
			"isDeleted": false,
			"id": "KG_rrghv15obZFBgb3eeO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -72.54046630859375,
			"y": 34.10456885600695,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 128,
			"height": 56,
			"seed": 26452158,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "5ndQpCKW"
				}
			],
			"updated": 1684346088566,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 515,
			"versionNonce": 1245344133,
			"isDeleted": false,
			"id": "5ndQpCKW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -54.56041717529297,
			"y": 49.60456885600695,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 92.03990173339844,
			"height": 25,
			"seed": 446593378,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088566,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Repetidor",
			"rawText": "Repetidor",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "KG_rrghv15obZFBgb3eeO",
			"originalText": "Repetidor",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 293,
			"versionNonce": 1644369227,
			"isDeleted": false,
			"id": "pIQ7uphzT7QW9c_Bte5tZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -316.6898498535156,
			"y": -136.93522606586805,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 552,
			"versionNonce": 56359141,
			"isDeleted": false,
			"id": "f9VjX5AiPWYEp6AzhNSFX",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 98.92657470703125,
			"y": -140.15103912353516,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 910,
			"versionNonce": 1797796843,
			"isDeleted": false,
			"id": "98sL9aBpDCqHrimbcdIaj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -181.1385498046875,
			"y": -66.97763136435766,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"Z_4De55lponpnGgfkv87h"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1133,
			"versionNonce": 1637192773,
			"isDeleted": false,
			"id": "V0z6omjg-u3Lg0CHdFScr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -200.544189453125,
			"y": -28.525803361427975,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"Z_4De55lponpnGgfkv87h"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 968,
			"versionNonce": 1534099083,
			"isDeleted": false,
			"id": "AHJziUd1Idhb85CKTDwQg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -172.220947265625,
			"y": -59.613327775490475,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"Z_4De55lponpnGgfkv87h"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 933,
			"versionNonce": 818201509,
			"isDeleted": false,
			"id": "U-LqlPD54Ih03risp6Y3I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -190.94622802734375,
			"y": -20.07460096884985,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"Z_4De55lponpnGgfkv87h"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 902,
			"versionNonce": 1033270571,
			"isDeleted": false,
			"id": "RmdnJBYot-hEk5Tknq_Mj",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -126.13525390625,
			"y": -21.49525526572485,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"Z_4De55lponpnGgfkv87h"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 918,
			"versionNonce": 1696007941,
			"isDeleted": false,
			"id": "6-oeNALWwsRR-3uKJbc9Q",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -155.70013427734375,
			"y": -123.64563063193579,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "line",
			"version": 204,
			"versionNonce": 1627690955,
			"isDeleted": false,
			"id": "5cQvUWq6mfN3LKNqe0Yzp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -9.890838623046875,
			"y": -123.42301940917969,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0855712890625,
			"height": 157.73126220703125,
			"seed": 392826238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.0855712890625,
					157.73126220703125
				]
			]
		},
		{
			"type": "line",
			"version": 207,
			"versionNonce": 285859429,
			"isDeleted": false,
			"id": "fAmbUYfdIkQSqGfupMC3I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 50.76478791138629,
			"y": -124.97637429275181,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 210.00354252864304,
			"height": 45.62080965531942,
			"seed": 165562174,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.7011201897275896,
					-45.62080965531942
				],
				[
					207.30242233891545,
					-45.57640720624943
				]
			]
		},
		{
			"type": "rectangle",
			"version": 884,
			"versionNonce": 1138058859,
			"isDeleted": false,
			"id": "yQJNVbnfiNnLjhkyTs-d1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 257.39581449896025,
			"y": -197.94508416750136,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 128,
			"height": 56,
			"seed": 26452158,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "c7f6AHa0"
				}
			],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 572,
			"versionNonce": 459983301,
			"isDeleted": false,
			"id": "c7f6AHa0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 275.37586363226103,
			"y": -182.44508416750136,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 92.03990173339844,
			"height": 25,
			"seed": 446593378,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Repetidor",
			"rawText": "Repetidor",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "yQJNVbnfiNnLjhkyTs-d1",
			"originalText": "Repetidor",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 1060,
			"versionNonce": 1020485899,
			"isDeleted": false,
			"id": "5JBlqZkq2vsZcS81xaMOU",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.32321347449414,
			"y": 55.613553517850846,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 382.14337158203125,
			"height": 2.6829833984375,
			"seed": 938903102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					382.14337158203125,
					-2.6829833984375
				]
			]
		},
		{
			"type": "rectangle",
			"version": 526,
			"versionNonce": 894912805,
			"isDeleted": false,
			"id": "mQnmNF4INxwrynfo14-QS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 218.74215878699414,
			"y": -66.9350915016804,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"LEUXG-x_x_LVrXQ90dHs1",
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 749,
			"versionNonce": 1702430635,
			"isDeleted": false,
			"id": "RFOlOGu5QuuJXNY3SCoVN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 199.33651913855664,
			"y": -28.483263498750716,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"LEUXG-x_x_LVrXQ90dHs1",
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 534,
			"versionNonce": 272424069,
			"isDeleted": false,
			"id": "KLVMdWDOWod8aFK-nZJXh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 227.65976132605664,
			"y": -59.570787912813216,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"LEUXG-x_x_LVrXQ90dHs1",
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 549,
			"versionNonce": 1139857995,
			"isDeleted": false,
			"id": "sYlQ5inoVYNBsreYdEY_e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 208.9344805643379,
			"y": -20.03206110617259,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"LEUXG-x_x_LVrXQ90dHs1",
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 518,
			"versionNonce": 1406731237,
			"isDeleted": false,
			"id": "9qUPYSYrpleNn2iiscFoZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 273.74545468543164,
			"y": -21.45271540304759,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"LEUXG-x_x_LVrXQ90dHs1",
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 574,
			"versionNonce": 890591467,
			"isDeleted": false,
			"id": "wXQnwDAY-R11hxidlYDcZ",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 244.1036700174629,
			"y": -2.154055124727279,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"s5tUVeWWvLeM9XCGUWh-g"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 905,
			"versionNonce": 1413037893,
			"isDeleted": false,
			"id": "8uos0fCPtMWy34VETysaV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 352.0628069803535,
			"y": -68.02075509260055,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"bxdabTr3lbXAnnyIhzpTa",
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1128,
			"versionNonce": 376505227,
			"isDeleted": false,
			"id": "SaxMxQFg5T2asJryvHOCi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 332.657167331916,
			"y": -29.568927089670865,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"bxdabTr3lbXAnnyIhzpTa",
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 913,
			"versionNonce": 129699493,
			"isDeleted": false,
			"id": "taH3zekblIosm8HT2rz1m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 360.980409519416,
			"y": -60.656451503733365,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"bxdabTr3lbXAnnyIhzpTa",
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 928,
			"versionNonce": 809392683,
			"isDeleted": false,
			"id": "e4QyG9Ow2EoPHUkNOjexf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 342.25512875769726,
			"y": -21.11772469709274,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"bxdabTr3lbXAnnyIhzpTa",
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 897,
			"versionNonce": 1024193029,
			"isDeleted": false,
			"id": "KICiymENhXQtr3WxgqMGx",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 407.066102878791,
			"y": -22.53837899396774,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"bxdabTr3lbXAnnyIhzpTa",
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 953,
			"versionNonce": 1600642251,
			"isDeleted": false,
			"id": "Hu8PKl2Ex9DQaJkkcyplg",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 377.42431821082226,
			"y": -3.2397187156474274,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"wFrRXa8whC8UTCPj5sNhi"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088567,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 548,
			"versionNonce": 287926629,
			"isDeleted": false,
			"id": "JXqBRbhUE69hWb3rSbeA4",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 147.67148007605664,
			"y": 40.626782887968034,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 807,
			"versionNonce": 2139622251,
			"isDeleted": false,
			"id": "cgiVGyz6Ybg8Y45qx2xs-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 563.2879046366035,
			"y": 37.41096983030093,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1250,
			"versionNonce": 627111109,
			"isDeleted": false,
			"id": "f1Y2ExLsNrU4vyYzINo-J",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 438.85503431773526,
			"y": 111.94457865888182,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"5zzYZ9BL-kuHxla7kpWsh"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1473,
			"versionNonce": 350840331,
			"isDeleted": false,
			"id": "Ng-kodsp0GD6G7mgJNm2r",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 419.44939466929776,
			"y": 150.3964066618115,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"5zzYZ9BL-kuHxla7kpWsh"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1308,
			"versionNonce": 357569573,
			"isDeleted": false,
			"id": "pTHCPLHNjqimy8SkmcGqk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 447.77263685679776,
			"y": 119.30888224774901,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"5zzYZ9BL-kuHxla7kpWsh"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1273,
			"versionNonce": 914779307,
			"isDeleted": false,
			"id": "8WOL3r1UpdRzXZdbQ51-d",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 429.047356095079,
			"y": 158.84760905438964,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"5zzYZ9BL-kuHxla7kpWsh"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1242,
			"versionNonce": 753158021,
			"isDeleted": false,
			"id": "NjSgyc5oZLnprefYvxdQO",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 493.8583302161727,
			"y": 157.42695475751464,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"5zzYZ9BL-kuHxla7kpWsh"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1258,
			"versionNonce": 940154699,
			"isDeleted": false,
			"id": "OxwnrvkrBhABhxCZSN79O",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 464.293449845079,
			"y": 55.2765793913037,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "line",
			"version": 452,
			"versionNonce": 1583025893,
			"isDeleted": false,
			"id": "KYLa14KSaPTZdLJH1DoyS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 321.9299108837525,
			"y": -143.09162326633754,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.11713953490050244,
			"height": 195.50861930847628,
			"seed": 1206707582,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.11713953490050244,
					195.50861930847628
				]
			]
		},
		{
			"type": "line",
			"version": 303,
			"versionNonce": 332234219,
			"isDeleted": false,
			"id": "E-9LUGfRx9k0mb-VCJlh8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 593.6759793674349,
			"y": -126.38094977330249,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 210.00354252864304,
			"height": 45.62080965531942,
			"seed": 165562174,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.7011201897275896,
					-45.62080965531942
				],
				[
					-207.30242233891545,
					-45.57640720624943
				]
			]
		},
		{
			"type": "line",
			"version": 1250,
			"versionNonce": 2017585733,
			"isDeleted": false,
			"id": "hOG4OJyGUkQY4wch7SQf6",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 544.4329764411556,
			"y": -125.77681470812689,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 382.14337158203125,
			"height": 2.6829833984375,
			"seed": 938903102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					382.14337158203125,
					-2.6829833984375
				]
			]
		},
		{
			"type": "rectangle",
			"version": 975,
			"versionNonce": 349997195,
			"isDeleted": false,
			"id": "EH10S1msupUN53F_1WO0b",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 721.9256852364925,
			"y": -249.73055823921362,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"XM0Tn8ThluIzfYL-CX-64",
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1198,
			"versionNonce": 460741029,
			"isDeleted": false,
			"id": "ZiQWfYbtqpLfIXj17T9cj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 702.520045588055,
			"y": -211.27873023628393,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"XM0Tn8ThluIzfYL-CX-64",
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 983,
			"versionNonce": 1089552171,
			"isDeleted": false,
			"id": "zUMJ0WTe5U40DzbvuoCWS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 730.843287775555,
			"y": -242.36625465034643,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"XM0Tn8ThluIzfYL-CX-64",
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 998,
			"versionNonce": 1898306821,
			"isDeleted": false,
			"id": "n5MjnF-oTzq7ziohZOoQG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 712.1180070138363,
			"y": -202.8275278437058,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"XM0Tn8ThluIzfYL-CX-64",
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 967,
			"versionNonce": 41296331,
			"isDeleted": false,
			"id": "NBBWmlsuu7yI6mD8p6h1N",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 776.92898113493,
			"y": -204.2481821405808,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"XM0Tn8ThluIzfYL-CX-64",
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1023,
			"versionNonce": 550368357,
			"isDeleted": false,
			"id": "n3RYEhclpZsZes3DwjCrS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 747.2871964669613,
			"y": -184.9495218622605,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"IO4-8jG-JAMs_tNb8PCkZ"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1354,
			"versionNonce": 310751339,
			"isDeleted": false,
			"id": "zflAkpeiVPyXpCcljL10Z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 855.2463334298519,
			"y": -250.81622183013377,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"U4uksAp0ccsW9cpSHEyXX",
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1577,
			"versionNonce": 104603589,
			"isDeleted": false,
			"id": "JGunkSp8p3ml8nK6waonJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 835.8406937814144,
			"y": -212.36439382720408,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"U4uksAp0ccsW9cpSHEyXX",
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1362,
			"versionNonce": 585788171,
			"isDeleted": false,
			"id": "atzHRA00v42vRDF-mr4Bn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 864.1639359689144,
			"y": -243.45191824126658,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"U4uksAp0ccsW9cpSHEyXX",
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1377,
			"versionNonce": 663609125,
			"isDeleted": false,
			"id": "GLuYzB9YtT_4PtGfJcQa6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 845.4386552071957,
			"y": -203.91319143462596,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"U4uksAp0ccsW9cpSHEyXX",
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1346,
			"versionNonce": 1209979307,
			"isDeleted": false,
			"id": "cVJT3h772jhzGrm_snkL7",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 910.2496293282894,
			"y": -205.33384573150096,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"U4uksAp0ccsW9cpSHEyXX",
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1402,
			"versionNonce": 1798353541,
			"isDeleted": false,
			"id": "z2YxZkuj67p00ed4bLRs1",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 880.6078446603207,
			"y": -186.03518545318065,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"S1j1zLSkqaVUGoDCXQtsE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 737,
			"versionNonce": 592274507,
			"isDeleted": false,
			"id": "d6VBeumBPheBOvwUB_X-H",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 512.7812430427181,
			"y": -140.5172986020204,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 997,
			"versionNonce": 232921573,
			"isDeleted": false,
			"id": "sim6oI9BFpLi1wtUAizAf",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 928.397667603265,
			"y": -143.9793983956768,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088568,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1614,
			"versionNonce": 1280353003,
			"isDeleted": false,
			"id": "IB3uQXMv1riIQTHO9iovl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 786.4063065743832,
			"y": -72.21108914805478,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"pnKUqLv4YpiUPxvntPFVR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1837,
			"versionNonce": 1487902021,
			"isDeleted": false,
			"id": "64a9Rw_rjObrfluZs46qE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 767.0006669259457,
			"y": -33.759261145125095,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"pnKUqLv4YpiUPxvntPFVR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1672,
			"versionNonce": 2075331979,
			"isDeleted": false,
			"id": "AlJkGARpqCIKUzFjFI8PE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 795.3239091134457,
			"y": -64.8467855591876,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"pnKUqLv4YpiUPxvntPFVR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1637,
			"versionNonce": 385262757,
			"isDeleted": false,
			"id": "WjkuhTzz4UdqO10UUK2BB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 776.5986283517269,
			"y": -25.30805875254697,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"pnKUqLv4YpiUPxvntPFVR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1606,
			"versionNonce": 1957635115,
			"isDeleted": false,
			"id": "rl2MKVxGP_jzz1Gh5EeyM",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 841.4096024728207,
			"y": -26.72871304942197,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"pnKUqLv4YpiUPxvntPFVR"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1576,
			"versionNonce": 1281673221,
			"isDeleted": false,
			"id": "APcnXJbDQrlywbHJHdIAz",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 812.0950113931123,
			"y": -128.8790884156329,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "line",
			"version": 262,
			"versionNonce": 791635659,
			"isDeleted": false,
			"id": "-_84UNilCbp6ibn9n5F4E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -8.252687855540303,
			"y": 88.16787373510651,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.0855712890625,
			"height": 157.73126220703125,
			"seed": 392826238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.0855712890625,
					157.73126220703125
				]
			]
		},
		{
			"type": "line",
			"version": 1039,
			"versionNonce": 720863077,
			"isDeleted": false,
			"id": "c2CTcQ8G5CiK3Kg80yP1q",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -280.02294621738747,
			"y": 248.40948630294457,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 382.14337158203125,
			"height": 2.6829833984375,
			"seed": 938903102,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					382.14337158203125,
					-2.6829833984375
				]
			]
		},
		{
			"type": "rectangle",
			"version": 505,
			"versionNonce": 1104041323,
			"isDeleted": false,
			"id": "x0IfNsRsIPhmjRTBzvMg0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -240.60400090488747,
			"y": 125.86084128341332,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"g_lpi2NQ55l98FtrWzzJd",
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 728,
			"versionNonce": 1224493765,
			"isDeleted": false,
			"id": "NpjLAd4DOjenCtHUuTdaU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -260.00964055332497,
			"y": 164.312669286343,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"g_lpi2NQ55l98FtrWzzJd",
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 513,
			"versionNonce": 198602763,
			"isDeleted": false,
			"id": "TWJtXEi2S8Qg0i8HlyqyH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -231.68639836582497,
			"y": 133.2251448722805,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"g_lpi2NQ55l98FtrWzzJd",
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 528,
			"versionNonce": 386968101,
			"isDeleted": false,
			"id": "1XJrJAc8Po1Gnizniyhgc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -250.41167912754372,
			"y": 172.76387167892113,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"g_lpi2NQ55l98FtrWzzJd",
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 497,
			"versionNonce": 524433067,
			"isDeleted": false,
			"id": "N-73cu2T2T1-vxlsLSovv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -185.60070500644997,
			"y": 171.34321738204613,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"g_lpi2NQ55l98FtrWzzJd",
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 553,
			"versionNonce": 371334533,
			"isDeleted": false,
			"id": "sJr0gLms-hjSBCQ0s4XB8",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -215.24248967441872,
			"y": 190.64187766036645,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"-1frT8G9C7Lx3JE6WBxz-"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 884,
			"versionNonce": 1790716235,
			"isDeleted": false,
			"id": "j4HoFJJrNzhM-tYPjCzpG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -107.2833527115281,
			"y": 124.77517769249317,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"EyyDZuF383ETK_Y8s61sO",
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1107,
			"versionNonce": 1299064037,
			"isDeleted": false,
			"id": "m2dAKOjc_mRI7c3AHE2uG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -126.6889923599656,
			"y": 163.22700569542286,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"EyyDZuF383ETK_Y8s61sO",
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 892,
			"versionNonce": 597608427,
			"isDeleted": false,
			"id": "kCHe1q1A5NNWUe6HJbeWX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -98.3657501724656,
			"y": 132.13948128136036,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"EyyDZuF383ETK_Y8s61sO",
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 907,
			"versionNonce": 8536133,
			"isDeleted": false,
			"id": "uLl_s9w9KDmgQKeoVAdQi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -117.09103093418435,
			"y": 171.67820808800099,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"EyyDZuF383ETK_Y8s61sO",
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 876,
			"versionNonce": 1878299275,
			"isDeleted": false,
			"id": "psc5ib7tYm7d-elk0qeeB",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -52.280056813090596,
			"y": 170.25755379112599,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"EyyDZuF383ETK_Y8s61sO",
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 932,
			"versionNonce": 624684965,
			"isDeleted": false,
			"id": "1WXOy_0xYWUrlbOX5UNaA",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -81.92184148105935,
			"y": 189.5562140694463,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [
				"yXM5dQK4dbAVfLfp9VgEX"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "rectangle",
			"version": 527,
			"versionNonce": 1350043947,
			"isDeleted": false,
			"id": "V-_XQi21sZZyiLZaP8sTs",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -311.67467961582497,
			"y": 233.42271567306176,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 786,
			"versionNonce": 432583429,
			"isDeleted": false,
			"id": "MDtSx8Q4gDqZmBehChpYf",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 103.9417449447219,
			"y": 230.20690261539465,
			"strokeColor": "#ffffff",
			"backgroundColor": "#353636",
			"width": 32.76068115234375,
			"height": 29.615524291992188,
			"seed": 1145733502,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1144,
			"versionNonce": 1251191755,
			"isDeleted": false,
			"id": "hTayygBBa8fCNQYnHCB08",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -176.12337956699685,
			"y": 303.38031037457216,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"XLgJtoOzq2Og6wENqzjBj"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1367,
			"versionNonce": 447089253,
			"isDeleted": false,
			"id": "HfSh5SoM65S8ciwo8QoMH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -195.52901921543435,
			"y": 341.83213837750185,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"XLgJtoOzq2Og6wENqzjBj"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1202,
			"versionNonce": 1382152811,
			"isDeleted": false,
			"id": "5uuleCHxd9qbeJaghaLwY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -167.20577702793435,
			"y": 310.74461396343935,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"XLgJtoOzq2Og6wENqzjBj"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1167,
			"versionNonce": 2023847365,
			"isDeleted": false,
			"id": "EdtBx7mca4pRobi65xGdR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -185.9310577896531,
			"y": 350.28334077008,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"XLgJtoOzq2Og6wENqzjBj"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1136,
			"versionNonce": 1957524747,
			"isDeleted": false,
			"id": "vSduodwTNoj4qYf5R3K1V",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -121.12008366855935,
			"y": 348.862686473205,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"XLgJtoOzq2Og6wENqzjBj"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 1152,
			"versionNonce": 249066789,
			"isDeleted": false,
			"id": "ACk2btIG65sHX6jlIy67T",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -150.6849640396531,
			"y": 246.71231110699404,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.45361328125,
			"height": 55.906219482421875,
			"seed": 1472673662,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1684346088569,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.45361328125,
					55.906219482421875
				]
			]
		},
		{
			"type": "line",
			"version": 679,
			"versionNonce": 1089510315,
			"isDeleted": false,
			"id": "-gEV9U-Ndm1R5uQ78rw5z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 26.736238016897982,
			"y": 172.92285252130569,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"xET3a-T09BTWS38PPssG9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 330,
			"versionNonce": 2025359493,
			"isDeleted": false,
			"id": "adLWjskbXWi2OTkcJl3LU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 16.75728545901173,
			"y": 131.7620579171646,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 1.0528994064730421,
			"height": 67.7116277916612,
			"seed": 1067548862,
			"groupIds": [
				"xET3a-T09BTWS38PPssG9"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.0528994064730421,
					67.7116277916612
				]
			]
		},
		{
			"type": "line",
			"version": 712,
			"versionNonce": 1935011403,
			"isDeleted": false,
			"id": "_j0crf3obqAw_ivKOL-TZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 24.95378623204479,
			"y": -25.04586764146049,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"0J7Y-_lDVIq_AzJpR_pgt"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 363,
			"versionNonce": 134164453,
			"isDeleted": false,
			"id": "MVNDzorzLaJqzFRANcb5u",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 14.974833674158548,
			"y": -66.20666224560156,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 1.0528994064730421,
			"height": 67.7116277916612,
			"seed": 1067548862,
			"groupIds": [
				"0J7Y-_lDVIq_AzJpR_pgt"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.0528994064730421,
					67.7116277916612
				]
			]
		},
		{
			"type": "line",
			"version": 716,
			"versionNonce": 1589112043,
			"isDeleted": false,
			"id": "Gq81v-uvy1latduPQ5Yri",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 232.5394346325037,
			"y": -112.30884232983962,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"lpVxPfTXeJgxksZXl8D7f"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 367,
			"versionNonce": 2059004741,
			"isDeleted": false,
			"id": "zB8uTIzg-uBXcyfw_Waxy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 222.5604820746175,
			"y": -153.4696369339807,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 1.0528994064730421,
			"height": 67.7116277916612,
			"seed": 1067548862,
			"groupIds": [
				"lpVxPfTXeJgxksZXl8D7f"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.0528994064730421,
					67.7116277916612
				]
			]
		},
		{
			"type": "line",
			"version": 882,
			"versionNonce": 379656075,
			"isDeleted": false,
			"id": "kB6WFq61pKAUlHoTmH_SR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.25682137896627,
			"y": -183.87381979682283,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"GRi6Ps0gTOurtCOVsCViz"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 571,
			"versionNonce": 1900427941,
			"isDeleted": false,
			"id": "W2EUMYLH3Qml-I8AsxKSG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 125.60381879415722,
			"y": -226.7744016572359,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.32961003110718,
			"height": 0.672710329802328,
			"seed": 1067548862,
			"groupIds": [
				"GRi6Ps0gTOurtCOVsCViz"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					69.32961003110718,
					-0.672710329802328
				]
			]
		},
		{
			"type": "line",
			"version": 1025,
			"versionNonce": 1498148395,
			"isDeleted": false,
			"id": "WXJm235y0NGsBDTS2RY-T",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 449.9680578320719,
			"y": -187.41317052470512,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"oVwIU1SOSHiaj2bkYcYgl"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 714,
			"versionNonce": 609328645,
			"isDeleted": false,
			"id": "0KPsj3ZoK4bixhJh2NGR7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 396.3150552472629,
			"y": -230.3137523851182,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.32961003110718,
			"height": 0.672710329802328,
			"seed": 1067548862,
			"groupIds": [
				"oVwIU1SOSHiaj2bkYcYgl"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					69.32961003110718,
					-0.672710329802328
				]
			]
		},
		{
			"type": "line",
			"version": 933,
			"versionNonce": 966979787,
			"isDeleted": false,
			"id": "tUiUTAbOUBcLpAuhEzbGk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -9.553119203678847,
			"y": -183.27491628198783,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 69.12384616358922,
			"height": 8.854852759545924,
			"seed": 1036951586,
			"groupIds": [
				"wuS54_6x9ZnFRYJ0VnWYY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					9.823074136893995,
					0
				],
				[
					9.823074136893995,
					-7.9718104678299655
				],
				[
					19.939658086076435,
					-8.007353646337794
				],
				[
					19.939658086076435,
					-0.049210632229161534
				],
				[
					29.298524519559237,
					-0.3991247434085634
				],
				[
					28.720518222066186,
					-7.897994519486216
				],
				[
					40.433315408882436,
					-7.742173848814483
				],
				[
					40.25061398737789,
					0
				],
				[
					49.4657370766094,
					0
				],
				[
					49.4657370766094,
					-8.55412978351477
				],
				[
					60.45080421508542,
					-8.55412978351477
				],
				[
					60.45080421508542,
					0.30072297603115405
				],
				[
					69.12384616358922,
					-1.131786050028031
				]
			]
		},
		{
			"type": "arrow",
			"version": 584,
			"versionNonce": 1524208997,
			"isDeleted": false,
			"id": "ypxt7qBZ_aydCeYnGyjWO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -19.532071761565092,
			"y": -224.4357108861289,
			"strokeColor": "#fbff00",
			"backgroundColor": "transparent",
			"width": 1.0528994064730421,
			"height": 67.7116277916612,
			"seed": 1067548862,
			"groupIds": [
				"wuS54_6x9ZnFRYJ0VnWYY"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-1.0528994064730421,
					67.7116277916612
				]
			]
		},
		{
			"type": "text",
			"version": 410,
			"versionNonce": 155230059,
			"isDeleted": false,
			"id": "tUfRZoc3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 357.92973450851116,
			"y": 340.58883340697,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 435.5277099609375,
			"height": 61.437241880063,
			"seed": 942180286,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1684346088570,
			"link": null,
			"locked": false,
			"fontSize": 49.1497935040504,
			"fontFamily": 1,
			"text": "Dominio de colisión",
			"rawText": "Dominio de colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio de colisión",
			"lineHeight": 1.25,
			"baseline": 43
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#fbff00",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 514.2289997201001,
		"scrollY": 487.8091407172401,
		"zoom": {
			"value": 0.8
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%