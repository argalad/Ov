---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
802.11
FHSS ^RV24zTFz

802.11
DSSS ^hnEEahEh

802.11
Infrared ^HgJo9rsr

802.11
DSSS ^Lv0VROWU

802.11a
OFDM ^mq1j86pw

802.11g
DSSS ^VH446Y0L

Distributed coordination function (DCF) ^rCGaFxH6

Point coordination function (PCF) ^43fkjUHV

Physical
layer ^GzFj79uJ

IEEE 802.2 ^K61X3CI2

MAC
sublayer ^RrKKvnDI

Servicio libre de colisiones
(centralizado) ^IljbQEPM

Servicio con posibilidad
de colisión (distribuido) ^VwGiYYpM

Data link
layer ^jXj3sSvv

LLC
sublayer ^7He76jdO

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"id": "RV24zTFz",
			"type": "text",
			"x": -386.09619903564453,
			"y": -14.290046691894531,
			"width": 47.69596862792969,
			"height": 40,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 568116578,
			"version": 165,
			"versionNonce": 1983932258,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"text": "802.11\nFHSS",
			"rawText": "802.11\nFHSS",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 34,
			"containerId": null,
			"originalText": "802.11\nFHSS",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 192,
			"versionNonce": 1508227006,
			"isDeleted": false,
			"id": "hnEEahEh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -310.0513432820638,
			"y": -14.254361470540346,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 47.69596862792969,
			"height": 40,
			"seed": 568116578,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "802.11\nDSSS",
			"rawText": "802.11\nDSSS",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "802.11\nDSSS",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 203,
			"versionNonce": 1782655778,
			"isDeleted": false,
			"id": "HgJo9rsr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -244.38006591796875,
			"y": -13.833218892415346,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.25592041015625,
			"height": 40,
			"seed": 568116578,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "802.11\nInfrared",
			"rawText": "802.11\nInfrared",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "802.11\nInfrared",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 204,
			"versionNonce": 907284478,
			"isDeleted": false,
			"id": "Lv0VROWU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -158.37133026123047,
			"y": -14.005744934082088,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 47.69596862792969,
			"height": 40,
			"seed": 568116578,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "802.11\nDSSS",
			"rawText": "802.11\nDSSS",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "802.11\nDSSS",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 209,
			"versionNonce": 1895003874,
			"isDeleted": false,
			"id": "mq1j86pw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -87.1850306193034,
			"y": -14.51091257731116,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 58.36796569824219,
			"height": 40,
			"seed": 568116578,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "802.11a\nOFDM",
			"rawText": "802.11a\nOFDM",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "802.11a\nOFDM",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"type": "text",
			"version": 251,
			"versionNonce": 1666015294,
			"isDeleted": false,
			"id": "VH446Y0L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -9.22279103597009,
			"y": -14.151985168457031,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 55.71195983886719,
			"height": 40,
			"seed": 568116578,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423260,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "802.11g\nDSSS",
			"rawText": "802.11g\nDSSS",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "802.11g\nDSSS",
			"lineHeight": 1.25,
			"baseline": 34
		},
		{
			"id": "pXrbU-AyrgidWWm7rPRoX",
			"type": "rectangle",
			"x": -395.901201883952,
			"y": -23.749544779459654,
			"width": 451.448933919271,
			"height": 55.77071126302087,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 1846524542,
			"version": 205,
			"versionNonce": 1256606370,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false
		},
		{
			"id": "fqO0q135sq69hbb6yJWEN",
			"type": "line",
			"x": -322.3694229125978,
			"y": -24.00629933675134,
			"width": 1.0869140625,
			"height": 55.73649088541674,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 866623394,
			"version": 90,
			"versionNonce": 1970448510,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.0869140625,
					55.73649088541674
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "2az5DEKs3cG6m704Xbw_s",
			"type": "line",
			"x": -247.30293528238946,
			"y": -23.869356791178404,
			"width": 0.5135091145833144,
			"height": 55.72222900390625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1053619746,
			"version": 68,
			"versionNonce": 1321772642,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.5135091145833144,
					55.72222900390625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "wOCz62kOJRWeG-V84bgpN",
			"type": "line",
			"x": -171.16662343343114,
			"y": -24.328646341959654,
			"width": 0.27958170572912877,
			"height": 56.50386555989587,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1181583970,
			"version": 119,
			"versionNonce": 1548019902,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.27958170572912877,
					56.50386555989587
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "cggWYKv8zpge7mAAXoiXf",
			"type": "line",
			"x": -94.17166900634777,
			"y": -24.285860697428404,
			"width": 0.6561279296875,
			"height": 56.21571858723962,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2769186,
			"version": 98,
			"versionNonce": 627673634,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.6561279296875,
					56.21571858723962
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "cYQ7DdCfZUky-9AiNBkk5",
			"type": "line",
			"x": -17.841428120931084,
			"y": -23.64684295654297,
			"width": 0.8614908854166288,
			"height": 55.5111083984375,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 177681826,
			"version": 78,
			"versionNonce": 1734680830,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.8614908854166288,
					55.5111083984375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "rectangle",
			"version": 315,
			"versionNonce": 95942114,
			"isDeleted": false,
			"id": "yYFVxmF2w8KDFhdQJR6Il",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -396.59940338134777,
			"y": -90.42506154378256,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"width": 452,
			"height": 56,
			"seed": 1846524542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "rCGaFxH6"
				}
			],
			"updated": 1682183423261,
			"link": null,
			"locked": false
		},
		{
			"id": "rCGaFxH6",
			"type": "text",
			"x": -364.18921661376964,
			"y": -74.92506154378256,
			"width": 387.17962646484375,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 612441086,
			"version": 78,
			"versionNonce": 1247039806,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"text": "Distributed coordination function (DCF)",
			"rawText": "Distributed coordination function (DCF)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 17,
			"containerId": "yYFVxmF2w8KDFhdQJR6Il",
			"originalText": "Distributed coordination function (DCF)",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 1092,
			"versionNonce": 1891821986,
			"isDeleted": false,
			"id": "qd55hk_NnoofX6u5Tn7hw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -395.34871164957707,
			"y": -152.4838638305659,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 321,
			"height": 60,
			"seed": 1846524542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "43fkjUHV"
				},
				{
					"id": "zPMGV6LI7Ou2XGH1sXGMs",
					"type": "arrow"
				}
			],
			"updated": 1682183423261,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 872,
			"versionNonce": 544438654,
			"isDeleted": false,
			"id": "43fkjUHV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -370.45859018961613,
			"y": -147.4838638305659,
			"strokeColor": "#ffffff",
			"backgroundColor": "#e64980",
			"width": 271.2197570800781,
			"height": 50,
			"seed": 612441086,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Point coordination function \n(PCF)",
			"rawText": "Point coordination function (PCF)",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "qd55hk_NnoofX6u5Tn7hw",
			"originalText": "Point coordination function (PCF)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"id": "7dai4d1cLDVL8NUNEnp-X",
			"type": "line",
			"x": -512.9801966349285,
			"y": 31.923387638105623,
			"width": 96.97259521484375,
			"height": 0.849395751953125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 996707838,
			"version": 115,
			"versionNonce": 1840866658,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					96.97259521484375,
					-0.849395751953125
				]
			],
			"lastCommittedPoint": [
				96.97259521484375,
				-0.849395751953125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 162,
			"versionNonce": 1896061374,
			"isDeleted": false,
			"id": "0w335ixD0TkVlTQrZcBdV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -512.7690561475854,
			"y": -20.540810280005836,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 96.97259521484375,
			"height": 0.849395751953125,
			"seed": 996707838,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					96.97259521484375,
					-0.849395751953125
				]
			]
		},
		{
			"id": "uqqDMnM1As40-g4Gh8ylm",
			"type": "arrow",
			"x": -508.3187281290691,
			"y": -21.26357830427719,
			"width": 0.109130859375,
			"height": 51.94590759277344,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2028646462,
			"version": 251,
			"versionNonce": 1172990242,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.07275390625,
					15.376876831054688
				],
				[
					0.036376953125,
					51.94590759277344
				]
			],
			"lastCommittedPoint": [
				0.036376953125,
				51.94590759277344
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		},
		{
			"id": "GzFj79uJ",
			"type": "text",
			"x": -592.0421168009441,
			"y": -12.720899471269377,
			"width": 61.08795166015625,
			"height": 40,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1054685730,
			"version": 29,
			"versionNonce": 858108414,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"text": "Physical\nlayer",
			"rawText": "Physical\nlayer",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 34,
			"containerId": null,
			"originalText": "Physical\nlayer",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 318,
			"versionNonce": 1086649570,
			"isDeleted": false,
			"id": "VoeRbJmnmkH9c8FQH_-tK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -395.9826990763347,
			"y": -254.547956356035,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 452,
			"height": 56,
			"seed": 1846524542,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "K61X3CI2"
				},
				{
					"id": "rikvPb4mDHfpVhhNOlFk7",
					"type": "arrow"
				}
			],
			"updated": 1682183423261,
			"link": null,
			"locked": false
		},
		{
			"id": "K61X3CI2",
			"type": "text",
			"x": -219.72667185465502,
			"y": -236.547956356035,
			"width": 99.48794555664062,
			"height": 20,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 248193598,
			"version": 17,
			"versionNonce": 1373291070,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"text": "IEEE 802.2",
			"rawText": "IEEE 802.2",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 14,
			"containerId": "VoeRbJmnmkH9c8FQH_-tK",
			"originalText": "IEEE 802.2",
			"lineHeight": 1.25
		},
		{
			"id": "d_FQx2R2HS2nZEn_bRf6B",
			"type": "line",
			"x": -416.24228159586596,
			"y": -151.48811138533188,
			"width": 32.369140625,
			"height": 0.6140594482421875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 732882750,
			"version": 139,
			"versionNonce": 1607993506,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-32.369140625,
					-0.6140594482421875
				]
			],
			"lastCommittedPoint": [
				-32.369140625,
				-0.6140594482421875
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "sMvxNB2WWlk02qHsZFp6-",
			"type": "arrow",
			"x": -431.3838221232097,
			"y": -151.070905574785,
			"width": 0.36370849609375,
			"height": 128.52011108398438,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1526965026,
			"version": 94,
			"versionNonce": 805554814,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.36370849609375,
					128.52011108398438
				]
			],
			"lastCommittedPoint": [
				0.36370849609375,
				128.52011108398438
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		},
		{
			"id": "RrKKvnDI",
			"type": "text",
			"x": -492.03187815348315,
			"y": -100.99259746931625,
			"width": 52.212371826171854,
			"height": 32.673598694503625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 162478114,
			"version": 299,
			"versionNonce": 243217058,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183435927,
			"link": null,
			"locked": false,
			"text": "MAC\nsublayer",
			"rawText": "MAC\nsublayer",
			"fontSize": 13.069439477801446,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 27.000000000000014,
			"containerId": null,
			"originalText": "MAC\nsublayer",
			"lineHeight": 1.25
		},
		{
			"id": "IljbQEPM",
			"type": "text",
			"x": -241.12569681803393,
			"y": -193.120710262285,
			"width": 165.3369598388672,
			"height": 32.815390538433384,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 75446270,
			"version": 325,
			"versionNonce": 744606398,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"text": "Servicio libre de colisiones\n(centralizado)",
			"rawText": "Servicio libre de colisiones\n(centralizado)",
			"fontSize": 13.12615621537335,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 27.000000000000007,
			"containerId": null,
			"originalText": "Servicio libre de colisiones\n(centralizado)",
			"lineHeight": 1.25
		},
		{
			"id": "zPMGV6LI7Ou2XGH1sXGMs",
			"type": "arrow",
			"x": -260.2195154825847,
			"y": -198.8980997886522,
			"width": 0.4740607162764263,
			"height": 45.414235958086294,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 146111138,
			"version": 186,
			"versionNonce": 461621282,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.378692626953125,
					18.673919677734375
				],
				[
					-0.09536808932330132,
					45.414235958086294
				]
			],
			"lastCommittedPoint": [
				-0.109130859375,
				46.1905517578125
			],
			"startBinding": null,
			"endBinding": {
				"elementId": "qd55hk_NnoofX6u5Tn7hw",
				"gap": 1,
				"focus": -0.16155654762080263
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "rikvPb4mDHfpVhhNOlFk7",
			"type": "arrow",
			"x": -35.22104136149093,
			"y": -197.547956356035,
			"width": 2.5096435546875,
			"height": 108.3609619140625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 458133474,
			"version": 237,
			"versionNonce": 630571774,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.842170943040401e-14,
					31.52789306640625
				],
				[
					1.6560058593749716,
					67.26251220703125
				],
				[
					2.5096435546874716,
					108.3609619140625
				]
			],
			"lastCommittedPoint": [
				2.5096435546875,
				109.32627868652344
			],
			"startBinding": {
				"elementId": "VoeRbJmnmkH9c8FQH_-tK",
				"gap": 1,
				"focus": -0.5962905208621405
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "text",
			"version": 474,
			"versionNonce": 2044359650,
			"isDeleted": false,
			"id": "VwGiYYpM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -10.660090128580805,
			"y": -165.8694547258376,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 146.32713317871094,
			"height": 32.81539053843338,
			"seed": 75446270,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"fontSize": 13.12615621537335,
			"fontFamily": 1,
			"text": "Servicio con posibilidad\nde colisión (distribuido)",
			"rawText": "Servicio con posibilidad\nde colisión (distribuido)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Servicio con posibilidad\nde colisión (distribuido)",
			"lineHeight": 1.25,
			"baseline": 27
		},
		{
			"type": "line",
			"version": 253,
			"versionNonce": 2116072254,
			"isDeleted": false,
			"id": "b9MA12m4x8xKsrAbr-UCw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -513.570966547976,
			"y": -252.70863407150975,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 96.97259521484375,
			"height": 0.849395751953125,
			"seed": 996707838,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					96.97259521484375,
					-0.849395751953125
				]
			]
		},
		{
			"id": "YCZ7tzqzvXQAkZ0v5Kwb_",
			"type": "arrow",
			"x": -508.15057627360034,
			"y": -253.4369715537889,
			"width": 0.417205810546875,
			"height": 228.94159698486328,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1395008162,
			"version": 533,
			"versionNonce": 520940578,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183462004,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.417205810546875,
					228.94159698486328
				]
			],
			"lastCommittedPoint": [
				1.322235107421875,
				207.37503814697266
			],
			"startBinding": {
				"elementId": "7He76jdO",
				"focus": 1.601979669185087,
				"gap": 15.961410522460938
			},
			"endBinding": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		},
		{
			"id": "jXj3sSvv",
			"type": "text",
			"x": -605.4139963785808,
			"y": -155.77094829939438,
			"width": 73.83995056152344,
			"height": 40,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 497928994,
			"version": 148,
			"versionNonce": 543398782,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"text": "Data link\nlayer",
			"rawText": "Data link\nlayer",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 34,
			"containerId": null,
			"originalText": "Data link\nlayer",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 184,
			"versionNonce": 1037329250,
			"isDeleted": false,
			"id": "9EKF9ygizF-nhO1IBI0Kc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -417.4145550257543,
			"y": -199.17041333034268,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"width": 32.369140625,
			"height": 0.6140594482421875,
			"seed": 732882750,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682183423261,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-32.369140625,
					-0.6140594482421875
				]
			]
		},
		{
			"id": "_M2mc9jH0Qh-KsdtS0ilR",
			"type": "arrow",
			"x": -432.1776148478191,
			"y": -253.54731548689438,
			"width": 0.77880859375,
			"height": 54.7059326171875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2009322146,
			"version": 548,
			"versionNonce": 2023692258,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682183462004,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.31878662109375,
					34.32466125488281
				],
				[
					-0.46002197265625,
					54.7059326171875
				]
			],
			"lastCommittedPoint": [
				-0.46002197265625,
				54.7059326171875
			],
			"startBinding": {
				"elementId": "7He76jdO",
				"focus": -1.2808114406626856,
				"gap": 13.057632446289062
			},
			"endBinding": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow"
		},
		{
			"id": "7He76jdO",
			"type": "text",
			"x": -492.1891657511394,
			"y": -240.4896830406053,
			"width": 52.6916198730469,
			"height": 32.97350382830702,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fab005",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 648765922,
			"version": 865,
			"versionNonce": 912805694,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "YCZ7tzqzvXQAkZ0v5Kwb_",
					"type": "arrow"
				},
				{
					"id": "_M2mc9jH0Qh-KsdtS0ilR",
					"type": "arrow"
				}
			],
			"updated": 1682183462004,
			"link": null,
			"locked": false,
			"text": "LLC\nsublayer",
			"rawText": "LLC\nsublayer",
			"fontSize": 13.189401531322803,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 28.000000000000007,
			"containerId": null,
			"originalText": "LLC\nsublayer",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#fab005",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 689.6067072550456,
		"scrollY": 332.09209621809555,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%