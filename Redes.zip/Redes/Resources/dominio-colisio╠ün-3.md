---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Dominio de colisión ^ROdlXOaC

Max. 5m ^9XafJnxT

HUB
100BASE-TX ^srhmiG3Z

HUB
100BASE-TX ^xZgBQlxl

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "ellipse",
			"version": 1350,
			"versionNonce": 1940755362,
			"isDeleted": false,
			"id": "_TJIR1nUoxI-7Fm9eNPcw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -861.7455091819375,
			"y": -221.90985183719079,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 838.6581180385092,
			"height": 472.3444609697902,
			"seed": 2035219390,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170607085,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 741,
			"versionNonce": 2034713534,
			"isDeleted": false,
			"id": "ROdlXOaC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -552.4548132149616,
			"y": 196.7987539531212,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 248.16387939453125,
			"height": 35,
			"seed": 942180286,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170511683,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Dominio de colisión",
			"rawText": "Dominio de colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio de colisión",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "rectangle",
			"version": 1394,
			"versionNonce": 373243938,
			"isDeleted": false,
			"id": "XVvqRP40sPwJdU9RiWICf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -735.6108827025167,
			"y": 75.87262341057868,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"nhmresaLDMCqmPxGqwC51"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1617,
			"versionNonce": 1617808126,
			"isDeleted": false,
			"id": "DjQgqKLs49RqS6pLoED8G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -755.0165223509542,
			"y": 114.32445141350837,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"nhmresaLDMCqmPxGqwC51"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1452,
			"versionNonce": 2120674274,
			"isDeleted": false,
			"id": "AXE5pp-xgQvvqqiaLgN17",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -726.6932801634542,
			"y": 83.23692699944587,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"nhmresaLDMCqmPxGqwC51"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1417,
			"versionNonce": 817347390,
			"isDeleted": false,
			"id": "GXmLBhEjd-ByrsI7FWquQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -745.418560925173,
			"y": 122.7756538060865,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"nhmresaLDMCqmPxGqwC51"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1386,
			"versionNonce": 606281634,
			"isDeleted": false,
			"id": "crviQSy57SPJYDJ9bh11z",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -680.6075868040792,
			"y": 121.3549995092115,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"nhmresaLDMCqmPxGqwC51"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 293,
			"versionNonce": 1753248958,
			"isDeleted": false,
			"id": "wxlAyuNZFhpzY4lsfwNdG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -530.9465796206177,
			"y": -99.78170396363885,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 196.9490966796875,
			"height": 0.2481689453125,
			"seed": 1024435874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170511684,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					196.9490966796875,
					0.2481689453125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1475,
			"versionNonce": 2061083518,
			"isDeleted": false,
			"id": "kbUXr_GxWKOON4OdNtRmI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -635.6032533079855,
			"y": 75.87134167229743,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"44Bg759xyMrXfWL8tw8Jc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1698,
			"versionNonce": 1940052834,
			"isDeleted": false,
			"id": "mCGT8iGZuYRDLXpiHWAsF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -655.008892956423,
			"y": 114.32316967522712,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"44Bg759xyMrXfWL8tw8Jc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1533,
			"versionNonce": 823428030,
			"isDeleted": false,
			"id": "KGVymWJ5zAQI71yOPnpa9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -626.685650768923,
			"y": 83.23564526116462,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"44Bg759xyMrXfWL8tw8Jc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1498,
			"versionNonce": 2067078946,
			"isDeleted": false,
			"id": "ScEUoRn5h66uR7z-4S6wt",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -645.4109315306417,
			"y": 122.77437206780525,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"44Bg759xyMrXfWL8tw8Jc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1467,
			"versionNonce": 1435065342,
			"isDeleted": false,
			"id": "AdyofhaA64sVC88-uRQFo",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -580.599957409548,
			"y": 121.35371777093025,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"44Bg759xyMrXfWL8tw8Jc"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1407,
			"versionNonce": 659090146,
			"isDeleted": false,
			"id": "qS0XAMUO_PAyCdzxv8BxB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -532.7926453978292,
			"y": 76.24960705315681,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"JhOHuQ-mzSSK9hZ1QiO2N"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1630,
			"versionNonce": 2117676094,
			"isDeleted": false,
			"id": "EmNjey3AV-JwPI1KNEAxD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -552.1982850462667,
			"y": 114.7014350560865,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"JhOHuQ-mzSSK9hZ1QiO2N"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1465,
			"versionNonce": 2121088674,
			"isDeleted": false,
			"id": "F0U3_uidBYJaGk0XfiEK5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -523.8750428587667,
			"y": 83.613910642024,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"JhOHuQ-mzSSK9hZ1QiO2N"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1430,
			"versionNonce": 1493496958,
			"isDeleted": false,
			"id": "CRXJJUGQTx-vXh5NY0Vp3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -542.6003236204855,
			"y": 123.15263744866462,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"JhOHuQ-mzSSK9hZ1QiO2N"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1399,
			"versionNonce": 1565596258,
			"isDeleted": false,
			"id": "aP7AjATdJwkOkyLRMD9VS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -477.78934949939173,
			"y": 121.73198315178962,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"JhOHuQ-mzSSK9hZ1QiO2N"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 265,
			"versionNonce": 799913150,
			"isDeleted": false,
			"id": "ddiftyhdRe9UwtrNMh34V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -709.3053712279074,
			"y": 75.98627850091071,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 256,
			"versionNonce": 851672610,
			"isDeleted": false,
			"id": "xax3jhp5qGnFy7wYZlVu1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -609.4700440794699,
			"y": -53.91810992682411,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 128.9801025390625,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					128.9801025390625
				]
			]
		},
		{
			"type": "line",
			"version": 261,
			"versionNonce": 1809083646,
			"isDeleted": false,
			"id": "H5VNxxqNkvz1SNT9Akka1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -572.7769288450949,
			"y": -53.92238238776161,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 64.90509033203125,
			"height": 129.9385986328125,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					64.90509033203125,
					129.9385986328125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1512,
			"versionNonce": 1001613794,
			"isDeleted": false,
			"id": "1AZ3d0OqF56fcwwYUtah4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -383.0568665892356,
			"y": 79.38046521572767,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"b0x-NwsmcTyoQPiITj5c3"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1735,
			"versionNonce": 452599102,
			"isDeleted": false,
			"id": "QjfuaGLhGdmh7k-Qg1SiM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -402.4625062376731,
			"y": 117.83229321865736,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"b0x-NwsmcTyoQPiITj5c3"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1570,
			"versionNonce": 1060101538,
			"isDeleted": false,
			"id": "BTrQiklp1eLnfUj1O6il4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -374.1392640501731,
			"y": 86.74476880459486,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"b0x-NwsmcTyoQPiITj5c3"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1535,
			"versionNonce": 1920976254,
			"isDeleted": false,
			"id": "oXBKSjgolPLZXo9Ui_3ue",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.86454481189185,
			"y": 126.28349561123548,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"b0x-NwsmcTyoQPiITj5c3"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1504,
			"versionNonce": 1248319842,
			"isDeleted": false,
			"id": "h7pl8CS9IpKkMSTkLqJck",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -328.0535706907981,
			"y": 124.86284131436048,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"b0x-NwsmcTyoQPiITj5c3"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1592,
			"versionNonce": 1403413950,
			"isDeleted": false,
			"id": "1ayqGcA7cUO5j7abSKi6o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -283.2719232362772,
			"y": 79.37918347744642,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"6YwsaLt8aDr-zQ578STd_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1815,
			"versionNonce": 1823104290,
			"isDeleted": false,
			"id": "wbOfwgDAfQTzcwNXxmKkF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -302.6775628847147,
			"y": 117.83101148037616,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"6YwsaLt8aDr-zQ578STd_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1650,
			"versionNonce": 1334771198,
			"isDeleted": false,
			"id": "5XtiyTEx167b3h79ev3OI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -274.3543206972147,
			"y": 86.7434870663136,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"6YwsaLt8aDr-zQ578STd_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1615,
			"versionNonce": 1936091362,
			"isDeleted": false,
			"id": "x44klziaqlCevvRMzZrfQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -293.07960145893344,
			"y": 126.28221387295429,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"6YwsaLt8aDr-zQ578STd_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1584,
			"versionNonce": 725257790,
			"isDeleted": false,
			"id": "c77VXh3drfA9-zxE1LkSG",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -228.2686273378397,
			"y": 124.86155957607929,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"6YwsaLt8aDr-zQ578STd_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1523,
			"versionNonce": 640351394,
			"isDeleted": false,
			"id": "29M4TiV6is8MD2YbL5Hth",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -180.67694477063174,
			"y": 79.75744885830579,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"2jdNoZOzYZEeveUBV1yPt"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1746,
			"versionNonce": 1669994110,
			"isDeleted": false,
			"id": "UhuBpuzpRGJNIjiDtU6sP",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -200.08258441906924,
			"y": 118.20927686123554,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"2jdNoZOzYZEeveUBV1yPt"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1581,
			"versionNonce": 44505186,
			"isDeleted": false,
			"id": "8yZ48nWZYe8qOxqAgSv71",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.75934223156924,
			"y": 87.12175244717298,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"2jdNoZOzYZEeveUBV1yPt"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1546,
			"versionNonce": 826185406,
			"isDeleted": false,
			"id": "33BUe-QHB86Icl3jEv3n3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -190.48462299328799,
			"y": 126.66047925381366,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"2jdNoZOzYZEeveUBV1yPt"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1515,
			"versionNonce": 2024389666,
			"isDeleted": false,
			"id": "7ExSjVuZNQIVdNE7m_p8p",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -125.67364887219424,
			"y": 125.23982495693866,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"2jdNoZOzYZEeveUBV1yPt"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 383,
			"versionNonce": 217648894,
			"isDeleted": false,
			"id": "2qggXZtJC32GBRSeGLj9c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -356.7513551146262,
			"y": 79.4941203060597,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170571405,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 383,
			"versionNonce": 2075289058,
			"isDeleted": false,
			"id": "4BXPkPsWUtmau4xFVCrGI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -256.9160279661887,
			"y": -52.52346692043885,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 131.30532687740885,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170582574,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					131.30532687740885
				]
			]
		},
		{
			"type": "line",
			"version": 394,
			"versionNonce": 1457924990,
			"isDeleted": false,
			"id": "Djh8hny0ewWp2OncS9c30",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -221.51991527182076,
			"y": -53.18853929197364,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 65.76377738595465,
			"height": 132.71259734217358,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170585654,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					65.76377738595465,
					132.71259734217358
				]
			]
		},
		{
			"type": "text",
			"version": 174,
			"versionNonce": 1350338750,
			"isDeleted": false,
			"id": "9XafJnxT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -503.0784378051758,
			"y": -143.2747573852539,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 112.55996704101562,
			"height": 35,
			"seed": 416859042,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170643428,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Max. 5m",
			"rawText": "Max. 5m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 5m",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"id": "QGQ4FnPViKGYSmOxJrtq8",
			"type": "rectangle",
			"x": -686.0992952086167,
			"y": -147.71316952351236,
			"width": 155,
			"height": 94,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 1768757950,
			"version": 158,
			"versionNonce": 1113361314,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "srhmiG3Z"
				}
			],
			"updated": 1682170629010,
			"link": null,
			"locked": false
		},
		{
			"id": "srhmiG3Z",
			"type": "text",
			"x": -669.849257061644,
			"y": -125.71316952351236,
			"width": 122.49992370605469,
			"height": 50,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 411755234,
			"version": 38,
			"versionNonce": 349576958,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682170622174,
			"link": null,
			"locked": false,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 42,
			"containerId": "QGQ4FnPViKGYSmOxJrtq8",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25
		},
		{
			"type": "rectangle",
			"version": 196,
			"versionNonce": 1607386978,
			"isDeleted": false,
			"id": "3e9VlwI4_PaxX8CFxdvK2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -334.2230907942186,
			"y": -146.9081874262919,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 155,
			"height": 93,
			"seed": 1768757950,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "xZgBQlxl"
				}
			],
			"updated": 1682170635296,
			"link": null,
			"locked": false
		},
		{
			"id": "xZgBQlxl",
			"type": "text",
			"x": -317.97305264724594,
			"y": -125.4081874262919,
			"width": 122.49992370605469,
			"height": 50,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1371459426,
			"version": 20,
			"versionNonce": 887184610,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682170614827,
			"link": null,
			"locked": false,
			"text": "HUB\n100BASE-TX",
			"rawText": "HUB\n100BASE-TX",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 42,
			"containerId": "3e9VlwI4_PaxX8CFxdvK2",
			"originalText": "HUB\n100BASE-TX",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#82c91e",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1403.2084698305425,
		"scrollY": 456.74956676693546,
		"zoom": {
			"value": 0.7703470986429793
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%