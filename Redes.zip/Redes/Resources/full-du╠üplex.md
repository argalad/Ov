---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^ovHKHF4L

B ^HQOBlu8W

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "rectangle",
			"version": 73,
			"versionNonce": 86296250,
			"isDeleted": false,
			"id": "eZ0JB1DayWMR9MZ2tk9vy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -341.65338134765625,
			"y": -151.2187271118164,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 625822118,
			"groupIds": [
				"3pRd8t651rrp5xSKlRkqI",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681761905353,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 68,
			"versionNonce": 1635490278,
			"isDeleted": false,
			"id": "ovHKHF4L",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -323.7946472167969,
			"y": -140.4204330444336,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 406981562,
			"groupIds": [
				"3pRd8t651rrp5xSKlRkqI",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681761905353,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 332,
			"versionNonce": 957341562,
			"isDeleted": false,
			"id": "asJ0XexmeLoEZPFZEoT--",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -342.677490234375,
			"y": -33.51001739501953,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 226567398,
			"groupIds": [
				"Qqtc0EB6for5C0DC8ToX7",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1681761905353,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 212,
			"versionNonce": 133917990,
			"isDeleted": false,
			"id": "HQOBlu8W",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -324.9855651855469,
			"y": -22.425865173339844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1648133242,
			"groupIds": [
				"Qqtc0EB6for5C0DC8ToX7",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1681761905353,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 303,
			"versionNonce": 1041113338,
			"isDeleted": false,
			"id": "wnmnwMyT-kbqnqa66Gfqv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -317.3362274169922,
			"y": -106.33271408081055,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.11553955078125,
			"height": 71.74952697753906,
			"seed": 1360500774,
			"groupIds": [
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681762065489,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.01015400953661361,
				"gap": 9.087718963623047,
				"elementId": "ovHKHF4L"
			},
			"endBinding": {
				"focus": 0.006889503423351878,
				"gap": 1.0731697082519531,
				"elementId": "asJ0XexmeLoEZPFZEoT--"
			},
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.11553955078125,
					71.74952697753906
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#000000",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 633.2308044433594,
		"scrollY": 302.4138412475586,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%