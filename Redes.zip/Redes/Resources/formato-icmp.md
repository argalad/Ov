---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
IP Header
(Protocol = 1) ^UMSvfX5u

ICMP Header ^krlti0dt

ICMP Data (optional) ^4w0wseqO

Type (8 bits) ^tm3T2TXP

Code (8 bits) ^bAVoHXPW

Checksum (16 bits) ^lEQ9BuyQ

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"id": "UMSvfX5u",
			"type": "text",
			"x": -195.99932861328125,
			"y": -196.8098907470703,
			"width": 134.47988891601562,
			"height": 50,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 2090293088,
			"version": 37,
			"versionNonce": 145520480,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550361071,
			"link": null,
			"locked": false,
			"text": "IP Header\n(Protocol = 1)",
			"rawText": "IP Header\n(Protocol = 1)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "IP Header\n(Protocol = 1)",
			"lineHeight": 1.25
		},
		{
			"id": "krlti0dt",
			"type": "text",
			"x": -5.98822021484375,
			"y": -188.8704376220703,
			"width": 128.53990173339844,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 450388640,
			"version": 79,
			"versionNonce": 335612768,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550378057,
			"link": null,
			"locked": false,
			"text": "ICMP Header",
			"rawText": "ICMP Header",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "ICMP Header",
			"lineHeight": 1.25
		},
		{
			"id": "4w0wseqO",
			"type": "text",
			"x": 178.67645263671875,
			"y": -185.19532775878906,
			"width": 216.59983825683594,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1027475104,
			"version": 82,
			"versionNonce": 193034080,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550380465,
			"link": null,
			"locked": false,
			"text": "ICMP Data (optional)",
			"rawText": "ICMP Data (optional)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "ICMP Data (optional)",
			"lineHeight": 1.25
		},
		{
			"id": "CIZ89E-M_6fvJoEbznqk7",
			"type": "rectangle",
			"x": -223.3385009765625,
			"y": -220.0481719970703,
			"width": 648.9127807617188,
			"height": 88.32681274414062,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 16527008,
			"version": 178,
			"versionNonce": 1682078368,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550387866,
			"link": null,
			"locked": false
		},
		{
			"id": "-_3ulQ-j9E73IaHm2Fwb_",
			"type": "line",
			"x": -35.63348388671875,
			"y": -221.5032501220703,
			"width": 1.1328125,
			"height": 87.40884399414062,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1395654496,
			"version": 94,
			"versionNonce": 1181012640,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550410952,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.1328125,
					87.40884399414062
				]
			],
			"lastCommittedPoint": [
				1.52020263671875,
				87.40884399414062
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "NoISOxcVjad5QIaFHwmE7",
			"type": "line",
			"x": 148.38995361328125,
			"y": -220.484375,
			"width": 0.27020263671875,
			"height": 89.96745300292969,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1877935776,
			"version": 100,
			"versionNonce": 629442400,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550406561,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.27020263671875,
					89.96745300292969
				]
			],
			"lastCommittedPoint": [
				0.27020263671875,
				89.96745300292969
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "0eapooefcxnWDeaPn3uTi",
			"type": "line",
			"x": -33.439453125,
			"y": -131.1516876220703,
			"width": 160.576171875,
			"height": 159.76559448242188,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1969437536,
			"version": 123,
			"versionNonce": 447789920,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550521711,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-160.576171875,
					159.76559448242188
				]
			],
			"lastCommittedPoint": [
				-135.5078125,
				156.97589111328125
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "B9YGRHHa4x56EOQz8XE57",
			"type": "line",
			"x": 147.9049072265625,
			"y": -131.68556213378906,
			"width": 192.4056396484375,
			"height": 159.54428100585938,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2089842336,
			"version": 178,
			"versionNonce": 179459744,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550539639,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					192.4056396484375,
					159.54428100585938
				]
			],
			"lastCommittedPoint": [
				158.53515625,
				161.65689086914062
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "tm3T2TXP",
			"type": "text",
			"x": -179.9368896484375,
			"y": 44.51560974121094,
			"width": 133.3198699951172,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1821228704,
			"version": 69,
			"versionNonce": 1399351136,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550486449,
			"link": null,
			"locked": false,
			"text": "Type (8 bits)",
			"rawText": "Type (8 bits)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Type (8 bits)",
			"lineHeight": 1.25
		},
		{
			"id": "bAVoHXPW",
			"type": "text",
			"x": -14.09637451171875,
			"y": 42.77476501464844,
			"width": 133.33987426757812,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 369771360,
			"version": 142,
			"versionNonce": 1166403232,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550494578,
			"link": null,
			"locked": false,
			"text": "Code (8 bits)",
			"rawText": "Code (8 bits)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Code (8 bits)",
			"lineHeight": 1.25
		},
		{
			"id": "lEQ9BuyQ",
			"type": "text",
			"x": 146.22528076171875,
			"y": 41.22724914550781,
			"width": 178.33982849121094,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 485589664,
			"version": 141,
			"versionNonce": 2065945440,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550497378,
			"link": null,
			"locked": false,
			"text": "Checksum (16 bits)",
			"rawText": "Checksum (16 bits)",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 18,
			"containerId": null,
			"originalText": "Checksum (16 bits)",
			"lineHeight": 1.25
		},
		{
			"id": "etYhGQG0_EKznkbbL9jE4",
			"type": "rectangle",
			"x": -200.71478271484375,
			"y": 26.703109741210938,
			"width": 551.044921875,
			"height": 58.39520263671875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 1680652960,
			"version": 187,
			"versionNonce": 991363936,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550472971,
			"link": null,
			"locked": false
		},
		{
			"id": "313C5hKrqa2Ib3hOGN6hL",
			"type": "line",
			"x": -27.67120361328125,
			"y": 26.032546997070312,
			"width": 2.32098388671875,
			"height": 58.925750732421875,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1108502368,
			"version": 68,
			"versionNonce": 71232160,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550507633,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.32098388671875,
					58.925750732421875
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "ErUWUpFp0EifbxoZLnyCf",
			"type": "line",
			"x": 133.05145263671875,
			"y": 26.117172241210938,
			"width": 1.11328125,
			"height": 57.197265625,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 326274912,
			"version": 82,
			"versionNonce": 1202550432,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1685550515661,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.11328125,
					57.197265625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 299.17510986328125,
		"scrollY": 357.02734375,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%