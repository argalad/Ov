---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
HUB
10BASE-T ^JpKlZFvb

HUB
10BASE-T ^t8XsijsW

HUB
10BASE-T ^nB5dHDVV

HUB
10BASE-T ^MZ3lM0yi

Dominio de colisión ^YU3lbcHC

Max. 100m ^pc5oIhdr

Max. 100m ^eyN6lK60

Max. 100m ^TeVZ79tu

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "ellipse",
			"version": 989,
			"versionNonce": 1212332862,
			"isDeleted": false,
			"id": "YqM1fu80IizUbcmvNYHE-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -549.529218319854,
			"y": -507.0604000209828,
			"strokeColor": "#ffffff",
			"backgroundColor": "#952d2d",
			"width": 1434.2915922188342,
			"height": 836.6297646098683,
			"seed": 2035219390,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 517,
			"versionNonce": 1590173602,
			"isDeleted": false,
			"id": "YU3lbcHC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 206.9177549938999,
			"y": 170.93489495883807,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 435.5277099609375,
			"height": 61.437241880063,
			"seed": 942180286,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"fontSize": 49.1497935040504,
			"fontFamily": 1,
			"text": "Dominio de colisión",
			"rawText": "Dominio de colisión",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Dominio de colisión",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "rectangle",
			"version": 110,
			"versionNonce": 1761911678,
			"isDeleted": false,
			"id": "664jXP4AWuFXCQTyTjlJh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -442.0855255126953,
			"y": -291.88538360595703,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 158,
			"height": 104,
			"seed": 1731486434,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "JpKlZFvb"
				}
			],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 16,
			"versionNonce": 296213346,
			"isDeleted": false,
			"id": "JpKlZFvb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -411.4754943847656,
			"y": -264.88538360595703,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 96.77993774414062,
			"height": 50,
			"seed": 787323262,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "HUB\n10BASE-T",
			"rawText": "HUB\n10BASE-T",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "664jXP4AWuFXCQTyTjlJh",
			"originalText": "HUB\n10BASE-T",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 1220,
			"versionNonce": 568296382,
			"isDeleted": false,
			"id": "YrQnVknlWXGtVx6b7TaQ1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -488.94358825683594,
			"y": -57.65862274169922,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"Vlvdum-__ikClSJy2A2Ti"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1443,
			"versionNonce": 278535970,
			"isDeleted": false,
			"id": "njiQBBo8_ayv5Cu-oZo9P",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -508.34922790527344,
			"y": -19.20679473876953,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"Vlvdum-__ikClSJy2A2Ti"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1278,
			"versionNonce": 1962171390,
			"isDeleted": false,
			"id": "3Qjhu5nvz1YNGjSb69oWe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -480.02598571777344,
			"y": -50.29431915283203,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"Vlvdum-__ikClSJy2A2Ti"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1243,
			"versionNonce": 1208871650,
			"isDeleted": false,
			"id": "OM-70ZqHu7_zDfTTvdVUn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -498.7512664794922,
			"y": -10.755592346191406,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"Vlvdum-__ikClSJy2A2Ti"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1212,
			"versionNonce": 2017733694,
			"isDeleted": false,
			"id": "zWKJynJZgeS932AeeYWst",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -433.94029235839844,
			"y": -12.176246643066406,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"Vlvdum-__ikClSJy2A2Ti"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 184,
			"versionNonce": 1049771682,
			"isDeleted": false,
			"id": "z14i0Tri_ez_hq4ezwiVT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -283.18006896972656,
			"y": -238.7514190673828,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 196.9490966796875,
			"height": 0.2481689453125,
			"seed": 1024435874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					196.9490966796875,
					0.2481689453125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 197,
			"versionNonce": 1504703614,
			"isDeleted": false,
			"id": "XGzDcg28Y6SUYML1NTY2G",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -87.15892710573974,
			"y": -289.0345001220703,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 158,
			"height": 104,
			"seed": 1731486434,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "t8XsijsW"
				}
			],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 103,
			"versionNonce": 1356208738,
			"isDeleted": false,
			"id": "t8XsijsW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.54889597781005,
			"y": -262.0345001220703,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 96.77993774414062,
			"height": 50,
			"seed": 787323262,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "HUB\n10BASE-T",
			"rawText": "HUB\n10BASE-T",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "XGzDcg28Y6SUYML1NTY2G",
			"originalText": "HUB\n10BASE-T",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "line",
			"version": 271,
			"versionNonce": 1660466366,
			"isDeleted": false,
			"id": "fIW3h0tVGVUzwkRtAXQhM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 71.74652943722901,
			"y": -235.9005355834961,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 196.9490966796875,
			"height": 0.2481689453125,
			"seed": 1024435874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					196.9490966796875,
					0.2481689453125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 177,
			"versionNonce": 1839758882,
			"isDeleted": false,
			"id": "U-h8QsJMg2Bo15UQrNJEB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 268.00293812863526,
			"y": -289.46954345703125,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 158,
			"height": 104,
			"seed": 1731486434,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "nB5dHDVV"
				}
			],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 83,
			"versionNonce": 2109697278,
			"isDeleted": false,
			"id": "nB5dHDVV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 298.61296925656495,
			"y": -262.46954345703125,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 96.77993774414062,
			"height": 50,
			"seed": 787323262,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "HUB\n10BASE-T",
			"rawText": "HUB\n10BASE-T",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "U-h8QsJMg2Bo15UQrNJEB",
			"originalText": "HUB\n10BASE-T",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "line",
			"version": 249,
			"versionNonce": 1375234530,
			"isDeleted": false,
			"id": "pPHKMFBDqHiPeapsPYMEU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 426.638863421604,
			"y": -236.60517120361328,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 196.9490966796875,
			"height": 0.2481689453125,
			"seed": 1024435874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					196.9490966796875,
					0.2481689453125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 210,
			"versionNonce": 931470654,
			"isDeleted": false,
			"id": "uKMrmPJcPD0My930zCIm1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 621.9962242614478,
			"y": -289.5238342285156,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 158,
			"height": 104,
			"seed": 1731486434,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "MZ3lM0yi"
				}
			],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 116,
			"versionNonce": 1154801058,
			"isDeleted": false,
			"id": "MZ3lM0yi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 652.6062553893775,
			"y": -262.5238342285156,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 96.77993774414062,
			"height": 50,
			"seed": 787323262,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "HUB\n10BASE-T",
			"rawText": "HUB\n10BASE-T",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "uKMrmPJcPD0My930zCIm1",
			"originalText": "HUB\n10BASE-T",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 1301,
			"versionNonce": 1168819582,
			"isDeleted": false,
			"id": "fUvxmjUCCp8vDeeauCQ6M",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -388.9359588623047,
			"y": -57.65990447998047,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"tEQtWLIMnQO3W5pYRS9K_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1524,
			"versionNonce": 1399642466,
			"isDeleted": false,
			"id": "yftnHZNKxPnq7HZmQ07CY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -408.3415985107422,
			"y": -19.208076477050778,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"tEQtWLIMnQO3W5pYRS9K_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1359,
			"versionNonce": 158426558,
			"isDeleted": false,
			"id": "Z27Wg0VLNsPeVJOXXqbef",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -380.0183563232422,
			"y": -50.29560089111328,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"tEQtWLIMnQO3W5pYRS9K_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1324,
			"versionNonce": 219110690,
			"isDeleted": false,
			"id": "jt9rVUns1gnNV1PY-5GdB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -398.74363708496094,
			"y": -10.756874084472653,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"tEQtWLIMnQO3W5pYRS9K_"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1293,
			"versionNonce": 335150590,
			"isDeleted": false,
			"id": "EXRAXdJIxyQw_nUW4qdNy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -333.9326629638672,
			"y": -12.177528381347653,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"tEQtWLIMnQO3W5pYRS9K_"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1233,
			"versionNonce": 1059809506,
			"isDeleted": false,
			"id": "H3jdWckxj9kbjsTkaYKIJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -286.12535095214844,
			"y": -57.281639099121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"7PomXFhhQqC6b0JgJW-7z"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1456,
			"versionNonce": 709201470,
			"isDeleted": false,
			"id": "3vDRTqHbB5t0p2uin7qeD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -305.53099060058594,
			"y": -18.829811096191403,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"7PomXFhhQqC6b0JgJW-7z"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1291,
			"versionNonce": 827325602,
			"isDeleted": false,
			"id": "rSbA6t3yLbNB47chqMrse",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -277.20774841308594,
			"y": -49.917335510253906,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"7PomXFhhQqC6b0JgJW-7z"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1256,
			"versionNonce": 1228215934,
			"isDeleted": false,
			"id": "xUDiFPoLCtwrVxc5nIHiD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -295.9330291748047,
			"y": -10.378608703613278,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"7PomXFhhQqC6b0JgJW-7z"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1225,
			"versionNonce": 1630279778,
			"isDeleted": false,
			"id": "gwOIDfeexu_oE7j7aIlXt",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -231.12205505371094,
			"y": -11.799263000488278,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"7PomXFhhQqC6b0JgJW-7z"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 91,
			"versionNonce": 696882878,
			"isDeleted": false,
			"id": "6AVMH8E2fUgYavZ4V4I0-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -462.63807678222656,
			"y": -57.54496765136719,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 82,
			"versionNonce": 1049541666,
			"isDeleted": false,
			"id": "ZSuUSIn0TVNefl6XS37uA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -362.80274963378906,
			"y": -187.44935607910156,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 128.9801025390625,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					128.9801025390625
				]
			]
		},
		{
			"type": "line",
			"version": 87,
			"versionNonce": 1139019518,
			"isDeleted": false,
			"id": "NOHER50oT3QwmsRI1ehdi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -326.10963439941406,
			"y": -187.45362854003906,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 64.90509033203125,
			"height": 129.9385986328125,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					64.90509033203125,
					129.9385986328125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1339,
			"versionNonce": 1734797282,
			"isDeleted": false,
			"id": "xf48HmytYdeBw3nkzMrE_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -136.3895721435547,
			"y": -53.92461700071118,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"yZQamg96yfAmQ5V6q6i82"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1562,
			"versionNonce": 1422229310,
			"isDeleted": false,
			"id": "mBztN-rcj1azICex3sDRI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -155.7952117919922,
			"y": -15.472788997781493,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"yZQamg96yfAmQ5V6q6i82"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1397,
			"versionNonce": 1673763746,
			"isDeleted": false,
			"id": "IKLdd7Emzwme77egwtLGh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -127.47196960449219,
			"y": -46.56031341184399,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"yZQamg96yfAmQ5V6q6i82"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1362,
			"versionNonce": 1619978110,
			"isDeleted": false,
			"id": "6zbVLANh08p0OiuX6c2tm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -146.19725036621094,
			"y": -7.0215866052033675,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"yZQamg96yfAmQ5V6q6i82"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1331,
			"versionNonce": 1641273186,
			"isDeleted": false,
			"id": "OVd_wDNnfAO2edr_DAGez",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -81.38627624511719,
			"y": -8.442240902078368,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"yZQamg96yfAmQ5V6q6i82"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1420,
			"versionNonce": 931219390,
			"isDeleted": false,
			"id": "2LRSKXgdkDB5EpCZQO8Tw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -36.38194274902344,
			"y": -53.92589873899243,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"ESfOBcRE2-JEAKYu3rutc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1643,
			"versionNonce": 1910938402,
			"isDeleted": false,
			"id": "I1u0gyqM-iSUfGzu2Xh8g",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -55.78758239746094,
			"y": -15.474070736062686,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"ESfOBcRE2-JEAKYu3rutc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1478,
			"versionNonce": 2042470398,
			"isDeleted": false,
			"id": "iJ2Cs30zngLsRuMBv33a1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -27.464340209960938,
			"y": -46.56159515012524,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"ESfOBcRE2-JEAKYu3rutc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1443,
			"versionNonce": 1114302178,
			"isDeleted": false,
			"id": "lV_jnNcX8lz09jyCJ9TXu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -46.18962097167969,
			"y": -7.022868343484561,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"ESfOBcRE2-JEAKYu3rutc"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1412,
			"versionNonce": 457502782,
			"isDeleted": false,
			"id": "vCMMDBJzcNeKb-6HRm6IS",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 18.621353149414062,
			"y": -8.44352264035956,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"ESfOBcRE2-JEAKYu3rutc"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1352,
			"versionNonce": 1542437538,
			"isDeleted": false,
			"id": "AJcFeUdNQeOvqGfqlQiAz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 66.42866516113281,
			"y": -53.547633358133055,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"Kx0R-dVBJGiQUMP19eOku"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1575,
			"versionNonce": 1744320638,
			"isDeleted": false,
			"id": "HrbJgMWifET4rnPQulQ9-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 47.02302551269531,
			"y": -15.09580535520331,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"Kx0R-dVBJGiQUMP19eOku"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1410,
			"versionNonce": 1562646114,
			"isDeleted": false,
			"id": "4LbVit3Q4jHqGGu5yl8fz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 75.34626770019531,
			"y": -46.18332976926587,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"Kx0R-dVBJGiQUMP19eOku"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1375,
			"versionNonce": 127432894,
			"isDeleted": false,
			"id": "15V_DgqbGf5zVWojqIvso",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 56.62098693847656,
			"y": -6.644602962625186,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"Kx0R-dVBJGiQUMP19eOku"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341785,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1344,
			"versionNonce": 920058402,
			"isDeleted": false,
			"id": "PLa3gKFigMTTLctXPR_Bd",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 121.43196105957031,
			"y": -8.065257259500186,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"Kx0R-dVBJGiQUMP19eOku"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 210,
			"versionNonce": 29798654,
			"isDeleted": false,
			"id": "oUezG6Mt6bqOkLxOIGDCL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -110.08406066894531,
			"y": -53.81096191037915,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 201,
			"versionNonce": 1744266722,
			"isDeleted": false,
			"id": "-2ZaIEIJkkV2s3W4OtEox",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -10.248733520507812,
			"y": -183.71535033811352,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 128.9801025390625,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					128.9801025390625
				]
			]
		},
		{
			"type": "line",
			"version": 206,
			"versionNonce": 1107550526,
			"isDeleted": false,
			"id": "OlBhwu_uSg1T_O6-HQnaL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 26.444381713867188,
			"y": -183.71962279905102,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 64.90509033203125,
			"height": 129.9385986328125,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					64.90509033203125,
					129.9385986328125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1312,
			"versionNonce": 966023586,
			"isDeleted": false,
			"id": "zw7qubn29Z2asfDuD4srF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 218.36842346191406,
			"y": -54.38897246946115,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"-wALtKxlaOFb6Nytco0zT"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1535,
			"versionNonce": 464587134,
			"isDeleted": false,
			"id": "rPjFxqJisJcWb5Rw0MHvH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 198.96278381347656,
			"y": -15.937144466531464,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"-wALtKxlaOFb6Nytco0zT"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1370,
			"versionNonce": 2061292898,
			"isDeleted": false,
			"id": "qb4kUrZg8xnOKbprgYOkY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 227.28602600097656,
			"y": -47.024668880593964,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"-wALtKxlaOFb6Nytco0zT"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1335,
			"versionNonce": 1309616574,
			"isDeleted": false,
			"id": "QWDBunRqceeEFzRv6IPLX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 208.5607452392578,
			"y": -7.485942073953339,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"-wALtKxlaOFb6Nytco0zT"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1304,
			"versionNonce": 1025497378,
			"isDeleted": false,
			"id": "AmzAG57DTONMeU0lK2K_T",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 273.37171936035156,
			"y": -8.906596370828339,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"-wALtKxlaOFb6Nytco0zT"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1393,
			"versionNonce": 138363390,
			"isDeleted": false,
			"id": "hOebrO91sWLRQOp9BZVoY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 318.3760528564453,
			"y": -54.3902542077424,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"PzX77svR1FIv5GlmOuUpR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1616,
			"versionNonce": 265053410,
			"isDeleted": false,
			"id": "120IaP4k3a0WoiCjpBrJJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 298.9704132080078,
			"y": -15.938426204812714,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"PzX77svR1FIv5GlmOuUpR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1451,
			"versionNonce": 1833062974,
			"isDeleted": false,
			"id": "F9iM9FvLvcBqFfNEhRC6L",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 327.2936553955078,
			"y": -47.025950618875214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"PzX77svR1FIv5GlmOuUpR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1416,
			"versionNonce": 1014069410,
			"isDeleted": false,
			"id": "Lp03t1QOUUDXBaG5Lde32",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 308.56837463378906,
			"y": -7.487223812234589,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"PzX77svR1FIv5GlmOuUpR"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1385,
			"versionNonce": 402217598,
			"isDeleted": false,
			"id": "KAg8ploAhceKMEY76BEog",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 373.3793487548828,
			"y": -8.907878109109589,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"PzX77svR1FIv5GlmOuUpR"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1325,
			"versionNonce": 46011490,
			"isDeleted": false,
			"id": "FL_vBXoN7AuVgnJ34uhP5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 421.18666076660156,
			"y": -54.01198882688303,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"7TMHm_JEHfA2OwHu4wVya"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1548,
			"versionNonce": 522541758,
			"isDeleted": false,
			"id": "MYrnwUk0uyyZFU8k4n54j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 401.78102111816406,
			"y": -15.560160823953339,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"7TMHm_JEHfA2OwHu4wVya"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1383,
			"versionNonce": 1417754658,
			"isDeleted": false,
			"id": "Yg6DmLVhxOEkDRzSbONxG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 430.10426330566406,
			"y": -46.64768523801584,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"7TMHm_JEHfA2OwHu4wVya"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1348,
			"versionNonce": 426201854,
			"isDeleted": false,
			"id": "nK-WhMv8ozMgM036ZpMff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 411.3789825439453,
			"y": -7.108958431375214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"7TMHm_JEHfA2OwHu4wVya"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1317,
			"versionNonce": 296346594,
			"isDeleted": false,
			"id": "irPTkSkHJ2572689_UMNw",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 476.18995666503906,
			"y": -8.529612728250214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"7TMHm_JEHfA2OwHu4wVya"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 183,
			"versionNonce": 557859646,
			"isDeleted": false,
			"id": "upW9H81_lqATZcLsEVomi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 244.67393493652344,
			"y": -54.27531737912912,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 174,
			"versionNonce": 1145509794,
			"isDeleted": false,
			"id": "ZRcR6mM3XeqN2cve5S9yB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 344.50926208496094,
			"y": -184.17970580686352,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 128.9801025390625,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					128.9801025390625
				]
			]
		},
		{
			"type": "line",
			"version": 179,
			"versionNonce": 1494297470,
			"isDeleted": false,
			"id": "mCqNfLUotV3mrxlgQ539z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 381.20237731933594,
			"y": -184.18397826780102,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 64.90509033203125,
			"height": 129.9385986328125,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					64.90509033203125,
					129.9385986328125
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1298,
			"versionNonce": 1552405346,
			"isDeleted": false,
			"id": "DPL-g-apZQfNLQ9ZKgZOJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 572.1837310791016,
			"y": -54.47744292844553,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"bA2MXyf8V4sN7JLn8Omd4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1521,
			"versionNonce": 1864043454,
			"isDeleted": false,
			"id": "Mq9PRLuASOvLi2DOjEadg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 552.7780914306641,
			"y": -16.02561492551584,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"bA2MXyf8V4sN7JLn8Omd4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1356,
			"versionNonce": 1824200482,
			"isDeleted": false,
			"id": "1Uv9XKqJEnlsQ-ZA0tXcD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 581.1013336181641,
			"y": -47.11313933957834,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"bA2MXyf8V4sN7JLn8Omd4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1321,
			"versionNonce": 561964030,
			"isDeleted": false,
			"id": "ZhqqA6WmAUwd_MhM0_iFi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 562.3760528564453,
			"y": -7.574412532937714,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"bA2MXyf8V4sN7JLn8Omd4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1290,
			"versionNonce": 1699734242,
			"isDeleted": false,
			"id": "IXgMpuuSnyig-xSl7Mm2B",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 627.1870269775391,
			"y": -8.995066829812714,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"bA2MXyf8V4sN7JLn8Omd4"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1379,
			"versionNonce": 1111340094,
			"isDeleted": false,
			"id": "x0j6XIiMutfHy9QkX9v_o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 672.1913604736328,
			"y": -54.47872466672678,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"9CIcrMLmslc3T9ZBvNVhw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1602,
			"versionNonce": 1356150434,
			"isDeleted": false,
			"id": "iKiRLB1I-4Rn7WGLiF04o",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 652.7857208251953,
			"y": -16.02689666379709,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"9CIcrMLmslc3T9ZBvNVhw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1437,
			"versionNonce": 993557630,
			"isDeleted": false,
			"id": "uLQNlwzuqpx1r_yiVQkng",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 681.1089630126953,
			"y": -47.11442107785959,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"9CIcrMLmslc3T9ZBvNVhw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1402,
			"versionNonce": 268046946,
			"isDeleted": false,
			"id": "2zBj4K55-aSzA2lt11z2j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 662.3836822509766,
			"y": -7.575694271218964,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"9CIcrMLmslc3T9ZBvNVhw"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1371,
			"versionNonce": 305151166,
			"isDeleted": false,
			"id": "VprTeJC7ehW4RlytYbTuu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 727.1946563720703,
			"y": -8.996348568093964,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"9CIcrMLmslc3T9ZBvNVhw"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1311,
			"versionNonce": 361592354,
			"isDeleted": false,
			"id": "lwJzVnu7rYmUvnR_SjL-4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 775.0019683837891,
			"y": -54.1004592858674,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"y36xraX0EoH2KZ8SNJFsy"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1534,
			"versionNonce": 1824912638,
			"isDeleted": false,
			"id": "1NhxdhToyTe9olG5VkvY7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 755.5963287353516,
			"y": -15.648631282937714,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"y36xraX0EoH2KZ8SNJFsy"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1369,
			"versionNonce": 578707938,
			"isDeleted": false,
			"id": "eTkWFENFjUG8g9vZLBG2c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 783.9195709228516,
			"y": -46.736155697000214,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"y36xraX0EoH2KZ8SNJFsy"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1334,
			"versionNonce": 343582014,
			"isDeleted": false,
			"id": "re4-Llxy5y8HF5GFgW7cV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 765.1942901611328,
			"y": -7.197428890359589,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"y36xraX0EoH2KZ8SNJFsy"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1303,
			"versionNonce": 31184290,
			"isDeleted": false,
			"id": "qflOIYI9Bd4rrcipSQblc",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 830.0052642822266,
			"y": -8.618083187234589,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"y36xraX0EoH2KZ8SNJFsy"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 169,
			"versionNonce": 2058308990,
			"isDeleted": false,
			"id": "lVniT9Iq9BO9rgRmiFD2I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 598.4892425537109,
			"y": -54.363787838113495,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 66.646728515625,
			"height": 130.17398071289062,
			"seed": 632767230,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					66.646728515625,
					-130.17398071289062
				]
			]
		},
		{
			"type": "line",
			"version": 160,
			"versionNonce": 1154797922,
			"isDeleted": false,
			"id": "NPCsHU3biE11IsrcHvtwZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 698.3245697021484,
			"y": -184.2681762658479,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.05267333984375,
			"height": 128.9801025390625,
			"seed": 699567678,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.05267333984375,
					128.9801025390625
				]
			]
		},
		{
			"type": "line",
			"version": 165,
			"versionNonce": 1017441726,
			"isDeleted": false,
			"id": "ekN3COzgRIOD6wcQYmoYi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 735.0176849365234,
			"y": -184.2724487267854,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 64.90509033203125,
			"height": 129.9385986328125,
			"seed": 194738238,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					64.90509033203125,
					129.9385986328125
				]
			]
		},
		{
			"type": "text",
			"version": 59,
			"versionNonce": 2126009634,
			"isDeleted": false,
			"id": "pc5oIhdr",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.3119271542845,
			"y": -282.24447248899787,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 141.37196350097656,
			"height": 35,
			"seed": 416859042,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Max. 100m",
			"rawText": "Max. 100m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 100m",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 127,
			"versionNonce": 662472190,
			"isDeleted": false,
			"id": "eyN6lK60",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 101.48767153956317,
			"y": -279.3282890173182,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 141.37196350097656,
			"height": 35,
			"seed": 416859042,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Max. 100m",
			"rawText": "Max. 100m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 100m",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "text",
			"version": 125,
			"versionNonce": 16081122,
			"isDeleted": false,
			"id": "TeVZ79tu",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 454.35426394678973,
			"y": -279.9109840246424,
			"strokeColor": "#ffffff",
			"backgroundColor": "#82c91e",
			"width": 141.37196350097656,
			"height": 35,
			"seed": 416859042,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682170341786,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Max. 100m",
			"rawText": "Max. 100m",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Max. 100m",
			"lineHeight": 1.25,
			"baseline": 24
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#82c91e",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 622.9119103696165,
		"scrollY": 612.1896552892908,
		"zoom": {
			"value": 0.8
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%