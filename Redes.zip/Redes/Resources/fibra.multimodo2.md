---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "ellipse",
			"version": 292,
			"versionNonce": 1381368486,
			"isDeleted": false,
			"id": "iDP2XjtmzKXvUyEzZayaa",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -307.7002258300781,
			"y": -202.22943878173828,
			"strokeColor": "#a61e4d",
			"backgroundColor": "#e64980",
			"width": 29.08917236328125,
			"height": 49.324981689453125,
			"seed": 118923238,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760426655,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 180,
			"versionNonce": 826146554,
			"isDeleted": false,
			"id": "vIXbzdoxlc5zXXGYymulO",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.3798522949219,
			"y": -202.8713150024414,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 334.3931884765625,
			"height": 1.369293212890625,
			"seed": 542816358,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-1.369293212890625
				]
			]
		},
		{
			"type": "line",
			"version": 296,
			"versionNonce": 148964774,
			"isDeleted": false,
			"id": "e27EBtfEZhYAJkim5oXqh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.1886965088546,
			"y": -154.79639297202232,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 334.3931884765625,
			"height": 0.06414794921875,
			"seed": 1481859450,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					334.3931884765625,
					-0.06414794921875
				]
			]
		},
		{
			"type": "line",
			"version": 180,
			"versionNonce": 903352250,
			"isDeleted": false,
			"id": "aEQ2K2Bx-_odtuxsKFtHV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.934600830078125,
			"y": -205.92227935791016,
			"strokeColor": "#a61e4d",
			"backgroundColor": "transparent",
			"width": 14.1124267578125,
			"height": 49.03826904296875,
			"seed": 666854842,
			"groupIds": [
				"3nAXs0c0ubQnOV4lKpWQA"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760350311,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					12.98699951171875,
					26.975311279296875
				],
				[
					-1.12542724609375,
					49.03826904296875
				]
			]
		},
		{
			"type": "arrow",
			"version": 143,
			"versionNonce": 1702899770,
			"isDeleted": false,
			"id": "GOnyQY9cSP8IypiMirK5C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -327.6921691894531,
			"y": -179.34491729736328,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 361.4541015625,
			"height": 0.43218994140625,
			"seed": 1174045094,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					361.4541015625,
					0.43218994140625
				]
			]
		},
		{
			"type": "arrow",
			"version": 569,
			"versionNonce": 490871034,
			"isDeleted": false,
			"id": "BJcxXqqmRUayJS8nZ-K5w",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -322.1935729980469,
			"y": -163.38822174072266,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 354.93707275390625,
			"height": 48.4991455078125,
			"seed": 273054758,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760325783,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					76.565673828125,
					-39.222076416015625
				],
				[
					133.2806396484375,
					9.277069091796875
				],
				[
					206.7481689453125,
					-37.87841796875
				],
				[
					265.76531982421875,
					8.23297119140625
				],
				[
					321.033935546875,
					-37.74578857421875
				],
				[
					354.93707275390625,
					-13.93267822265625
				]
			]
		},
		{
			"type": "arrow",
			"version": 811,
			"versionNonce": 2052174330,
			"isDeleted": true,
			"id": "90EC6avrhew0j-jc3ornl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -319.8274404887501,
			"y": -196.04691041378814,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 357.10682891648446,
			"height": 49.9197998046875,
			"seed": 1163402874,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1681760426655,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "iDP2XjtmzKXvUyEzZayaa",
				"focus": -0.09208473423507761,
				"gap": 15.324018057201055
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					71.03730987351571,
					42.80013764767486
				],
				[
					144.99269317429696,
					-5.750338426543891
				],
				[
					207.83961700242196,
					41.957150587127984
				],
				[
					268.9619924907032,
					-7.119662157012641
				],
				[
					321.5861379985157,
					41.717526563690484
				],
				[
					357.10682891648446,
					21.39614594845611
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#e64980",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 451.1027156406569,
		"scrollY": 392.06925528083565,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%