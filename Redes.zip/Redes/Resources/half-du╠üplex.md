---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
A ^ovHKHF4L

B ^HQOBlu8W

A ^KA9Al4Gw

B ^QBiCnC5g

... ^krmmLJXc

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.23",
	"elements": [
		{
			"type": "rectangle",
			"version": 73,
			"versionNonce": 86296250,
			"isDeleted": false,
			"id": "eZ0JB1DayWMR9MZ2tk9vy",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -341.65338134765625,
			"y": -151.2187271118164,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 625822118,
			"groupIds": [
				"3pRd8t651rrp5xSKlRkqI",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761905353,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 68,
			"versionNonce": 1635490278,
			"isDeleted": false,
			"id": "ovHKHF4L",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -323.7946472167969,
			"y": -140.4204330444336,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 406981562,
			"groupIds": [
				"3pRd8t651rrp5xSKlRkqI",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1681761905353,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 332,
			"versionNonce": 957341562,
			"isDeleted": false,
			"id": "asJ0XexmeLoEZPFZEoT--",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -342.677490234375,
			"y": -33.51001739501953,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 226567398,
			"groupIds": [
				"Qqtc0EB6for5C0DC8ToX7",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761905353,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 212,
			"versionNonce": 133917990,
			"isDeleted": false,
			"id": "HQOBlu8W",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -324.9855651855469,
			"y": -22.425865173339844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1648133242,
			"groupIds": [
				"Qqtc0EB6for5C0DC8ToX7",
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": null,
			"boundElements": null,
			"updated": 1681761905353,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 302,
			"versionNonce": 535422266,
			"isDeleted": false,
			"id": "wnmnwMyT-kbqnqa66Gfqv",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -317.3362274169922,
			"y": -106.33271408081055,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.11553955078125,
			"height": 71.74952697753906,
			"seed": 1360500774,
			"groupIds": [
				"gdmAF0HIr_3ahKRTGMN37"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681761905354,
			"link": null,
			"locked": false,
			"startBinding": {
				"focus": 0.01015400953661361,
				"gap": 9.087718963623047,
				"elementId": "ovHKHF4L"
			},
			"endBinding": {
				"focus": 0.006889503423351878,
				"gap": 1.0731697082519531,
				"elementId": "asJ0XexmeLoEZPFZEoT--"
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.11553955078125,
					71.74952697753906
				]
			]
		},
		{
			"type": "rectangle",
			"version": 133,
			"versionNonce": 72046842,
			"isDeleted": false,
			"id": "nNd6Pt2Zz5BMgrqEmr_5A",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -250.24544757038905,
			"y": -151.5210854401522,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 715992570,
			"groupIds": [
				"1lfqvSYCIfheNByuXfG5r"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761925845,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 129,
			"versionNonce": 997084070,
			"isDeleted": false,
			"id": "KA9Al4Gw",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -232.38671343952967,
			"y": -140.7227913727694,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 75515558,
			"groupIds": [
				"1lfqvSYCIfheNByuXfG5r"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "5CdL1CvnbCrb7HjRasNBl",
					"type": "arrow"
				}
			],
			"updated": 1681761925845,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 392,
			"versionNonce": 841623994,
			"isDeleted": false,
			"id": "9KJlTpYw_B91xwVSNupRN",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -251.2695564571078,
			"y": -33.81237572335533,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 50.031005859375,
			"height": 44.588043212890625,
			"seed": 931749562,
			"groupIds": [
				"BQCdY-nsYWDB6NsYZLU0J"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": null,
			"updated": 1681761925845,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 273,
			"versionNonce": 2083645158,
			"isDeleted": false,
			"id": "QBiCnC5g",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -233.57763140827967,
			"y": -22.728223501675643,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 1733067238,
			"groupIds": [
				"BQCdY-nsYWDB6NsYZLU0J"
			],
			"roundness": null,
			"boundElements": [
				{
					"id": "5CdL1CvnbCrb7HjRasNBl",
					"type": "arrow"
				}
			],
			"updated": 1681761925845,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 387,
			"versionNonce": 291952422,
			"isDeleted": false,
			"id": "5CdL1CvnbCrb7HjRasNBl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 3.141592653589793,
			"x": -225.92829363972498,
			"y": -106.63507240914635,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.11553955078125,
			"height": 71.74952697753906,
			"seed": 1663137658,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1681761933947,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "KA9Al4Gw",
				"focus": 0.01015400953661361,
				"gap": 9.087718963623047
			},
			"endBinding": {
				"elementId": "QBiCnC5g",
				"focus": 0.030739586463767465,
				"gap": 12.15732192993164
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-0.11553955078125,
					71.74952697753906
				]
			]
		},
		{
			"id": "krmmLJXc",
			"type": "text",
			"x": -279.5554332502769,
			"y": -86.4893706689613,
			"width": 16.439987182617188,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 705495654,
			"version": 114,
			"versionNonce": 875017018,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1681761962206,
			"link": null,
			"locked": false,
			"text": "...",
			"rawText": "...",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "...",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 450.9403688385113,
		"scrollY": 207.61986038290158,
		"zoom": {
			"value": 2.1768198349334824
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%