---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Emisor ^XF0v5o35

Receptor ^6a1kWlNn

SEQ = 1
(bytes del 1 al 100) ^IoJa5SBH

SEQ = 301
(bytes del 301 al 400) ^9URQMA3G

SEQ = 101
(bytes del 101 al 200) ^LZRo8GLY

SEQ = 201
(bytes del 201 al 300) ^cAhns1mw

ACK = 101 (bytes del 1 al 100) ^KXDd4MMY

ACK = 201 (bytes del 101 al 200) ^d623zxni

ACK = 301 (bytes del 201 al 300) ^7CKuRwdC

ACK = 401 (bytes del 301 al 400) ^wcy2ru0E

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "line",
			"version": 153,
			"versionNonce": 245928336,
			"isDeleted": false,
			"id": "RjtQOjguB5i1S5nwr6QUx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.2734146118164,
			"y": -177.5260467529297,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.6504313151041572,
			"height": 205.9316327130353,
			"seed": 891828112,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.6504313151041572,
					205.9316327130353
				]
			]
		},
		{
			"type": "line",
			"version": 212,
			"versionNonce": 2064584560,
			"isDeleted": false,
			"id": "Cxl8Gel6bz4oXpq4DV-XA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.85415621903742,
			"y": -175.39886252212807,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.1850495515046191,
			"height": 209.19407484266492,
			"seed": 420678000,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.1850495515046191,
					209.19407484266492
				]
			]
		},
		{
			"type": "arrow",
			"version": 100,
			"versionNonce": 1287643024,
			"isDeleted": false,
			"id": "4uoEJIxfSSfz_hf5azB3Q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.99986295346858,
			"y": -150.19484779823736,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.04132532190394,
			"height": 19.5110104727527,
			"seed": 25651600,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "IoJa5SBH",
				"focus": -0.35599298177174243,
				"gap": 4.649021572536924
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.04132532190394,
					19.5110104727527
				]
			]
		},
		{
			"type": "arrow",
			"version": 249,
			"versionNonce": 1197187440,
			"isDeleted": false,
			"id": "cyEojDg36wkUWSM638461",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.0147717795471,
			"y": -110.02783681899814,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 2116888976,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "text",
			"version": 91,
			"versionNonce": 649948560,
			"isDeleted": false,
			"id": "XF0v5o35",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.90166473388672,
			"y": -209.30404663085938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 61.0599365234375,
			"height": 25,
			"seed": 840245648,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Emisor",
			"rawText": "Emisor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Emisor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 87,
			"versionNonce": 1078326128,
			"isDeleted": false,
			"id": "6a1kWlNn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -13.554023742675781,
			"y": -206.16795349121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 86.31991577148438,
			"height": 25,
			"seed": 1327880560,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Receptor",
			"rawText": "Receptor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Receptor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 341,
			"versionNonce": 1171864464,
			"isDeleted": false,
			"id": "IoJa5SBH",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -295.6532637984664,
			"y": -169.02822084780092,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 151.00437927246094,
			"height": 39.27887126510597,
			"seed": 1928374160,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "4uoEJIxfSSfz_hf5azB3Q",
					"type": "arrow"
				}
			],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 15.711548506042387,
			"fontFamily": 1,
			"text": "SEQ = 1\n(bytes del 1 al 100)",
			"rawText": "SEQ = 1\n(bytes del 1 al 100)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SEQ = 1\n(bytes del 1 al 100)",
			"lineHeight": 1.25,
			"baseline": 33
		},
		{
			"type": "arrow",
			"version": 254,
			"versionNonce": 202769776,
			"isDeleted": false,
			"id": "ySp5O8SXl4uMIa2-ErKWV",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.060397919981604,
			"y": -127.33169402252247,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.621851853624918,
			"seed": 221796752,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "LZRo8GLY",
				"focus": 0.42628751518854396,
				"gap": 4.500175011679005
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-168.18359375,
					19.621851853624918
				]
			]
		},
		{
			"type": "arrow",
			"version": 375,
			"versionNonce": 1816873360,
			"isDeleted": false,
			"id": "Ukssr_QPKefJQgBA0H1wH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.73145282055825,
			"y": -71.10472236265338,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 1760460688,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 363,
			"versionNonce": 1209259888,
			"isDeleted": false,
			"id": "76-7dP2IrIBMAx7jWOLRQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.161795944364002,
			"y": -89.5285090953322,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 166.72718189380788,
			"height": 19.225632279007527,
			"seed": 68685200,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-166.72718189380788,
					19.225632279007527
				]
			]
		},
		{
			"type": "arrow",
			"version": 317,
			"versionNonce": 1431017360,
			"isDeleted": false,
			"id": "M8rrjhu6OMz2cyTIioIwL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.95551513971333,
			"y": -31.547408090373267,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 614172528,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 274,
			"versionNonce": 679962992,
			"isDeleted": false,
			"id": "bQnybeFwbEV1s6RYsnGjm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 27.857501782037616,
			"y": -51.57470140580676,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.18359375,
			"height": 19.514984130859375,
			"seed": 2023299440,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-168.18359375,
					19.514984130859375
				]
			]
		},
		{
			"type": "arrow",
			"version": 486,
			"versionNonce": 353510800,
			"isDeleted": false,
			"id": "HrMFKqSx7oOzHCjPldfQg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 28.718061491074423,
			"y": -7.863441872169231,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 93.59108253761573,
			"height": 11.022507279007527,
			"seed": 2071851888,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-93.59108253761573,
					11.022507279007527
				]
			]
		},
		{
			"type": "text",
			"version": 784,
			"versionNonce": 414759792,
			"isDeleted": false,
			"id": "9URQMA3G",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -322.5903898168492,
			"y": -50.047892933627395,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 178.308349609375,
			"height": 39.27887126510597,
			"seed": 142324112,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 15.711548506042387,
			"fontFamily": 1,
			"text": "SEQ = 301\n(bytes del 301 al 400)",
			"rawText": "SEQ = 301\n(bytes del 301 al 400)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SEQ = 301\n(bytes del 301 al 400)",
			"lineHeight": 1.25,
			"baseline": 33
		},
		{
			"type": "text",
			"version": 516,
			"versionNonce": 2027352976,
			"isDeleted": false,
			"id": "LZRo8GLY",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -317.6217381512677,
			"y": -129.4065038638936,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 172.9983673095703,
			"height": 39.27887126510597,
			"seed": 1966270352,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "ySp5O8SXl4uMIa2-ErKWV",
					"type": "arrow"
				}
			],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 15.711548506042387,
			"fontFamily": 1,
			"text": "SEQ = 101\n(bytes del 101 al 200)",
			"rawText": "SEQ = 101\n(bytes del 101 al 200)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SEQ = 101\n(bytes del 101 al 200)",
			"lineHeight": 1.25,
			"baseline": 33
		},
		{
			"type": "text",
			"version": 782,
			"versionNonce": 1525665136,
			"isDeleted": false,
			"id": "cAhns1mw",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -324.15577203256106,
			"y": -88.94883061447223,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 179.43946838378906,
			"height": 39.27887126510597,
			"seed": 922162576,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685615479304,
			"link": null,
			"locked": false,
			"fontSize": 15.711548506042387,
			"fontFamily": 1,
			"text": "SEQ = 201\n(bytes del 201 al 300)",
			"rawText": "SEQ = 201\n(bytes del 201 al 300)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "SEQ = 201\n(bytes del 201 al 300)",
			"lineHeight": 1.25,
			"baseline": 33
		},
		{
			"type": "text",
			"version": 177,
			"versionNonce": 1255778160,
			"isDeleted": false,
			"id": "KXDd4MMY",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.98727167910254,
			"y": -140.21800500796084,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 266.0303913101689,
			"height": 22.360015936094694,
			"seed": 429404016,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617406582,
			"link": null,
			"locked": false,
			"fontSize": 17.888012748875756,
			"fontFamily": 1,
			"text": "ACK = 101 (bytes del 1 al 100)",
			"rawText": "ACK = 101 (bytes del 1 al 100)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ACK = 101 (bytes del 1 al 100)",
			"lineHeight": 1.25,
			"baseline": 15
		},
		{
			"type": "text",
			"version": 315,
			"versionNonce": 733761936,
			"isDeleted": false,
			"id": "d623zxni",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.43921806855852,
			"y": -99.25126749046674,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 298.96214744681106,
			"height": 22.360015936094694,
			"seed": 1468404112,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617404559,
			"link": null,
			"locked": false,
			"fontSize": 17.888012748875752,
			"fontFamily": 1,
			"text": "ACK = 201 (bytes del 101 al 200)",
			"rawText": "ACK = 201 (bytes del 101 al 200)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ACK = 201 (bytes del 101 al 200)",
			"lineHeight": 1.25,
			"baseline": 15.000000000000004
		},
		{
			"type": "text",
			"version": 286,
			"versionNonce": 922111376,
			"isDeleted": false,
			"id": "7CKuRwdC",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 44.12821748521705,
			"y": -60.72458307719077,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 305.7417195638021,
			"height": 22.360015936094694,
			"seed": 396534128,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617402372,
			"link": null,
			"locked": false,
			"fontSize": 17.888012748875756,
			"fontFamily": 1,
			"text": "ACK = 301 (bytes del 201 al 300)",
			"rawText": "ACK = 301 (bytes del 201 al 300)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ACK = 301 (bytes del 201 al 300)",
			"lineHeight": 1.25,
			"baseline": 15
		},
		{
			"type": "text",
			"version": 299,
			"versionNonce": 1844289904,
			"isDeleted": false,
			"id": "wcy2ru0E",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 46.56732801276079,
			"y": -19.86949300739623,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 303.720365388798,
			"height": 22.360015936094694,
			"seed": 1516765552,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685617399590,
			"link": null,
			"locked": false,
			"fontSize": 17.888012748875756,
			"fontFamily": 1,
			"text": "ACK = 401 (bytes del 301 al 400)",
			"rawText": "ACK = 401 (bytes del 301 al 400)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ACK = 401 (bytes del 301 al 400)",
			"lineHeight": 1.25,
			"baseline": 15
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "dotted",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 260.4419490672918,
		"scrollY": 501.95802915075603,
		"zoom": {
			"value": 0.75
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%