---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Preámbulo    SFD    Dir. MAC Destino    Dir. MAC Origen    Long./Tipo    Datos + Relleno    CRC ^WfhiwfL8

7         1              6                  6                2           46 - 100          4 ^JoTrIlNb

B ^K77hhYBW

Tamaño de la trama mínima = 64 Bytes

Tamaño de la trama máxima = 1518 Bytes ^AwmNyXsw

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 502,
			"versionNonce": 505353122,
			"isDeleted": false,
			"id": "PF1zaavW0vny8fohXE_7R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.446264141603,
			"y": -167.47834931417503,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 2640.3733537953267,
			"height": 139.32253259299407,
			"seed": 805680574,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 364,
			"versionNonce": 542699682,
			"isDeleted": false,
			"id": "WfhiwfL8",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -410.74029602705144,
			"y": -124.06236481898797,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 2546.43701171875,
			"height": 63.96153033997443,
			"seed": 1048358050,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682155167777,
			"link": null,
			"locked": false,
			"fontSize": 51.169224271979544,
			"fontFamily": 1,
			"text": "Preámbulo    SFD    Dir. MAC Destino    Dir. MAC Origen    Long./Tipo    Datos + Relleno    CRC",
			"rawText": "Preámbulo    SFD    Dir. MAC Destino    Dir. MAC Origen    Long./Tipo    Datos + Relleno    CRC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Preámbulo    SFD    Dir. MAC Destino    Dir. MAC Origen    Long./Tipo    Datos + Relleno    CRC",
			"lineHeight": 1.25,
			"baseline": 45
		},
		{
			"type": "line",
			"version": 271,
			"versionNonce": 838881122,
			"isDeleted": false,
			"id": "fiQiA4cGOFY3u1EU9MBIK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -118.0579150522289,
			"y": -169.5302011654559,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.6421373365604766,
			"height": 137.83362340986642,
			"seed": 1316464546,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.6421373365604766,
					137.83362340986642
				]
			]
		},
		{
			"type": "line",
			"version": 264,
			"versionNonce": 678973374,
			"isDeleted": false,
			"id": "kA5HmAZC88BfLgcu1GbXc",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 89.30598240752681,
			"y": -168.548147908916,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 2.518016788896699,
			"height": 137.0234856671814,
			"seed": 1840835838,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.518016788896699,
					137.0234856671814
				]
			]
		},
		{
			"type": "line",
			"version": 253,
			"versionNonce": 1975784226,
			"isDeleted": false,
			"id": "YMTharKTFBaI3gW7fMvVj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 618.2303608599318,
			"y": -167.9788809195254,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.499722991662877,
			"height": 131.19925427593336,
			"seed": 1242816738,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.499722991662877,
					131.19925427593336
				]
			]
		},
		{
			"type": "line",
			"version": 266,
			"versionNonce": 1184081918,
			"isDeleted": false,
			"id": "2MAyYG6E1EuSgqarOWP40",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1109.723970796657,
			"y": -168.72331599157928,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 3.2296200451449,
			"height": 135.21711117355287,
			"seed": 2082600382,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					3.2296200451449,
					135.21711117355287
				]
			]
		},
		{
			"type": "line",
			"version": 254,
			"versionNonce": 1540972258,
			"isDeleted": false,
			"id": "KffgXViDfB0WvwupTO3IG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1467.1168293752612,
			"y": -168.87658318403217,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.40506887134251385,
			"height": 133.04943054998267,
			"seed": 1912153854,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.40506887134251385,
					133.04943054998267
				]
			]
		},
		{
			"type": "line",
			"version": 260,
			"versionNonce": 1880750142,
			"isDeleted": false,
			"id": "PUdqtftQICh31y5Ne5l1b",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 1980.6485907166507,
			"y": -169.46779010265308,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.7405156669173705,
			"height": 139.913739511615,
			"seed": 892417726,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682154912362,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.7405156669173705,
					139.913739511615
				]
			]
		},
		{
			"type": "text",
			"version": 316,
			"versionNonce": 1650811518,
			"isDeleted": false,
			"id": "JoTrIlNb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -274.7091432088154,
			"y": -236.46073938331926,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 2393.2119140625,
			"height": 63.96153033997443,
			"seed": 1212475518,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682155167777,
			"link": null,
			"locked": false,
			"fontSize": 51.169224271979544,
			"fontFamily": 1,
			"text": "7         1              6                  6                2           46 - 100          4",
			"rawText": "7         1              6                  6                2           46 - 100          4",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "7         1              6                  6                2           46 - 100          4",
			"lineHeight": 1.25,
			"baseline": 45
		},
		{
			"type": "text",
			"version": 236,
			"versionNonce": 1794542690,
			"isDeleted": false,
			"id": "K77hhYBW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -478.0875244140625,
			"y": -236.93151092529297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.19329833984375,
			"height": 63.96153033997444,
			"seed": 899020926,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682155167777,
			"link": null,
			"locked": false,
			"fontSize": 51.16922427197955,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 45
		},
		{
			"type": "arrow",
			"version": 486,
			"versionNonce": 1465159266,
			"isDeleted": false,
			"id": "caNNMwkNONp00UMqHusQe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 89.97526736611348,
			"y": 109.60131691838922,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 2119.408563049194,
			"height": 3.3938181631929547,
			"seed": 1633607358,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682154912364,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": "arrow",
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					2119.408563049194,
					3.3938181631929547
				]
			]
		},
		{
			"type": "line",
			"version": 247,
			"versionNonce": 1623949502,
			"isDeleted": false,
			"id": "EPqOekujCyCePmEI7Cho0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 90.12861263660625,
			"y": -30.148224475177756,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.6421373365604766,
			"height": 143.9425663738497,
			"seed": 547879650,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682154912364,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.6421373365604766,
					143.9425663738497
				]
			]
		},
		{
			"type": "line",
			"version": 280,
			"versionNonce": 70808098,
			"isDeleted": false,
			"id": "o6n6lt6sdKn98Tfz68Xyg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 2206.110486667782,
			"y": -27.816267655519482,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.9160351007604641,
			"height": 140.19833396729032,
			"seed": 239547198,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682154912364,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.9160351007604641,
					140.19833396729032
				]
			]
		},
		{
			"type": "text",
			"version": 516,
			"versionNonce": 1322279614,
			"isDeleted": false,
			"id": "AwmNyXsw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 575.0970846173111,
			"y": 21.62423073357752,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1078.401123046875,
			"height": 191.88459101992328,
			"seed": 139328674,
			"groupIds": [
				"H8iy4W64aFBkeA9-B7dSE"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1682155167778,
			"link": null,
			"locked": false,
			"fontSize": 51.169224271979544,
			"fontFamily": 1,
			"text": "Tamaño de la trama mínima = 64 Bytes\n\nTamaño de la trama máxima = 1518 Bytes",
			"rawText": "Tamaño de la trama mínima = 64 Bytes\n\nTamaño de la trama máxima = 1518 Bytes",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Tamaño de la trama mínima = 64 Bytes\n\nTamaño de la trama máxima = 1518 Bytes",
			"lineHeight": 1.25,
			"baseline": 173
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": "arrow",
		"currentItemEndArrowhead": "arrow",
		"scrollX": 495.02700575928804,
		"scrollY": 782.5704980725887,
		"zoom": {
			"value": 0.44414742410182884
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%