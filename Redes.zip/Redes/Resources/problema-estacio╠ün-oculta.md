---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Área de
cobertura de B ^edpySL3I

B ^WTozi3Hx

A ^pNrfjZPM

C ^yOGlGUSm

Área de
cobertura de C ^2uEkpF84

Área de
cobertura de B ^2EJvZsQX

B ^fnSEGxx0

A ^8Ei4gSqX

C ^CIdNNdne

Área de
cobertura de C ^qdYpLqzn

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.26",
	"elements": [
		{
			"type": "ellipse",
			"version": 1266,
			"versionNonce": 1169937916,
			"isDeleted": false,
			"id": "QEemnHcT01VYC8SyA6ehI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -598.312566031924,
			"y": -180.78875637620393,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 501.73285911462926,
			"height": 193.2995433920563,
			"seed": 446063330,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371236580,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1535,
			"versionNonce": 1624210756,
			"isDeleted": false,
			"id": "iVCAV_5i4fl2hXBaY49pp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -210.76177944529002,
			"y": -125.40360074101386,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"B6hPxj4DykT6tZlBZV8Jb"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370998125,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1760,
			"versionNonce": 1944381692,
			"isDeleted": false,
			"id": "SSzV8lpOtDnE0xPmDi6Xe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -230.16741909372752,
			"y": -86.95177273808417,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"B6hPxj4DykT6tZlBZV8Jb"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370998125,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1593,
			"versionNonce": 1475818692,
			"isDeleted": false,
			"id": "Gfl3jLL2YSkaFaKqQAhCU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -201.84417690622752,
			"y": -118.03929715214667,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"B6hPxj4DykT6tZlBZV8Jb"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370998125,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1558,
			"versionNonce": 769026428,
			"isDeleted": false,
			"id": "bEg5Vc4xpP873BPrj7MAd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.56945766794627,
			"y": -78.50057034550605,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"B6hPxj4DykT6tZlBZV8Jb"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370998125,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1528,
			"versionNonce": 272366660,
			"isDeleted": false,
			"id": "I2VijeA1I91xrq48Ic6bl",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -155.75848354685252,
			"y": -79.92122464238105,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"B6hPxj4DykT6tZlBZV8Jb"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370998125,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1691,
			"versionNonce": 1123190140,
			"isDeleted": false,
			"id": "T7qzGyxiTmfvrzpqOOa8N",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -382.4969718973642,
			"y": -125.44531597188421,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"GXBXA_ov2qUIu0oY0qYT4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370994583,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1914,
			"versionNonce": 2139070532,
			"isDeleted": false,
			"id": "TJLX3k8gqOs-WnZZ5S_rk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -401.9026115458017,
			"y": -86.99348796895453,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"GXBXA_ov2qUIu0oY0qYT4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370994583,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1751,
			"versionNonce": 1912370684,
			"isDeleted": false,
			"id": "DWEbGWsP0Zr7tXSi5httK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -373.5793693583017,
			"y": -118.08101238301703,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"GXBXA_ov2qUIu0oY0qYT4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370994583,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1714,
			"versionNonce": 313194436,
			"isDeleted": false,
			"id": "SxewGuRxyiZAibhwFkc2C",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.3046501200204,
			"y": -78.5422855763764,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"GXBXA_ov2qUIu0oY0qYT4"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682370994583,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1683,
			"versionNonce": 2071221884,
			"isDeleted": false,
			"id": "ZSHM_uiXy7kTo6HLsrdAI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -327.4936759989267,
			"y": -79.9629398732514,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"GXBXA_ov2qUIu0oY0qYT4"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682370994583,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 127,
			"versionNonce": 190013180,
			"isDeleted": false,
			"id": "edpySL3I",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -580.8489685058594,
			"y": -110.55016326904297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 152.27987670898438,
			"height": 50,
			"seed": 2124142204,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682370989172,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Área de\ncobertura de B",
			"rawText": "Área de\ncobertura de B",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Área de\ncobertura de B",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 268,
			"versionNonce": 1417867460,
			"isDeleted": false,
			"id": "T_PSOIUi5BV0vZQvw24IN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -332.4953308105469,
			"y": -163.92317962646484,
			"strokeColor": "#d1dd27",
			"backgroundColor": "transparent",
			"width": 136.13470458984375,
			"height": 21.48101806640625,
			"seed": 1638873724,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371037127,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					83.26666259765625,
					2.54608154296875
				],
				[
					31.58819580078125,
					19.534027099609375
				],
				[
					136.13470458984375,
					21.48101806640625
				]
			]
		},
		{
			"type": "text",
			"version": 58,
			"versionNonce": 871040380,
			"isDeleted": false,
			"id": "WTozi3Hx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -365.31140899658203,
			"y": -50.459068298339844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 2079340612,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371062582,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 57,
			"versionNonce": 1474566212,
			"isDeleted": false,
			"id": "pNrfjZPM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -191.08761596679688,
			"y": -50.754844665527344,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 175271620,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371067095,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "ellipse",
			"version": 1342,
			"versionNonce": 1900460796,
			"isDeleted": false,
			"id": "ShsAUdOeRANX-g5ypcox-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -282.85876964520526,
			"y": -180.82643032639925,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 501.73285911462926,
			"height": 193.2995433920563,
			"seed": 446063330,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371208488,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1806,
			"versionNonce": 934389188,
			"isDeleted": false,
			"id": "HbFvDyB5chO6dD09JSxsF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -33.71868896484375,
			"y": -123.71198827769018,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"g7pZlCQkpnqVSLCxCqfON"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2029,
			"versionNonce": 301435004,
			"isDeleted": false,
			"id": "FlPMMLxfndB1sXn9gxuii",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -53.12432861328125,
			"y": -85.26016027476047,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"g7pZlCQkpnqVSLCxCqfON"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1866,
			"versionNonce": 1367362884,
			"isDeleted": false,
			"id": "JYIvr1-GulWD9g2ZlqHSz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -24.80108642578125,
			"y": -116.34768468882297,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"g7pZlCQkpnqVSLCxCqfON"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1829,
			"versionNonce": 1063852284,
			"isDeleted": false,
			"id": "-tAFODrYBiMWYyNbsrf_f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -43.5263671875,
			"y": -76.80895788218234,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"g7pZlCQkpnqVSLCxCqfON"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1798,
			"versionNonce": 437126340,
			"isDeleted": false,
			"id": "Uo8a_PkVA25GzDOtkLKq-",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 21.28460693359375,
			"y": -78.22961217905734,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"g7pZlCQkpnqVSLCxCqfON"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 174,
			"versionNonce": 1498716540,
			"isDeleted": false,
			"id": "yOGlGUSm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -15.703124233006918,
			"y": -48.725740604145784,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 2079340612,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371144566,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 157,
			"versionNonce": 1254005188,
			"isDeleted": false,
			"id": "2uEkpF84",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 52.306243896484375,
			"y": -114.4900131225586,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 150.619873046875,
			"height": 50,
			"seed": 2124142204,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371222898,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Área de\ncobertura de C",
			"rawText": "Área de\ncobertura de C",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Área de\ncobertura de C",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "ellipse",
			"version": 1319,
			"versionNonce": 96372604,
			"isDeleted": false,
			"id": "sZ5rG4CWQB39Pj36oBlMp",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -597.0787708659084,
			"y": 110.35866641432341,
			"strokeColor": "#ffffff",
			"backgroundColor": "#15aabf",
			"width": 501.73285911462926,
			"height": 193.2995433920563,
			"seed": 446063330,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1588,
			"versionNonce": 552386116,
			"isDeleted": false,
			"id": "8jDX5EbXxR5aJHLR5mzr5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -209.5279842792744,
			"y": 165.74382204951348,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"osfYlUL-b4UnRCaG6DNcO"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1813,
			"versionNonce": 1073231868,
			"isDeleted": false,
			"id": "SUwRov7tgUIG1jiU0kSTY",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -228.9336239277119,
			"y": 204.19565005244317,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"osfYlUL-b4UnRCaG6DNcO"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1646,
			"versionNonce": 79975876,
			"isDeleted": false,
			"id": "SF_j_zKks6QGTcKBkTmeg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -200.6103817402119,
			"y": 173.10812563838067,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"osfYlUL-b4UnRCaG6DNcO"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1611,
			"versionNonce": 1487394940,
			"isDeleted": false,
			"id": "fc8PpdmgEyxCnIJVlSxgK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -219.33566250193064,
			"y": 212.6468524450213,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"osfYlUL-b4UnRCaG6DNcO"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1581,
			"versionNonce": 1220345156,
			"isDeleted": false,
			"id": "JAsMsExDcEJ88R8jvZFUn",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -154.5246883808369,
			"y": 211.2261981481463,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"osfYlUL-b4UnRCaG6DNcO"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1744,
			"versionNonce": 1804560636,
			"isDeleted": false,
			"id": "dafqZG-Ll8ELmLEE-eupD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -381.2631767313485,
			"y": 165.70210681864313,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"lM52taynaqhVyBnDiJZCW"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1967,
			"versionNonce": 1714730180,
			"isDeleted": false,
			"id": "87Q-Flk4yHBKvfqErxu0h",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -400.668816379786,
			"y": 204.15393482157282,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"lM52taynaqhVyBnDiJZCW"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1804,
			"versionNonce": 1278273916,
			"isDeleted": false,
			"id": "KaGs-r3y4CKEYbiDsNUpC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.345574192286,
			"y": 173.06641040751032,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"lM52taynaqhVyBnDiJZCW"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1767,
			"versionNonce": 2060024900,
			"isDeleted": false,
			"id": "p8PqLytXrU0Qra22GH4tg",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -391.07085495400474,
			"y": 212.60513721415094,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"lM52taynaqhVyBnDiJZCW"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1736,
			"versionNonce": 231627260,
			"isDeleted": false,
			"id": "hRVN7ydGbxCUonwfBmwGI",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -326.259880832911,
			"y": 211.18448291727594,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"lM52taynaqhVyBnDiJZCW"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 180,
			"versionNonce": 1079595972,
			"isDeleted": false,
			"id": "2EJvZsQX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -579.6151733398438,
			"y": 180.59725952148438,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 152.27987670898438,
			"height": 50,
			"seed": 2124142204,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Área de\ncobertura de B",
			"rawText": "Área de\ncobertura de B",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Área de\ncobertura de B",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 321,
			"versionNonce": 191478396,
			"isDeleted": false,
			"id": "X1JQwB_gNp4TtKVTMlvNR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -331.26153564453125,
			"y": 127.2242431640625,
			"strokeColor": "#d1dd27",
			"backgroundColor": "transparent",
			"width": 136.13470458984375,
			"height": 21.48101806640625,
			"seed": 1638873724,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					83.26666259765625,
					2.54608154296875
				],
				[
					31.58819580078125,
					19.534027099609375
				],
				[
					136.13470458984375,
					21.48101806640625
				]
			]
		},
		{
			"type": "text",
			"version": 111,
			"versionNonce": 84032324,
			"isDeleted": false,
			"id": "fnSEGxx0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -364.0776138305664,
			"y": 240.6883544921875,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 14.539993286132812,
			"height": 25,
			"seed": 2079340612,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "B",
			"rawText": "B",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "B",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 110,
			"versionNonce": 1875184380,
			"isDeleted": false,
			"id": "8Ei4gSqX",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -189.85382080078125,
			"y": 240.392578125,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 13.1199951171875,
			"height": 25,
			"seed": 175271620,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "A",
			"rawText": "A",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "ellipse",
			"version": 1395,
			"versionNonce": 589443780,
			"isDeleted": false,
			"id": "Q8Ab15DQPV5efg7YP5ZqH",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -281.62497447918963,
			"y": 110.3209924641281,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 501.73285911462926,
			"height": 193.2995433920563,
			"seed": 446063330,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1859,
			"versionNonce": 1029852028,
			"isDeleted": false,
			"id": "8SCrWR69CVasN-xn7bKGS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -32.484893798828125,
			"y": 167.43543451283716,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.909912109375,
			"height": 38.12236022949219,
			"seed": 929909630,
			"groupIds": [
				"By2_gy7oT0cogW7OXfCki"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 2082,
			"versionNonce": 2035759684,
			"isDeleted": false,
			"id": "fadjO6IUkquRtoqRS-TG4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -51.890533447265625,
			"y": 205.8872625157669,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 89.59967041015626,
			"height": 25.537567138671868,
			"seed": 859159522,
			"groupIds": [
				"By2_gy7oT0cogW7OXfCki"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1919,
			"versionNonce": 1451457532,
			"isDeleted": false,
			"id": "lAA10YDjbWhSXPKaO6LzS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -23.567291259765625,
			"y": 174.79973810170438,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 30.57403564453125,
			"height": 24.279510498046875,
			"seed": 1576636258,
			"groupIds": [
				"By2_gy7oT0cogW7OXfCki"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 1882,
			"versionNonce": 1652511172,
			"isDeleted": false,
			"id": "Uj14Cn1T9T5hX-EWt1_LM",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -42.292572021484375,
			"y": 214.33846490834503,
			"strokeColor": "#ffffff",
			"backgroundColor": "#868e96",
			"width": 35.62762451171875,
			"height": 3.90252685546875,
			"seed": 1773146238,
			"groupIds": [
				"By2_gy7oT0cogW7OXfCki"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1851,
			"versionNonce": 86678652,
			"isDeleted": false,
			"id": "T5GuY_8RYRsBzBB9Au0-S",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 22.518402099609375,
			"y": 212.91781061147003,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fa5252",
			"width": 7.210266113281255,
			"height": 6.324493408203125,
			"seed": 2030535650,
			"groupIds": [
				"By2_gy7oT0cogW7OXfCki"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 227,
			"versionNonce": 767064388,
			"isDeleted": false,
			"id": "CIdNNdne",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.46932906699135,
			"y": 242.42168218638153,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 12.879989624023438,
			"height": 25,
			"seed": 2079340612,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "C",
			"rawText": "C",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "C",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 210,
			"versionNonce": 52014332,
			"isDeleted": false,
			"id": "qdYpLqzn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 53.5400390625,
			"y": 176.65740966796875,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 150.619873046875,
			"height": 50,
			"seed": 2124142204,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371266379,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Área de\ncobertura de C",
			"rawText": "Área de\ncobertura de C",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Área de\ncobertura de C",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "arrow",
			"version": 305,
			"versionNonce": 1169148,
			"isDeleted": false,
			"id": "4IYU9E_hm8TTQg5C8q7JL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -37.27371679991484,
			"y": 127.92960172705352,
			"strokeColor": "#d1dd27",
			"backgroundColor": "transparent",
			"width": 136.13470458984375,
			"height": 21.48101806640625,
			"seed": 1638873724,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682371285507,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "triangle",
			"points": [
				[
					0,
					0
				],
				[
					-83.26666259765625,
					2.54608154296875
				],
				[
					-31.58819580078125,
					19.534027099609375
				],
				[
					-136.13470458984375,
					21.48101806640625
				]
			]
		},
		{
			"type": "line",
			"version": 2143,
			"versionNonce": 1504747076,
			"isDeleted": false,
			"id": "jaTEOewq59iitUI4Wztzu",
			"fillStyle": "solid",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -198.3865878406233,
			"y": 136.183856498024,
			"strokeColor": "#ff0000",
			"backgroundColor": "#ffff00",
			"width": 30.027907729728298,
			"height": 32.70156759213356,
			"seed": 677326595,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682371310045,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					8.98020087972965,
					12.157852768049286
				],
				[
					-1.0007349133541639,
					14.123131694500799
				],
				[
					10.049909773653518,
					15.426852985109164
				],
				[
					-1.2120311721437922,
					24.62433485304638
				],
				[
					10.623635992854261,
					18.666290964573992
				],
				[
					13.920039718769509,
					29.864823618858342
				],
				[
					14.911984138468917,
					18.445516714567535
				],
				[
					27.769661304440323,
					27.324256452096083
				],
				[
					17.164370234653695,
					15.28302260857304
				],
				[
					28.24508050293534,
					11.348572653120943
				],
				[
					16.584009285718288,
					12.44627863529784
				],
				[
					28.815876557584506,
					2.3252263362687065
				],
				[
					14.723428049574288,
					10.589812251051955
				],
				[
					12.480564988182149,
					-2.8367439732752158
				],
				[
					11.629509159047092,
					11.650216144980638
				],
				[
					0,
					0
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#15aabf",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "triangle",
		"scrollX": 625.0759566734577,
		"scrollY": 232.28263026270372,
		"zoom": {
			"value": 1.4500000000000002
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%