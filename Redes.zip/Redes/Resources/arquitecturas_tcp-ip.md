---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Aplicación ^COy6qT9K

Transporte ^n0AieaHS

Red ^kHwNTiHf

Enlace
Física ^72qvc3lS

DNS ^xxmFJhmC

NIS+ ^uxgeeSFT

NFS ^XlGE4HZl

FTP ^2jTlsWk4

HTTP ^aLJgSiI5

TELNET ^ljrHbB83

SMPT ^HABfEAOU

POP3 ^SbIYIJEF

RPC ^mS2VWMWn

ICMP ^XFdZLf5V

OSPF ^4QESPMpy

RIP ^9brIGdfw

DHCP ^wx6IUsKx

ARP ^RlaJ3LNT

RARP ^QXhTZ37f

SNMP ^Llreg944

UDP ^Ne7mr5ZE

TCP ^JSfW58vW

IP ^6HBMWotN

Token Ring ^9JSpq1Wf

Ethernet ^S5rxNNYN

PPP ^RQf8x6wn

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "rectangle",
			"version": 272,
			"versionNonce": 1107446867,
			"isDeleted": false,
			"id": "TEnhEsZSHwtY2k8fSWd4R",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 60,
			"angle": 0,
			"x": -601.7100066974447,
			"y": -329.65810183987463,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffa94d",
			"width": 915.6792756553916,
			"height": 154.75177214366707,
			"seed": 1531249149,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 122,
			"versionNonce": 257267293,
			"isDeleted": false,
			"id": "COy6qT9K",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -580.7988530166997,
			"y": -263.89865721169787,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 90.83992004394531,
			"height": 25,
			"seed": 693084787,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Aplicación",
			"rawText": "Aplicación",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Aplicación",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 138,
			"versionNonce": 1799047667,
			"isDeleted": false,
			"id": "bdF-GrAqP74M8-VzcrYmE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -452.0086975097656,
			"y": -228.82861550205615,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 2126801437,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "xxmFJhmC"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 83,
			"versionNonce": 1886175933,
			"isDeleted": false,
			"id": "xxmFJhmC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.8286819458008,
			"y": -223.82861550205615,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 40.63996887207031,
			"height": 25,
			"seed": 1929417437,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DNS",
			"rawText": "DNS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "bdF-GrAqP74M8-VzcrYmE",
			"originalText": "DNS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 200,
			"versionNonce": 734237587,
			"isDeleted": false,
			"id": "ZAcyAlQCz9vnFRlenCTbW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -364.62907600297774,
			"y": -228.87861242667034,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1589815347,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "uxgeeSFT"
				},
				{
					"id": "dGipw3wkUKm8PVmbAnN9x",
					"type": "arrow"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 154,
			"versionNonce": 312435485,
			"isDeleted": false,
			"id": "uxgeeSFT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -353.3490619648918,
			"y": -223.87861242667034,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 48.439971923828125,
			"height": 25,
			"seed": 1799694803,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "NIS+",
			"rawText": "NIS+",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZAcyAlQCz9vnFRlenCTbW",
			"originalText": "NIS+",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 189,
			"versionNonce": 1943120179,
			"isDeleted": false,
			"id": "D84q5cCYPB4kufQvbQXqm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -291.28589715247915,
			"y": -228.25557354087655,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1117730045,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "XlGE4HZl"
				},
				{
					"id": "qUxNAlOczVIxzC3mCeb-m",
					"type": "arrow"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 136,
			"versionNonce": 710866813,
			"isDeleted": false,
			"id": "XlGE4HZl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -274.04588402992056,
			"y": -223.25557354087655,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 36.51997375488281,
			"height": 25,
			"seed": 1380552029,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "NFS",
			"rawText": "NFS",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "D84q5cCYPB4kufQvbQXqm",
			"originalText": "NFS",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 167,
			"versionNonce": 1758202579,
			"isDeleted": false,
			"id": "tjz2Bs0soGV8c25bqN3YQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -217.61855577664204,
			"y": -229.10505233918946,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 401904445,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "2jTlsWk4"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 119,
			"versionNonce": 1642921949,
			"isDeleted": false,
			"id": "2jTlsWk4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -202.50853990750142,
			"y": -224.10505233918946,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 40.77996826171875,
			"height": 25,
			"seed": 165225373,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "FTP",
			"rawText": "FTP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "tjz2Bs0soGV8c25bqN3YQ",
			"originalText": "FTP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 213,
			"versionNonce": 1061763187,
			"isDeleted": false,
			"id": "hAh2JIrc9OAiUb_xvQc0E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -144.77276231382763,
			"y": -228.655465524149,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 82822717,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "aLJgSiI5"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 162,
			"versionNonce": 526056509,
			"isDeleted": false,
			"id": "aLJgSiI5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -137.47273637388622,
			"y": -223.655465524149,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 56.39994812011719,
			"height": 25,
			"seed": 922089117,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "HTTP",
			"rawText": "HTTP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "hAh2JIrc9OAiUb_xvQc0E",
			"originalText": "HTTP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 247,
			"versionNonce": 1427091987,
			"isDeleted": false,
			"id": "t4IDSkmrPXwX_fMJdWTyd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -71.09822348786031,
			"y": -228.58772735174642,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 102,
			"height": 35,
			"seed": 1612848595,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "ljrHbB83"
				},
				{
					"id": "SUbpA2dXgXtD50WCfbHsj",
					"type": "arrow"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 230,
			"versionNonce": 176843933,
			"isDeleted": false,
			"id": "ljrHbB83",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -62.08819846344625,
			"y": -223.58772735174642,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 83.97994995117188,
			"height": 25,
			"seed": 677702515,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "TELNET",
			"rawText": "TELNET",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "t4IDSkmrPXwX_fMJdWTyd",
			"originalText": "TELNET",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 254,
			"versionNonce": 185989043,
			"isDeleted": false,
			"id": "lKA662DceAt3Vxwj_2Wnn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 43.35748617806155,
			"y": -228.60897604256533,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 2135271219,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "HABfEAOU"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 202,
			"versionNonce": 1395446013,
			"isDeleted": false,
			"id": "HABfEAOU",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 50.467509676596706,
			"y": -223.60897604256533,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 56.77995300292969,
			"height": 25,
			"seed": 554715347,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SMPT",
			"rawText": "SMPT",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "lKA662DceAt3Vxwj_2Wnn",
			"originalText": "SMPT",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 214,
			"versionNonce": 1602390355,
			"isDeleted": false,
			"id": "4vTspUjleYr2Zb_gSvn0X",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 124.91763375915207,
			"y": -229.35444957353337,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 285821789,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "SbIYIJEF"
				},
				{
					"id": "eU-ksHy-9dDhAbf5ZWLIK",
					"type": "arrow"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 162,
			"versionNonce": 918792541,
			"isDeleted": false,
			"id": "SbIYIJEF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 133.12765573180832,
			"y": -224.35444957353337,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 54.5799560546875,
			"height": 25,
			"seed": 1273092029,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680705,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "POP3",
			"rawText": "POP3",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "4vTspUjleYr2Zb_gSvn0X",
			"originalText": "POP3",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 200,
			"versionNonce": 1202448115,
			"isDeleted": false,
			"id": "L_hle50x3ZKO028xKTM0E",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 207.89587143745382,
			"y": -228.9715984971159,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1523831475,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "mS2VWMWn"
				}
			],
			"updated": 1685197680705,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 148,
			"versionNonce": 1184921021,
			"isDeleted": false,
			"id": "mS2VWMWn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 223.5658848651882,
			"y": -223.9715984971159,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.65997314453125,
			"height": 25,
			"seed": 1355613267,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "RPC",
			"rawText": "RPC",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "L_hle50x3ZKO028xKTM0E",
			"originalText": "RPC",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 181,
			"versionNonce": 1243123859,
			"isDeleted": false,
			"id": "fJSb_o5EhEAxN7HGImOV3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -408.38399694106886,
			"y": -307.602484296588,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1885097949,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Llreg944"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 130,
			"versionNonce": 1843705373,
			"isDeleted": false,
			"id": "Llreg944",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -399.6739749684126,
			"y": -302.602484296588,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 53.5799560546875,
			"height": 25,
			"seed": 1130384445,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SNMP",
			"rawText": "SNMP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "fJSb_o5EhEAxN7HGImOV3",
			"originalText": "SNMP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 574,
			"versionNonce": 1484719667,
			"isDeleted": false,
			"id": "5Qr-ZakHCsNqhttlE1cqQ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 60,
			"angle": 0,
			"x": -600.752354348538,
			"y": -166.4042874618189,
			"strokeColor": "#ffffff",
			"backgroundColor": "#f783ac",
			"width": 915.6792756553916,
			"height": 94.63439753690187,
			"seed": 2057112093,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 164,
			"versionNonce": 931261053,
			"isDeleted": false,
			"id": "n0AieaHS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -578.3015564489849,
			"y": -131.80823772250022,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 109.99989318847656,
			"height": 25,
			"seed": 1985656723,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Transporte",
			"rawText": "Transporte",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Transporte",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 604,
			"versionNonce": 1774569427,
			"isDeleted": false,
			"id": "ODW9ihveR8sYjgTM8U8Q2",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -444.94946344760285,
			"y": -135.90192517476783,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 147,
			"height": 35,
			"seed": 2026934653,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Ne7mr5ZE"
				},
				{
					"id": "1JqmhdDEIgPJfEAvj5b1b",
					"type": "arrow"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 104,
			"versionNonce": 1413059293,
			"isDeleted": false,
			"id": "Ne7mr5ZE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.9994512405716,
			"y": -130.90192517476783,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 43.0999755859375,
			"height": 25,
			"seed": 31060563,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "UDP",
			"rawText": "UDP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ODW9ihveR8sYjgTM8U8Q2",
			"originalText": "UDP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 938,
			"versionNonce": 1409504627,
			"isDeleted": false,
			"id": "nDLkIPZyC-BxMrOEPgrAz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -282.49097665998386,
			"y": -135.67714155671024,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 555,
			"height": 35,
			"seed": 1512033021,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "JSfW58vW"
				},
				{
					"id": "qUxNAlOczVIxzC3mCeb-m",
					"type": "arrow"
				},
				{
					"id": "rzlVzQJumhKypTC9GptH5",
					"type": "arrow"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 448,
			"versionNonce": 1620913981,
			"isDeleted": false,
			"id": "JSfW58vW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -26.08095773908542,
			"y": -130.67714155671024,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 42.179962158203125,
			"height": 25,
			"seed": 424108893,
			"groupIds": [
				"IRBBxS5N0UN0Tkq_Uxb9G",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "TCP",
			"rawText": "TCP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "nDLkIPZyC-BxMrOEPgrAz",
			"originalText": "TCP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 429,
			"versionNonce": 1719545619,
			"isDeleted": false,
			"id": "lA6UNJnfSSll_gpsHvTc6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 60,
			"angle": 0,
			"x": -600.4531961490686,
			"y": -64.83884440470186,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 915.6792756553916,
			"height": 154.75177214366707,
			"seed": 939787197,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 160,
			"versionNonce": 1796095901,
			"isDeleted": false,
			"id": "kHwNTiHf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -577.1245906681644,
			"y": 0.2573257653820349,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 35.879974365234375,
			"height": 25,
			"seed": 369067645,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Red",
			"rawText": "Red",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Red",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 430,
			"versionNonce": 1135400115,
			"isDeleted": false,
			"id": "e5vY7qdBiAO6EPKFGN77W",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -199.99218351602542,
			"y": -47.23484233339346,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 734027069,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "XFdZLf5V"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 379,
			"versionNonce": 968770557,
			"isDeleted": false,
			"id": "XFdZLf5V",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -190.6521642899512,
			"y": -42.23484233339346,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.31996154785156,
			"height": 25,
			"seed": 94088605,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ICMP",
			"rawText": "ICMP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "e5vY7qdBiAO6EPKFGN77W",
			"originalText": "ICMP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 386,
			"versionNonce": 2067121747,
			"isDeleted": false,
			"id": "zwmcuZ1rbLaWwmkzDkL7z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -124.96087496206258,
			"y": -47.401347945781794,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1135851219,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "4QESPMpy"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 335,
			"versionNonce": 1353628765,
			"isDeleted": false,
			"id": "4QESPMpy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -115.15085451528523,
			"y": -42.401347945781794,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 51.37995910644531,
			"height": 25,
			"seed": 945513587,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "OSPF",
			"rawText": "OSPF",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "zwmcuZ1rbLaWwmkzDkL7z",
			"originalText": "OSPF",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 341,
			"versionNonce": 1676641267,
			"isDeleted": false,
			"id": "IZNwc7J6aybi3Atix4l0v",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -49.25682849542352,
			"y": -46.71480904903197,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 1186908701,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "9brIGdfw"
				},
				{
					"id": "O9OpYzX7AjbCfASQNpTW9",
					"type": "arrow"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 288,
			"versionNonce": 934357181,
			"isDeleted": false,
			"id": "9brIGdfw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -32.59681720391961,
			"y": -41.71480904903197,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 37.67997741699219,
			"height": 25,
			"seed": 335117949,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "RIP",
			"rawText": "RIP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "IZNwc7J6aybi3Atix4l0v",
			"originalText": "RIP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 307,
			"versionNonce": 903908755,
			"isDeleted": false,
			"id": "6pBKNMvghApdDwtP2nm3c",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 34.44460633788901,
			"y": 30.731219204609005,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 40484029,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "wx6IUsKx"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 256,
			"versionNonce": 6752541,
			"isDeleted": false,
			"id": "wx6IUsKx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 43.584628615721044,
			"y": 35.731219204609005,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 52.71995544433594,
			"height": 25,
			"seed": 250420509,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "DHCP",
			"rawText": "DHCP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "6pBKNMvghApdDwtP2nm3c",
			"originalText": "DHCP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 275,
			"versionNonce": 1681875763,
			"isDeleted": false,
			"id": "qYmuojGo4zvHlFvYik8z-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 119.08115187100032,
			"y": 31.379140795234008,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 268297053,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "RlaJ3LNT"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 223,
			"versionNonce": 205643133,
			"isDeleted": false,
			"id": "RlaJ3LNT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 134.63116255215266,
			"y": 36.37914079523401,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.89997863769531,
			"height": 25,
			"seed": 813920189,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ARP",
			"rawText": "ARP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "qYmuojGo4zvHlFvYik8z-",
			"originalText": "ARP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 281,
			"versionNonce": 930251987,
			"isDeleted": false,
			"id": "9XY4LifdojvwzS9aPfry9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 202.2555319365614,
			"y": 30.466341655708078,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 71,
			"height": 35,
			"seed": 634714525,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "QXhTZ37f"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 230,
			"versionNonce": 310584797,
			"isDeleted": false,
			"id": "QXhTZ37f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 211.02554383841687,
			"y": 35.46634165570808,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 53.45997619628906,
			"height": 25,
			"seed": 530431485,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "RARP",
			"rawText": "RARP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9XY4LifdojvwzS9aPfry9",
			"originalText": "RARP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 1132,
			"versionNonce": 655389299,
			"isDeleted": false,
			"id": "CIdGu1EJZnMvMf3_Hu2ce",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -446.07530445606176,
			"y": 29.965183488637564,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 470,
			"height": 37,
			"seed": 726251133,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "6HBMWotN"
				},
				{
					"id": "-kU2ywwIS6EfRt1OdzBbF",
					"type": "arrow"
				},
				{
					"id": "iGN6qnxbU6RKywxYV-nni",
					"type": "arrow"
				},
				{
					"id": "R-wdxgTwLb7kng3J6d85q",
					"type": "arrow"
				},
				{
					"id": "EMLwbHVER3e_XV8z2Ojrv",
					"type": "arrow"
				},
				{
					"id": "O9OpYzX7AjbCfASQNpTW9",
					"type": "arrow"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 639,
			"versionNonce": 1715233341,
			"isDeleted": false,
			"id": "6HBMWotN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -223.13529438526098,
			"y": 35.965183488637564,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.119979858398438,
			"height": 25,
			"seed": 354934493,
			"groupIds": [
				"Hw7gZtLqtHXiADsf_U2z7",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "IP",
			"rawText": "IP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "CIdGu1EJZnMvMf3_Hu2ce",
			"originalText": "IP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 795,
			"versionNonce": 1944038419,
			"isDeleted": false,
			"id": "uOxGqdGIvZrxYy0StOy_j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 60,
			"angle": 0,
			"x": -599.6611469432162,
			"y": 98.76547105606701,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 915.6792756553916,
			"height": 94.63439753690187,
			"seed": 723322205,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 309,
			"versionNonce": 2085556893,
			"isDeleted": false,
			"id": "72qvc3lS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -576.2361884643045,
			"y": 121.17669054993638,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 62.39996337890625,
			"height": 50,
			"seed": 931017587,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Enlace\nFísica",
			"rawText": "Enlace\nFísica",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Enlace\nFísica",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "rectangle",
			"version": 896,
			"versionNonce": 30847411,
			"isDeleted": false,
			"id": "q2vwBl_XeAHj2B7WD-d-s",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -442.3001907145267,
			"y": 131.0621103671861,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 227,
			"height": 35,
			"seed": 261809277,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "9JSpq1Wf"
				}
			],
			"updated": 1685197680706,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 415,
			"versionNonce": 829208317,
			"isDeleted": false,
			"id": "9JSpq1Wf",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -381.0401504313236,
			"y": 136.0621103671861,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 104.47991943359375,
			"height": 25,
			"seed": 1931693277,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Token Ring",
			"rawText": "Token Ring",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "q2vwBl_XeAHj2B7WD-d-s",
			"originalText": "Token Ring",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 998,
			"versionNonce": 1914438483,
			"isDeleted": false,
			"id": "ZHVY8lswLCFA8uPq7j541",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -204.42791736484742,
			"y": 131.8660649473705,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 227,
			"height": 35,
			"seed": 584382419,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "S5rxNNYN"
				}
			],
			"updated": 1685197680707,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 524,
			"versionNonce": 1343672157,
			"isDeleted": false,
			"id": "S5rxNNYN",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -133.8178786075232,
			"y": 136.8660649473705,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 85.77992248535156,
			"height": 25,
			"seed": 61638003,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ethernet",
			"rawText": "Ethernet",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "ZHVY8lswLCFA8uPq7j541",
			"originalText": "Ethernet",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 952,
			"versionNonce": 539008253,
			"isDeleted": false,
			"id": "_fg6b0kpNaqgD-YOAvWM1",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 39.05988439281293,
			"y": 131.29861763351613,
			"strokeColor": "#ffffff",
			"backgroundColor": "#343a40",
			"width": 227,
			"height": 35,
			"seed": 481693683,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "RQf8x6wn"
				}
			],
			"updated": 1685197685034,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 474,
			"versionNonce": 1702985043,
			"isDeleted": false,
			"id": "RQf8x6wn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 132.72990544994184,
			"y": 136.29861763351613,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 39.65995788574219,
			"height": 25,
			"seed": 771070355,
			"groupIds": [
				"uQjJu_L9BT2_pNN4fMQQ5",
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": null,
			"boundElements": [],
			"updated": 1685197685034,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "PPP",
			"rawText": "PPP",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "_fg6b0kpNaqgD-YOAvWM1",
			"originalText": "PPP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 80,
			"versionNonce": 203131539,
			"isDeleted": false,
			"id": "-L_9--mNADb1U2ootYPlo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.77658243756036,
			"y": -272.87631166293517,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.7677298377785178,
			"height": 137.3454410030751,
			"seed": 1661131965,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.7677298377785178,
					137.3454410030751
				]
			]
		},
		{
			"type": "arrow",
			"version": 75,
			"versionNonce": 2099665949,
			"isDeleted": false,
			"id": "1JqmhdDEIgPJfEAvj5b1b",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -416.2022836737145,
			"y": -194.5586056349978,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.6428166294148809,
			"height": 57.65668046022998,
			"seed": 905782803,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "ODW9ihveR8sYjgTM8U8Q2",
				"gap": 1,
				"focus": -0.6187913310446135
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.6428166294148809,
					57.65668046022998
				]
			]
		},
		{
			"type": "arrow",
			"version": 113,
			"versionNonce": 336773171,
			"isDeleted": false,
			"id": "dGipw3wkUKm8PVmbAnN9x",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -329.83532170929016,
			"y": -192.87861242667034,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.31401327543778734,
			"height": 57.19227803497,
			"seed": 893451155,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ZAcyAlQCz9vnFRlenCTbW",
				"gap": 1,
				"focus": 0.016987030519189757
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.31401327543778734,
					57.19227803497
				]
			]
		},
		{
			"type": "arrow",
			"version": 101,
			"versionNonce": 2074005629,
			"isDeleted": false,
			"id": "qUxNAlOczVIxzC3mCeb-m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.90394894714382,
			"y": -192.25557354087655,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.12183826702232636,
			"height": 55.578431984166315,
			"seed": 184557661,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "D84q5cCYPB4kufQvbQXqm",
				"gap": 1,
				"focus": 0.002180639297660292
			},
			"endBinding": {
				"elementId": "nDLkIPZyC-BxMrOEPgrAz",
				"gap": 1,
				"focus": -0.9046510293238614
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.12183826702232636,
					55.578431984166315
				]
			]
		},
		{
			"type": "arrow",
			"version": 60,
			"versionNonce": 785531347,
			"isDeleted": false,
			"id": "MqAinOhlV_qMzD5n2FBP4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -181.9483126591146,
			"y": -194.9205978281119,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.718026834460602,
			"height": 60.035809472794426,
			"seed": 1685032317,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.718026834460602,
					60.035809472794426
				]
			]
		},
		{
			"type": "arrow",
			"version": 93,
			"versionNonce": 264878301,
			"isDeleted": false,
			"id": "s2Ta5mXiisVNtTlbLfjUh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -109.2847913519355,
			"y": -194.3159630622937,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 2.24548636907258,
			"height": 59.86872851500874,
			"seed": 1825905011,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					2.24548636907258,
					59.86872851500874
				]
			]
		},
		{
			"type": "arrow",
			"version": 89,
			"versionNonce": 1970311027,
			"isDeleted": false,
			"id": "SUbpA2dXgXtD50WCfbHsj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -20.01712646110006,
			"y": -192.58772735174645,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.455238412969475,
			"height": 58.418313301888105,
			"seed": 1750657459,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "t4IDSkmrPXwX_fMJdWTyd",
				"gap": 1,
				"focus": 0.0073829720178614855
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.455238412969475,
					58.418313301888105
				]
			]
		},
		{
			"type": "arrow",
			"version": 78,
			"versionNonce": 1127781693,
			"isDeleted": false,
			"id": "JhvAeuvIU7cQ_IsAl3gGJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 78.46200569797861,
			"y": -194.32257310782646,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.3643928319458496,
			"height": 60.24663588213042,
			"seed": 347256467,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.3643928319458496,
					60.24663588213042
				]
			]
		},
		{
			"type": "arrow",
			"version": 90,
			"versionNonce": 439626003,
			"isDeleted": false,
			"id": "eU-ksHy-9dDhAbf5ZWLIK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 160.54259320082167,
			"y": -193.35444957353337,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.0835443340574784,
			"height": 58.08630694662031,
			"seed": 803379421,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "4vTspUjleYr2Zb_gSvn0X",
				"gap": 1,
				"focus": 0.006144631624916628
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0835443340574784,
					58.08630694662031
				]
			]
		},
		{
			"type": "arrow",
			"version": 88,
			"versionNonce": 1900864925,
			"isDeleted": false,
			"id": "rzlVzQJumhKypTC9GptH5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 242.4146814198216,
			"y": -194.74293512361623,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.1122920101869624,
			"height": 58.06579356690597,
			"seed": 1242649683,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "nDLkIPZyC-BxMrOEPgrAz",
				"gap": 1,
				"focus": 0.8851972790844201
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.1122920101869624,
					58.06579356690597
				]
			]
		},
		{
			"type": "arrow",
			"version": 111,
			"versionNonce": 1116966579,
			"isDeleted": false,
			"id": "-kU2ywwIS6EfRt1OdzBbF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -372.2846305080315,
			"y": -101.0454829608606,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.373907296649179,
			"height": 130.00233291015587,
			"seed": 1686775581,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "CIdGu1EJZnMvMf3_Hu2ce",
				"gap": 1.0083335393422885,
				"focus": -0.6840124005574743
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.373907296649179,
					130.00233291015587
				]
			]
		},
		{
			"type": "arrow",
			"version": 110,
			"versionNonce": 221784573,
			"isDeleted": false,
			"id": "iGN6qnxbU6RKywxYV-nni",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.75781909282972,
			"y": -100.93087101257053,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.0892789537201963,
			"height": 129.89605450120808,
			"seed": 506514525,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "CIdGu1EJZnMvMf3_Hu2ce",
				"gap": 1,
				"focus": -0.03584745459748841
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0892789537201963,
					129.89605450120808
				]
			]
		},
		{
			"type": "arrow",
			"version": 100,
			"versionNonce": 557138003,
			"isDeleted": false,
			"id": "R-wdxgTwLb7kng3J6d85q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -163.01779474760335,
			"y": -12.247067463033176,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 1.3624069813566564,
			"height": 41.08130532309352,
			"seed": 1315245331,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "CIdGu1EJZnMvMf3_Hu2ce",
				"gap": 1.1309456285772228,
				"focus": 0.19542200680565755
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-1.3624069813566564,
					41.08130532309352
				]
			]
		},
		{
			"type": "arrow",
			"version": 71,
			"versionNonce": 670818909,
			"isDeleted": false,
			"id": "EMLwbHVER3e_XV8z2Ojrv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -89.35385865218166,
			"y": -12.698564779131189,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.8372054004783962,
			"height": 41.66374826776875,
			"seed": 1334337693,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "CIdGu1EJZnMvMf3_Hu2ce",
				"gap": 1,
				"focus": 0.5223672478353754
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.8372054004783962,
					41.66374826776875
				]
			]
		},
		{
			"type": "arrow",
			"version": 102,
			"versionNonce": 1341111795,
			"isDeleted": false,
			"id": "O9OpYzX7AjbCfASQNpTW9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -13.854804265322517,
			"y": -10.71480904903197,
			"strokeColor": "#ffffff",
			"backgroundColor": "#69db7c",
			"width": 0.4735766850134837,
			"height": 39.679992537669534,
			"seed": 728815197,
			"groupIds": [
				"hU-DPaUPVozgcXd52VdDI"
			],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685197680707,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "IZNwc7J6aybi3Atix4l0v",
				"gap": 1,
				"focus": 0.008926955002925419
			},
			"endBinding": {
				"elementId": "CIdGu1EJZnMvMf3_Hu2ce",
				"gap": 1,
				"focus": 0.8414511432676177
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.4735766850134837,
					39.679992537669534
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#343a40",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": null,
		"scrollX": 641.0160111080193,
		"scrollY": 258.70801160542385,
		"zoom": {
			"value": 1.3
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%