---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Preámb.  SFD  MAC Orig.  MAC Dest.  Long                      Datos (trama LLC)                      CRC ^xU3biCkK

Trama Ethernet ^FqjTJv4z

Datos (Paquete IP) ^fk8HyiDS

IP ^qRFflPYv

Ethernet
(802.3) ^3k7TCz9P

DSAP SSAP Control ORG Tipo ^WvkglUoN

(AA)     (AA)     (03)     (00)  (0800) ^Z7WnBShq

Paquete IP ^BCAJLL9m

LLC
(802.2) ^a9PChl5j

Trama LLC (UI) ^xdZNqlc2

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 695,
			"versionNonce": 2052234430,
			"isDeleted": false,
			"id": "WN9ZSQZb2o-5ZPX-lj2wG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -396.344899412876,
			"y": -80.75927615860519,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 311.5372191114286,
			"height": 65.78777376092057,
			"seed": 1219656574,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 412,
			"versionNonce": 2134971938,
			"isDeleted": false,
			"id": "WcpdFvva3td3sRE25CDhA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 202.47351681402495,
			"y": -79.64297972900093,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a2a428",
			"width": 91.3841552734375,
			"height": 65.21749877929688,
			"seed": 1441266146,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 789,
			"versionNonce": 901937122,
			"isDeleted": false,
			"id": "LtCNC05DxvBwrV3u22C6r",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -83.94699494515567,
			"y": -79.09377780437953,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 284.95590992512143,
			"height": 64.97039967072214,
			"seed": 1219656574,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "iIqLV2VI1NW6QHDkU-DAC",
					"type": "arrow"
				}
			],
			"updated": 1682157705599,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 584,
			"versionNonce": 1421738466,
			"isDeleted": false,
			"id": "GQt3nR1DLxc4Bk23G3vsF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -856.2400551077856,
			"y": -80.63883358538183,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a2a428",
			"width": 461.02077784401075,
			"height": 64.39593505859375,
			"seed": 319333246,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 241,
			"versionNonce": 1602553150,
			"isDeleted": false,
			"id": "xU3biCkK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -841.0526988710344,
			"y": -58.684686210506555,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1106.3995361328125,
			"height": 25,
			"seed": 220478306,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Preámb.  SFD  MAC Orig.  MAC Dest.  Long                      Datos (trama LLC)                      CRC",
			"rawText": "Preámb.  SFD  MAC Orig.  MAC Dest.  Long                      Datos (trama LLC)                      CRC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Preámb.  SFD  MAC Orig.  MAC Dest.  Long                      Datos (trama LLC)                      CRC",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 86,
			"versionNonce": 187135394,
			"isDeleted": false,
			"id": "6dTXLJ4UzccsK11c913sF",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -755.3613672294164,
			"y": -81.18656307756933,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3607177734375,
			"height": 62.35479736328125,
			"seed": 1594971838,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.3607177734375,
					62.35479736328125
				]
			]
		},
		{
			"type": "line",
			"version": 140,
			"versionNonce": 896380286,
			"isDeleted": false,
			"id": "d9vqZXKB0Zi94NXykFWcZ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -698.8985023069205,
			"y": -80.23556913108351,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3251953125,
			"height": 60.720184326171875,
			"seed": 255086690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3251953125,
					60.720184326171875
				]
			]
		},
		{
			"type": "line",
			"version": 116,
			"versionNonce": 1672245602,
			"isDeleted": false,
			"id": "rGguOQwGl3PlrTR0hJU9m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -586.755515354406,
			"y": -82.93100191488546,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.5477294921875,
			"height": 61.828460693359375,
			"seed": 1442058750,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.5477294921875,
					61.828460693359375
				]
			]
		},
		{
			"type": "line",
			"version": 165,
			"versionNonce": 1352093118,
			"isDeleted": false,
			"id": "SjRbmPwY9ESaBnAfNOfoE",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -460.7210849025928,
			"y": -78.77318871934372,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 60.908447265625,
			"seed": 713933602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					60.908447265625
				]
			]
		},
		{
			"type": "text",
			"version": 130,
			"versionNonce": 65662178,
			"isDeleted": false,
			"id": "FqjTJv4z",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -852.6575804477773,
			"y": -123.2015489728361,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 223.71990966796875,
			"height": 35,
			"seed": 1841881506,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157745409,
			"link": null,
			"locked": false,
			"fontSize": 28,
			"fontFamily": 1,
			"text": "Trama Ethernet",
			"rawText": "Trama Ethernet",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Trama Ethernet",
			"lineHeight": 1.25,
			"baseline": 24
		},
		{
			"type": "line",
			"version": 344,
			"versionNonce": 1310909950,
			"isDeleted": false,
			"id": "SFkOtxibOp0jzf5Khixe7",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -397.20312242149,
			"y": -84.35591860470052,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.20538330078125,
			"height": 70.72470092773438,
			"seed": 1673745250,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681875,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.20538330078125,
					-70.72470092773438
				]
			]
		},
		{
			"type": "line",
			"version": 416,
			"versionNonce": 1181024482,
			"isDeleted": false,
			"id": "oMZqd3osL_DqZkVIBFxFy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 199.73508549610062,
			"y": -83.76940885593612,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.0869140625,
			"height": 72.77865600585938,
			"seed": 1379868514,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0869140625,
					-72.77865600585938
				]
			]
		},
		{
			"type": "rectangle",
			"version": 570,
			"versionNonce": 1290562914,
			"isDeleted": false,
			"id": "TSRX8FrW1gjgUYPUwlR5B",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -83.82237082549403,
			"y": -214.2793045964472,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 285.5609608364112,
			"height": 56.11146626654573,
			"seed": 85546082,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "64cZlMFnFrldHkSf0rU7s",
					"type": "arrow"
				}
			],
			"updated": 1682157692290,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 409,
			"versionNonce": 1301714082,
			"isDeleted": false,
			"id": "fk8HyiDS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -56.26710782215207,
			"y": -195.9783316611354,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 203.3798370361328,
			"height": 25,
			"seed": 864700478,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datos (Paquete IP)",
			"rawText": "Datos (Paquete IP)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datos (Paquete IP)",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 1172,
			"versionNonce": 1816395390,
			"isDeleted": false,
			"id": "FsLaaQVXG_IJ2CIGSHi5U",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 462.05004244574945,
			"y": -344.9316598884893,
			"strokeColor": "#2b8a3e",
			"backgroundColor": "transparent",
			"width": 18.42648715367397,
			"height": 71.11840623719742,
			"seed": 1972422078,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.372776849452755,
					9.685729607244532
				],
				[
					13.64856491341974,
					22.346763958487717
				],
				[
					8.880915123802447,
					31.79120151788073
				],
				[
					18.42648715367397,
					35.97498603849374
				],
				[
					8.796622328861602,
					41.86179521253007
				],
				[
					13.866693065230452,
					50.929333057192856
				],
				[
					15.716497276212952,
					62.25427278180567
				],
				[
					3.5700581445036885,
					71.11840623719742
				]
			]
		},
		{
			"type": "text",
			"version": 359,
			"versionNonce": 1759490146,
			"isDeleted": false,
			"id": "qRFflPYv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 525.9389045513059,
			"y": -319.985901396303,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.119979858398438,
			"height": 25,
			"seed": 321906174,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "IP",
			"rawText": "IP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "IP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 232,
			"versionNonce": 1518042814,
			"isDeleted": false,
			"id": "3k7TCz9P",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 506.3557965009487,
			"y": -68.4100746101864,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 85.77992248535156,
			"height": 50,
			"seed": 303103614,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ethernet\n(802.3)",
			"rawText": "Ethernet\n(802.3)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Ethernet\n(802.3)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"type": "line",
			"version": 1053,
			"versionNonce": 1007637538,
			"isDeleted": false,
			"id": "loz6qj0ION2B8yJ2NrcGb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 464.24750614385766,
			"y": -79.26126326069712,
			"strokeColor": "#a1a329",
			"backgroundColor": "transparent",
			"width": 18.42648715367397,
			"height": 71.11840623719742,
			"seed": 1972422078,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.372776849452755,
					9.685729607244532
				],
				[
					13.64856491341974,
					22.346763958487717
				],
				[
					8.880915123802447,
					31.79120151788073
				],
				[
					18.42648715367397,
					35.97498603849374
				],
				[
					8.796622328861602,
					41.86179521253007
				],
				[
					13.866693065230452,
					50.929333057192856
				],
				[
					15.716497276212952,
					62.25427278180567
				],
				[
					3.5700581445036885,
					71.11840623719742
				]
			]
		},
		{
			"type": "rectangle",
			"version": 785,
			"versionNonce": 1314453246,
			"isDeleted": false,
			"id": "SybasaFYtDZ_IyNraU32e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -398.20357248480724,
			"y": -212.5508752881448,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 315.6485708634961,
			"height": 53.138157855215745,
			"seed": 85546082,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false
		},
		{
			"id": "WvkglUoN",
			"type": "text",
			"x": -395.7650483325182,
			"y": -200.94293679993052,
			"width": 299.559814453125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 286075682,
			"version": 132,
			"versionNonce": 420773858,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"text": "DSAP SSAP Control ORG Tipo",
			"rawText": "DSAP SSAP Control ORG Tipo",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "DSAP SSAP Control ORG Tipo",
			"lineHeight": 1.25
		},
		{
			"id": "Z7WnBShq",
			"type": "text",
			"x": -392.85613658833506,
			"y": -176.80561073937616,
			"width": 307.1492004394531,
			"height": 18.76800723240462,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 777961982,
			"version": 188,
			"versionNonce": 705365694,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "iIqLV2VI1NW6QHDkU-DAC",
					"type": "arrow"
				}
			],
			"updated": 1682157705599,
			"link": null,
			"locked": false,
			"text": "(AA)     (AA)     (03)     (00)  (0800)",
			"rawText": "(AA)     (AA)     (03)     (00)  (0800)",
			"fontSize": 15.014405785923698,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 13,
			"containerId": null,
			"originalText": "(AA)     (AA)     (03)     (00)  (0800)",
			"lineHeight": 1.25
		},
		{
			"id": "XaAPkukNkFIikA5MYPH8j",
			"type": "line",
			"x": -336.6066805691304,
			"y": -212.28290071910192,
			"width": 0.04507307707626751,
			"height": 52.25273172236507,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1099865314,
			"version": 76,
			"versionNonce": 1006515106,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-0.04507307707626751,
					52.25273172236507
				]
			],
			"lastCommittedPoint": [
				-0.04507307707626751,
				52.25273172236507
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "T-hQ3URypgNkulJXAoyP7",
			"type": "line",
			"x": -275.8907671870995,
			"y": -213.66019992870343,
			"width": 0.33460563328537773,
			"height": 54.942933474421466,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 187562878,
			"version": 55,
			"versionNonce": 820629374,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.33460563328537773,
					54.942933474421466
				]
			],
			"lastCommittedPoint": [
				0.33460563328537773,
				54.942933474421466
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "zqV4ai-_FqMrxllv95f-V",
			"type": "line",
			"x": -194.29702286302927,
			"y": -212.81065045456359,
			"width": 0,
			"height": 53.47553400993115,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 524462654,
			"version": 41,
			"versionNonce": 117141346,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					53.47553400993115
				]
			],
			"lastCommittedPoint": [
				0,
				53.47553400993115
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "wMTzVS-i6B6Kwlv5BjgyL",
			"type": "line",
			"x": -141.40069166330784,
			"y": -212.3665750770552,
			"width": 0,
			"height": 53.507709393872574,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1092050750,
			"version": 53,
			"versionNonce": 205467582,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					53.507709393872574
				]
			],
			"lastCommittedPoint": [
				0,
				53.507709393872574
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "line",
			"version": 436,
			"versionNonce": 1046164258,
			"isDeleted": false,
			"id": "-ullKIB9WTR6KGiQAW8Ze",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 201.21449476749626,
			"y": -216.61160755813577,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.0869140625,
			"height": 72.77865600585938,
			"seed": 1379868514,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0869140625,
					-72.77865600585938
				]
			]
		},
		{
			"type": "line",
			"version": 382,
			"versionNonce": 1316915198,
			"isDeleted": false,
			"id": "yGnOUaUm0XNAHrCPMtJGq",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -83.39033503144435,
			"y": -218.29567701656524,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.20538330078125,
			"height": 70.72470092773438,
			"seed": 1673745250,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.20538330078125,
					-70.72470092773438
				]
			]
		},
		{
			"type": "rectangle",
			"version": 603,
			"versionNonce": 1001845154,
			"isDeleted": false,
			"id": "IKED5iHNWDGA1W0Dle1Ki",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -83.5365794050488,
			"y": -341.22957617013657,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 285.5609608364112,
			"height": 56.11146626654573,
			"seed": 85546082,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "64cZlMFnFrldHkSf0rU7s",
					"type": "arrow"
				}
			],
			"updated": 1682157692290,
			"link": null,
			"locked": false
		},
		{
			"id": "BCAJLL9m",
			"type": "text",
			"x": -4.481902493472603,
			"y": -323.00404247103404,
			"width": 116.13990783691406,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 649686498,
			"version": 76,
			"versionNonce": 2007554110,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"text": "Paquete IP",
			"rawText": "Paquete IP",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 17,
			"containerId": null,
			"originalText": "Paquete IP",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 1257,
			"versionNonce": 1444827810,
			"isDeleted": false,
			"id": "ykSZUKAeL1SafT5bXMtBB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 466.95795331027057,
			"y": -220.87567682390625,
			"strokeColor": "#1864ab",
			"backgroundColor": "transparent",
			"width": 18.42648715367397,
			"height": 71.11840623719742,
			"seed": 1972422078,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.372776849452755,
					9.685729607244532
				],
				[
					13.64856491341974,
					22.346763958487717
				],
				[
					8.880915123802447,
					31.79120151788073
				],
				[
					18.42648715367397,
					35.97498603849374
				],
				[
					8.796622328861602,
					41.86179521253007
				],
				[
					13.866693065230452,
					50.929333057192856
				],
				[
					15.716497276212952,
					62.25427278180567
				],
				[
					3.5700581445036885,
					71.11840623719742
				]
			]
		},
		{
			"type": "text",
			"version": 442,
			"versionNonce": 1604264062,
			"isDeleted": false,
			"id": "a9PChl5j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 504.2279963530643,
			"y": -203.0286525756552,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 78.07994079589844,
			"height": 50,
			"seed": 321906174,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157681876,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "LLC\n(802.2)",
			"rawText": "LLC\n(802.2)",
			"textAlign": "center",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "LLC\n(802.2)",
			"lineHeight": 1.25,
			"baseline": 42
		},
		{
			"id": "iIqLV2VI1NW6QHDkU-DAC",
			"type": "arrow",
			"x": -83.23787893229007,
			"y": -156.2449026083391,
			"width": 2.3555502195071085,
			"height": 74.79748622874286,
			"angle": 0,
			"strokeColor": "#1864ab",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 301011170,
			"version": 124,
			"versionNonce": 1470820158,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157706395,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					2.3555502195071085,
					74.79748622874286
				]
			],
			"lastCommittedPoint": [
				2.3555502195071085,
				60.21386723431124
			],
			"startBinding": {
				"elementId": "Z7WnBShq",
				"focus": -1.011838241906532,
				"gap": 2.469057216591864
			},
			"endBinding": {
				"elementId": "LtCNC05DxvBwrV3u22C6r",
				"focus": -0.9638688219643524,
				"gap": 2.3536385752167064
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "arrow",
			"version": 94,
			"versionNonce": 1603807742,
			"isDeleted": false,
			"id": "64cZlMFnFrldHkSf0rU7s",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 55.30328402696338,
			"y": -280.4710504900062,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 2.3555502195071085,
			"height": 60.21386723431124,
			"seed": 301011170,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682157697562,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "IKED5iHNWDGA1W0Dle1Ki",
				"focus": 0.03628032722196283,
				"gap": 4.647059413584628
			},
			"endBinding": {
				"elementId": "TSRX8FrW1gjgUYPUwlR5B",
				"focus": 0.00022317762283165988,
				"gap": 5.97787865924775
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					2.3555502195071085,
					60.21386723431124
				]
			]
		},
		{
			"id": "xdZNqlc2",
			"type": "text",
			"x": -391.44598481063315,
			"y": -255.53966172178872,
			"width": 225.5399169921875,
			"height": 35,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1162237822,
			"version": 121,
			"versionNonce": 2003931746,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157749442,
			"link": null,
			"locked": false,
			"text": "Trama LLC (UI)",
			"rawText": "Trama LLC (UI)",
			"fontSize": 28,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "top",
			"baseline": 24,
			"containerId": null,
			"originalText": "Trama LLC (UI)",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 28,
		"currentItemTextAlign": "center",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 971.1291654107107,
		"scrollY": 592.8114015260912,
		"zoom": {
			"value": 0.6648816469311714
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%