---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Emisor ^XF0v5o35

Receptor ^6a1kWlNn

Datagrama UDP ^IoJa5SBH

Puerto destino cerrado ^PymFgVyZ

ICMP Destination Unreachable
(UDP Port Unreachable) ^dhY6jZ4A

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "line",
			"version": 221,
			"versionNonce": 1646838640,
			"isDeleted": false,
			"id": "RjtQOjguB5i1S5nwr6QUx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -140.2734146118164,
			"y": -177.5260467529297,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 2.1381745515046475,
			"height": 130.87613593207465,
			"seed": 891828112,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614350869,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.1381745515046475,
					130.87613593207465
				]
			]
		},
		{
			"type": "line",
			"version": 311,
			"versionNonce": 705321360,
			"isDeleted": false,
			"id": "Cxl8Gel6bz4oXpq4DV-XA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 29.412191933323143,
			"y": -175.39886252212807,
			"strokeColor": "#f08c00",
			"backgroundColor": "transparent",
			"width": 0.6547006893107437,
			"height": 128.1349597990743,
			"seed": 420678000,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614365689,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.6547006893107437,
					128.1349597990743
				]
			]
		},
		{
			"type": "arrow",
			"version": 97,
			"versionNonce": 1068458864,
			"isDeleted": false,
			"id": "4uoEJIxfSSfz_hf5azB3Q",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.4814597235786,
			"y": -150.98488645200376,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.43161583318837,
			"height": 19.5217491092001,
			"seed": 25651600,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614279462,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "PymFgVyZ",
				"focus": -0.591869740524661,
				"gap": 4.873728292960081
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					168.43161583318837,
					19.5217491092001
				]
			]
		},
		{
			"type": "text",
			"version": 82,
			"versionNonce": 320109456,
			"isDeleted": false,
			"id": "XF0v5o35",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -171.90166473388672,
			"y": -209.30404663085938,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 61.0599365234375,
			"height": 25,
			"seed": 840245648,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Emisor",
			"rawText": "Emisor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Emisor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 78,
			"versionNonce": 858703216,
			"isDeleted": false,
			"id": "6a1kWlNn",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -13.554023742675781,
			"y": -206.16795349121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 86.31991577148438,
			"height": 25,
			"seed": 1327880560,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Receptor",
			"rawText": "Receptor",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Receptor",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 138,
			"versionNonce": 756376976,
			"isDeleted": false,
			"id": "IoJa5SBH",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -311.05401611328125,
			"y": -163.318359375,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 164.63990783691406,
			"height": 25,
			"seed": 1928374160,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685613948325,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Datagrama UDP",
			"rawText": "Datagrama UDP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Datagrama UDP",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 155,
			"versionNonce": 2052390288,
			"isDeleted": false,
			"id": "PymFgVyZ",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 33.82388440256986,
			"y": -145.36240000122797,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 229.75978088378906,
			"height": 25,
			"seed": 1467459440,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "4uoEJIxfSSfz_hf5azB3Q",
					"type": "arrow"
				}
			],
			"updated": 1685614279462,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Puerto destino cerrado",
			"rawText": "Puerto destino cerrado",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Puerto destino cerrado",
			"lineHeight": 1.25,
			"baseline": 18
		},
		{
			"type": "text",
			"version": 206,
			"versionNonce": 795889552,
			"isDeleted": false,
			"id": "dhY6jZ4A",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 33.06563101874485,
			"y": -113.58556324002086,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 300.2997741699219,
			"height": 50,
			"seed": 375634320,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685614288065,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "ICMP Destination Unreachable\n(UDP Port Unreachable)",
			"rawText": "ICMP Destination Unreachable\n(UDP Port Unreachable)",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ICMP Destination Unreachable\n(UDP Port Unreachable)",
			"lineHeight": 1.25,
			"baseline": 43
		},
		{
			"type": "arrow",
			"version": 151,
			"versionNonce": 692695952,
			"isDeleted": false,
			"id": "gTXYfw4H0S2vbJVzKiyve",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 27.18668057044038,
			"y": -89.88695946383646,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 168.43161583318837,
			"height": 19.5217491092001,
			"seed": 985826160,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1685614301390,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-168.43161583318837,
					19.5217491092001
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#f08c00",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 180.0569535598455,
		"scrollY": 322.09379924305637,
		"zoom": {
			"value": 0.9407313123345377
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%