---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Preámb.    SFD    MAC Orig.    MAC Dest.       Tipo            Datos (paquete IP)        CRC ^HDMWrXIB

Trama Ethernet ^vIOX96g4

Paquete IP ^oCggH44M

IP ^VIHaPAwb

Ethernet II ^EggPxTE4

(0800) ^0fdYfzzv

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.24",
	"elements": [
		{
			"type": "rectangle",
			"version": 77,
			"versionNonce": 1377609982,
			"isDeleted": false,
			"id": "O2f82rdnyEEOMIVxvJ7MB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 452.0755310058594,
			"y": -54.006248474121094,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a2a428",
			"width": 91.3841552734375,
			"height": 65.21749877929688,
			"seed": 1441266146,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156266054,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 212,
			"versionNonce": 587541602,
			"isDeleted": false,
			"id": "a5l2qsh33p_4brIW4IhmK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 139.19332885742188,
			"y": -54.446983337402344,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 310.79833984375,
			"height": 65.36297607421875,
			"seed": 1219656574,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "55J6mJ35W_NjTQM8k3r4M",
					"type": "arrow"
				}
			],
			"updated": 1682156497641,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 444,
			"versionNonce": 394147070,
			"isDeleted": false,
			"id": "sLXQOqupBM1-hzwAfr7dm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -491.5339660644531,
			"y": -54.429954528808594,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a2a428",
			"width": 629.2861938476562,
			"height": 64.39593505859375,
			"seed": 319333246,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156195859,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 152,
			"versionNonce": 429649790,
			"isDeleted": false,
			"id": "HDMWrXIB",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -475.9281921386719,
			"y": -31.94762420654297,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 982.0794677734375,
			"height": 25,
			"seed": 220478306,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682157927446,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Preámb.    SFD    MAC Orig.    MAC Dest.       Tipo            Datos (paquete IP)        CRC",
			"rawText": "Preámb.    SFD    MAC Orig.    MAC Dest.       Tipo            Datos (paquete IP)        CRC",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Preámb.    SFD    MAC Orig.    MAC Dest.       Tipo            Datos (paquete IP)        CRC",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 67,
			"versionNonce": 627187774,
			"isDeleted": false,
			"id": "72Dix2B5ObZ5HK21Ol_hx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -384.8179016113281,
			"y": -54.977684020996094,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.3607177734375,
			"height": 62.35479736328125,
			"seed": 1594971838,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156184247,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.3607177734375,
					62.35479736328125
				]
			]
		},
		{
			"type": "line",
			"version": 95,
			"versionNonce": 1904052898,
			"isDeleted": false,
			"id": "iCk9yO6b3DciyBt56QDTW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -303.7378845214844,
			"y": -53.59551239013672,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.3251953125,
			"height": 60.720184326171875,
			"seed": 255086690,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156184247,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.3251953125,
					60.720184326171875
				]
			]
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 384788606,
			"isDeleted": false,
			"id": "dyeNY4BPZCLGCj6H4PVMh",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -168.79269409179688,
			"y": -54.05767059326172,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.5477294921875,
			"height": 61.828460693359375,
			"seed": 1442058750,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156184247,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.5477294921875,
					61.828460693359375
				]
			]
		},
		{
			"type": "line",
			"version": 93,
			"versionNonce": 544728674,
			"isDeleted": false,
			"id": "VbbK4b0BdBLC6BpTe6W52",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -22.974395751953125,
			"y": -53.35588836669922,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0,
			"height": 60.908447265625,
			"seed": 713933602,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156184247,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					60.908447265625
				]
			]
		},
		{
			"type": "text",
			"version": 80,
			"versionNonce": 1827837858,
			"isDeleted": false,
			"id": "vIOX96g4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -481.18731689453125,
			"y": -101.2925033569336,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 159.7998809814453,
			"height": 25,
			"seed": 1841881506,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156281076,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Trama Ethernet",
			"rawText": "Trama Ethernet",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Trama Ethernet",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 221,
			"versionNonce": 346234750,
			"isDeleted": false,
			"id": "fmluoX6qwH05oCOkiOL20",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 137.47390747070312,
			"y": -57.953941345214844,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 0.20538330078125,
			"height": 70.72470092773438,
			"seed": 1673745250,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156401968,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					0.20538330078125,
					-70.72470092773438
				]
			]
		},
		{
			"type": "line",
			"version": 86,
			"versionNonce": 959756450,
			"isDeleted": false,
			"id": "-uKpXy9ozbcC32Yiv9n8e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 450.0951843261719,
			"y": -53.460899353027344,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 1.0869140625,
			"height": 72.77865600585938,
			"seed": 1379868514,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156415019,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					1.0869140625,
					-72.77865600585938
				]
			]
		},
		{
			"type": "rectangle",
			"version": 175,
			"versionNonce": 1572573346,
			"isDeleted": false,
			"id": "IkoJ-bbP4Smgj4cAzBKNm",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 138.29122924804688,
			"y": -183.19844818115234,
			"strokeColor": "#ffffff",
			"backgroundColor": "#40c057",
			"width": 310.1392822265625,
			"height": 56.95458984375,
			"seed": 85546082,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "55J6mJ35W_NjTQM8k3r4M",
					"type": "arrow"
				}
			],
			"updated": 1682156497641,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 43,
			"versionNonce": 1514666338,
			"isDeleted": false,
			"id": "oCggH44M",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 235.53341674804688,
			"y": -167.01494598388672,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 116.13990783691406,
			"height": 25,
			"seed": 864700478,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156459468,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Paquete IP",
			"rawText": "Paquete IP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Paquete IP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "arrow",
			"version": 103,
			"versionNonce": 972911550,
			"isDeleted": false,
			"id": "55J6mJ35W_NjTQM8k3r4M",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": 286.8247985839844,
			"y": -115.80742645263672,
			"strokeColor": "#2b8a3e",
			"backgroundColor": "#40c057",
			"width": 1.0697021484375,
			"height": 53.29168701171875,
			"seed": 706777982,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156513263,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "IkoJ-bbP4Smgj4cAzBKNm",
				"focus": 0.047013056240097974,
				"gap": 10.436431884765625
			},
			"endBinding": {
				"elementId": "a5l2qsh33p_4brIW4IhmK",
				"focus": -0.03767920700823763,
				"gap": 8.068756103515625
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					1.0697021484375,
					53.29168701171875
				]
			]
		},
		{
			"type": "line",
			"version": 926,
			"versionNonce": 1817399998,
			"isDeleted": false,
			"id": "PE2Mp5_tyovWGaHLaUB3_",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 587.5817565917969,
			"y": -191.15703582763672,
			"strokeColor": "#2b8a3e",
			"backgroundColor": "transparent",
			"width": 18.42648715367397,
			"height": 71.11840623719742,
			"seed": 1972422078,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156707096,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.372776849452755,
					9.685729607244532
				],
				[
					13.64856491341974,
					22.346763958487717
				],
				[
					8.880915123802447,
					31.79120151788073
				],
				[
					18.42648715367397,
					35.97498603849374
				],
				[
					8.796622328861602,
					41.86179521253007
				],
				[
					13.866693065230452,
					50.929333057192856
				],
				[
					15.716497276212952,
					62.25427278180567
				],
				[
					3.5700581445036885,
					71.11840623719742
				]
			]
		},
		{
			"type": "text",
			"version": 46,
			"versionNonce": 378449086,
			"isDeleted": false,
			"id": "VIHaPAwb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 654.6820983886719,
			"y": -153.73213958740234,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 24.119979858398438,
			"height": 25,
			"seed": 321906174,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156704110,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "IP",
			"rawText": "IP",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "IP",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 42,
			"versionNonce": 171875390,
			"isDeleted": false,
			"id": "EggPxTE4",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 642.2941589355469,
			"y": -35.59093475341797,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 117.57991027832031,
			"height": 25,
			"seed": 303103614,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1682156698001,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Ethernet II",
			"rawText": "Ethernet II",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Ethernet II",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "line",
			"version": 904,
			"versionNonce": 1620569918,
			"isDeleted": false,
			"id": "Bl58i7RA0DAOuFB7jJVjd",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 587.5909269877769,
			"y": -57.32516015172067,
			"strokeColor": "#a1a329",
			"backgroundColor": "transparent",
			"width": 18.42648715367397,
			"height": 71.11840623719742,
			"seed": 1972422078,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1682156700495,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					11.372776849452755,
					9.685729607244532
				],
				[
					13.64856491341974,
					22.346763958487717
				],
				[
					8.880915123802447,
					31.79120151788073
				],
				[
					18.42648715367397,
					35.97498603849374
				],
				[
					8.796622328861602,
					41.86179521253007
				],
				[
					13.866693065230452,
					50.929333057192856
				],
				[
					15.716497276212952,
					62.25427278180567
				],
				[
					3.5700581445036885,
					71.11840623719742
				]
			]
		},
		{
			"id": "0fdYfzzv",
			"type": "text",
			"x": 18.792436700118287,
			"y": -6.845069998345593,
			"width": 57.31196594238281,
			"height": 20,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1375424354,
			"version": 53,
			"versionNonce": 1575840930,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1682157951936,
			"link": null,
			"locked": false,
			"text": "(0800)",
			"rawText": "(0800)",
			"fontSize": 16,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 14,
			"containerId": null,
			"originalText": "(0800)",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#2e3440",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 531.2633622822008,
		"scrollY": 536.113651991047,
		"zoom": {
			"value": 0.9500000000000001
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%