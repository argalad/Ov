---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Red ^OhSn4JSJ

Host ^R9GJOItC

(32 - n) bits ^yasmdZ5j

n bits ^TWIrKsQb

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.9.2",
	"elements": [
		{
			"type": "rectangle",
			"version": 190,
			"versionNonce": 714359293,
			"isDeleted": false,
			"id": "KDJsbq_-cdiswgqNtnoa-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -413.396728515625,
			"y": -139.86151123046875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#fd7e14",
			"width": 323,
			"height": 66,
			"seed": 313692563,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "OhSn4JSJ"
				}
			],
			"updated": 1685208365147,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 29,
			"versionNonce": 1685079357,
			"isDeleted": false,
			"id": "OhSn4JSJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -269.8367156982422,
			"y": -119.36151123046875,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 35.879974365234375,
			"height": 25,
			"seed": 896774877,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685208703456,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Red",
			"rawText": "Red",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "KDJsbq_-cdiswgqNtnoa-",
			"originalText": "Red",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "rectangle",
			"version": 490,
			"versionNonce": 1880003997,
			"isDeleted": false,
			"id": "sCYXBRmiCXdVhrBiH-H7-",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -89.96420288085938,
			"y": -140.48004150390625,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 196,
			"height": 66,
			"seed": 1401299411,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"type": "text",
					"id": "R9GJOItC"
				}
			],
			"updated": 1685208704804,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 341,
			"versionNonce": 1716076221,
			"isDeleted": false,
			"id": "R9GJOItC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.09417724609375,
			"y": -119.98004150390625,
			"strokeColor": "#ffffff",
			"backgroundColor": "transparent",
			"width": 44.25994873046875,
			"height": 25,
			"seed": 413691763,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685208707403,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Host",
			"rawText": "Host",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "sCYXBRmiCXdVhrBiH-H7-",
			"originalText": "Host",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 207,
			"versionNonce": 617561277,
			"isDeleted": false,
			"id": "yasmdZ5j",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -314.05157470703125,
			"y": -168.5032958984375,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 127.17990112304688,
			"height": 25,
			"seed": 131752925,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685208723089,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "(32 - n) bits",
			"rawText": "(32 - n) bits",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "(32 - n) bits",
			"lineHeight": 1.25,
			"baseline": 17
		},
		{
			"type": "text",
			"version": 46,
			"versionNonce": 201636787,
			"isDeleted": false,
			"id": "TWIrKsQb",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -15.708587646484375,
			"y": -172.2484130859375,
			"strokeColor": "#ffffff",
			"backgroundColor": "#228be6",
			"width": 56.039947509765625,
			"height": 25,
			"seed": 233092349,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1685208711764,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "n bits",
			"rawText": "n bits",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "n bits",
			"lineHeight": 1.25,
			"baseline": 17
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#1e1e2e",
		"currentItemStrokeColor": "#ffffff",
		"currentItemBackgroundColor": "#228be6",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 475.4910125732422,
		"scrollY": 337.9312438964844,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%