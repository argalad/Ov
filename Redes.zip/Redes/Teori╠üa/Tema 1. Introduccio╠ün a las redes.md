#redes
```toc
```
---
# Definiciones

- **Redes**: interconexiones entre un conjunto de *dispositivos* (máquinas, portátiles, routers…) capaces de comunicarse (intercambiar información). Es la forma más sencilla de conectar dos o más dispositivos.

- **Redes [[Tema 1. Introducción a las redes#LAN|LAN]] (Local Area Network)**: redes de *carácter privado* que presentan cobertura limitada. Cada uno de los dispositivos que se encuentran conectados a la red están identificados mediante su dirección.

- **Redes [[Tema 1. Introducción a las redes#WAN|WAN]] (Wide Area Network)**: redes que emplean un área mucho más extensa, son de *uso público* y normalmente se encuentran gestionadas por empresas de comunicación.

- **[[Tema 1. Introducción a las redes#Internet|Internet]]**: conexión de varias LAN o WLAN unidas mediante routers (actúan de encaminadores y de reexpediciones, es decir, routing y forwarding de los paquetes).

- **[[Tema 1. Introducción a las redes#Arquitectura de protocolos|Arquitectura de Protocolos]]**: definen las reglas que ambos extremos deben seguir para comunicarse. Las reglas se dividen en tareas a diferentes niveles donde cada uno de los niveles emplea un determinado protocolo.

- **Distintas fases del encapsulado**: al mensaje que se tiene en la fase de aplicación se le une en la fase de transporte una cabecera, de modo que el conjunto pasa a denominarse *segmento* ([[Tema 5. La capa de transporte. Protocolos TCP y UDP#Protocolo TCP|TCP]]) o *datagrama de usuario* ([[Tema 5. La capa de transporte. Protocolos TCP y UDP#Protocolo UDP|UDP]]). En la etapa posterior, la de red, se añade una nueva cabecera y pasa a denominarse *paquete* o *datagrama IP.* Por último, en la fase de enlace se añade una nueva cabecera y queda definitivamente lo que denominamos *trama*, que luego pasamos a *bits*.

El problema de aumentar el número de redes es que requiere de una gran cantidad de cable y un gran número de puertos de E/S. La solución al problema será el uso de redes conmutadas.

---
# Tipos de Redes 
## LAN

- **LAN de difusión o Broadcast**: computadores interconectados mediante un medio de transmisión compartido. Cuando uno de los computadores quiere enviar información, se difunde a los demás a través del medio ya mencionado. Si dos medios desean transmitir a la vez se producirá una *colisión* (información inválida).
	Algunas de las topologías que podemos encontrar para sus conexiones son: un cable común (*bus*), un *hub* (repetidor en forma de “estrella” que pasa la información a todas las salidas o bien una LAN inalámbrica (*WLAN*), en la que encontramos un Punto de Acceso (*AP*) que actúa como un hub inalámbrico.

- **LAN conmutada o Switched**: computadores interconectados a través de conmutadores, que dirigen la información para que solo llegue al destinatario, de modo que se evitan las colisiones.
	La principal topología que presenta para poder conectar los dispositivos es un conmutador o switch.

## WAN

- **Punto a punto**: Conecta dos dispositivos mediante un *medio de transmisión*, como por ejemplo una conexión por módem convencional o ADSL.

- **De conmutación de circuitos**: Se establece una conexión entre dos extremos. Los switches no procesan información y actúan de un modo similar a las centralitas de las conexiones telefónicas.

- **De conmutación de paquetes**: La información se transmite en paquetes. Los switches procesan los paquetes, deciden cuál es la ruta más adecuada (*routing*) y en base a esta ruta se mueve el paquete al siguiente nodo hasta llegar al destino (*forwarding*).

	- **Redes de datagramas**: Los paquetes se tratan de forma independiente a la dirección de destino. Pueden seguir caminos distintos y llegar en un orden distinto al esperado (*redes IP*).
	- **Redes de circuitos virtuales**: Se establece una ruta previa para el envío de los paquetes y puede estar empleada para varias transmisiones (*redes ATM*).

---
# Internet

Internet se encuentra organizado de una forma jerárquica, de modo que los usuarios se conectan gracias a un proveedor de acceso a internet (*ISP*). Estos ISP se encuentran organizados de forma jerárquica, del siguiente modo:

- **ISP locales**: dan conexión a los *usuarios finales* y pueden ser conectados o bien a los ISP regionales o bien directamente a los backbones.

- **ISP regionales**: Conforman el *segundo nivel* de la jerarquía y se conectan a uno o a varios backbones.

- **Backbone ISP**: la columna vertebral de Internet. Se interconectan mediante las *NAP* (Network Access Points) o las *IXP* (Internet eXchange Points) o puntos neutros.

---
# Arquitectura de protocolos

Cada una de las *capas* tiene una serie de funciones definidas:

- **Servicios**: la capa K solo se comunica con la capa K – 1 mediante los servicios que ésta ofrece.

- **Protocolos**: las capas del mismo nivel emplean las mismas reglas. En la comunicación se establece una conexión lógica entre ambas capas.

- **Arquitectura de protocolos**: formada por las capas y el conjunto de servicios y de protocolos.

---
# Arquitectura TCP/IP

Se trata de una estructura jerárquica que se encuentra compuesta por *módulos*. Podemos encontrar las siguientes capas:

- **Capa de aplicaciones**: se realiza el *intercambio* entre los dos programas de extremo a extremo. Ejemplos: HTTPS, DNS.

- **Capa de transporte**: comunicación de extremo a extremo, en la que se *encapsulan* los *mensajes*. Tenemos el TCP (control de flujo, errores y congestión) y el UDP (más simple y no tiene conexión).

- **Capa de red**: gracias a ella se produce la *comunicación* entre los *hosts* y envía los paquetes. El protocolo IP define los *formatos*, las *direcciones* y el *encaminamiento*, pero no produce control de errores.

- **Capa de enlace de datos**: los *datagramas* se transmiten por el enlace y es encapsulado en un frame. No presentan protocolos en particular. Pueden detectar y corregir errores.

- **Capa física**: se envían los bits por el *enlace* (se codifican) y se envían de forma lógica mediante señales electromagnéticas.

---
# Encapsulado/Desencapsulado en TCP/IP

Para realizar el *encapsulado*, al mensaje se le añade una *cabecera* con información del protocolo. En la capa de transporte se añade información sobre los procesos de origen/destino. La capa de red añade información sobre los hosts de origen y destino y la capa de enlace incluye la dirección de enlace de los extremos. Es realizado por el *emisor*.

En cuando al *desencapsulado*, se produce cuando se recibe un mensaje y se envía a las capas superiores y los routers pueden reencapsular el mensaje. Es realizador por el *receptor*.

Los hosts de origen y de destino tienen transformaciones en las *cinco capas*. Los routers únicamente realizan transformaciones hasta la capa de *encaminamiento* (3) y los switches hasta la capa de *enlace de datos* (2).

Los protocolos/reglas que se emplean en cada una de las capas han de mantenerse en cada uno de los lados, de modo que se pueda permitir la comunicación entre ambos.

![[Capas.png]]

---
# Modelo OSI

Se desarrolló por ISO a finales de los 70 para la comunicación de red. Permite la comunicación entre dos medios. No es un protocolo sino un *modelo para el desarrollo de protocolos*, pero no tuvo éxito debido a la aparición del TCP/IP, la presencia de *capas* que no se encontraban definidas y un bajo rendimiento. La principal diferencia con el protocolo TCP/IP es que la capa de aplicación se encuentra dividida en aplicación, presentación y sesión.