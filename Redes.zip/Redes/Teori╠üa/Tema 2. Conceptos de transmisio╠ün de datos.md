#redes 
```toc
```
---
# Definiciones
- **Datos**: entidades de información que se transmiten bien sean *analógicas* (valores continuos en un intervalo) o *digitales* (toman valores discretos).

- **Señales**: codificaciones eléctricas de los datos a transmitir que hace posible la *propagación*. Las señales analógicas varían de forma continua en un rango de valores y las señales digitales son pulsos eléctricos discretos.

- **Elementos de señal (símbolos)**: cada uno de los distintos *estados* que puede tomar la señal para codificar los datos binarios.

- **Elementos de datos (bits)**: uno o varios están representados por cada *elemento de señal*. $R$ es la relación de bits por elemento de señal (se denomina bits por baudio). Para poder codificar estos $R$ bits necesitaremos $V = 2^R$ símbolos.
$$R = log_2V$$
- **Tasa de baudios** $(B)$: número de veces que puede cambiar el estado de la señal. Se mide en *baudios/segundo*.

- **Tasa de bits** ($c$): número de bits que se transmiten por unidad de tiempo. Se mide en *bits/segundo*.

- **Espectro en frecuencias**: conjunto de componentes en frecuencia que componen la *señal* (representación frecuencia – amplitud).

---
# ¿Cómo codificar datos mediante señales analógicas o digitales?

Introducimos variaciones en el estado de la señal -> En las señales digitales tendremos **niveles discretos** de voltajes y en las señales analógicas tendremos **niveles contínuos** distintas formas de onda.

En el caso de las transmisiones digitales, si tenemos más de 2 elementos de señal entonces realizamos diferentes niveles y en el caso de las transmisiones analógicas dividimos 360° entre los distintos elementos que tengamos (fases distintas).
Si denominamos $R$ al número de bits por baudio, $B$  a la tasa de baudios y $C$ a la tasa de bits o bits por segundo, entonces obtenemos la siguiente relación:
$$C=R\cdot B$$

---
# Propiedades de un canal de transmisión

## Ancho de banda

- **Absoluto**: es la *diferencia entre la frecuencia más alta y la más baja* contenidas en la señal. 
- **Efectivo**: es la parte del ancho de banda donde se concentra la mayor cantidad de energía. En un canal es el rango de frecuencias que puede transmitir para una distancia determinada sin atenuación.
$$H=f_s -f_i$$
## Atenuación

La energía de la señal decae con la distancia recorrida en el canal de transmisión.
$$\begin{align}
&Atenuación_{db} = 10\cdot log(P_R/P_T) \\\\
&P_R = \text{potencia señal recibida} \\
&P_T = \text{potencia señal transmitida}\\\\
&P_{R}= P_{T}*10^\frac{Atenuación(dB)}{10}\\
&P_{T}=\frac{P_{R}}{10^{\frac{Atenuación}{10}}}
\end{align}$$
## Relación señal/ruido (SNR)

$$SNR_{db} = 10\cdot log(S/N)$$

## Teorema de Nyquist (Capacidad de un canal ideal)
$$C_N = B_{max}\cdot R = 2\cdot H\cdot R$$
## Teorema de Shanon (Capacidad de un canal real)
$$C_S = H\cdot log_2(1+S/N)$$

---
# Multiplexación

La **multiplexación** es una temática que permite la transmisión simultánea de múltiples señales a través de un mismo medio de transmisión.
![[multiplexer|800]]
Hay dos tipos:
- **FDM**: multiplexación por división de frecuencia. Se aplica cuando el ancho de banda del enlace es superior al de las señales transmitidas.
![[fdm|800]]
- **TDM**: multiplexación por división del tiempo. Procesamiento digital que permite compartir el ancho de banda entre diferentes conexiones.
![[tdm|800]]
Consiste en repartir el tiempo de transmisión entre las distintas fuentes de datos. El tiempo de transmisión se divide en intervalos idénticos o ranuras temporales. Cada dispositivo de transmisión tiene asignado un intervalo o ranura para transmitir.
- TDM síncrono.
- TDM estadístico.

---
# Medios de transmisión

## Guiados

- **Par trenzado**: dos hilos de cobre aislados de forma helicoidal.
	-  **UTP** (no apantallado)
		- **Cat 3**: calidad telefónica. Frecuencias hasta 16 MHz y se emplea en telefonía y redes Ethernet.
		- **Cat 5**: calidad de datos. Frecuencias hasta 100 MHz y se emplea en Fast Ethernet. 
	- **STP** (apantallado)
- **Cable coaxial**: núcleo central de cobre rodeado de otro conector. Se emplea en señales de televisión, telefonía larga distancia y redes LAN.
- **Fibra óptica**: núcleo de plástico que transmite señales en forma de luz. Para conexiones de larga distancia se pueden agrupar en mangueras de varias decenas de fibras. Su funcionamiento se basa en la **Ley de Snell**, que explica los comportamientos de la luz en función del ángulo y del medio al que pasan. 
	- **Multimodo**: la luz se mueve en múltiples direcciones.
		- **Índice escalonado**: mantiene el índice de refracción constante.
		![[fibra.multimodo]]
		- **Índice gradual**: el índice de refracción varía a lo largo del tubo.
		![[fibra.multimodo2]]
	- **Monomodo**: la luz pasa en línea recta a través de todo el conducto. Produce menos pérdidas pero es mucho más cara.
		![[fibra.monomodo]]
	Tiene un ancho de banda muy superior a los medios de cobre, es inmune a interferencias electromagnéticas y delgada y ligera. Por el contrario, es mucho más cara y su manipulación es muy compleja.

## No Guiados

- Ondas de radiofrecuencia (3 kHz - 1 GHz)
- Microondas (1 GHz - 300 GHz)
- Infrarrojos (300 GHz - 400 THz)