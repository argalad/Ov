#redes #hdlc #lan #ieee802 #llc #csma #wifi 
```toc
```
---
# Definiciones

**LLC**: protocolo de enlace de las **redes de área local**. Tiene dos **servicios**:
- **Orientados a conexión**: primero establecen conexión con **tramas sin numerar**, después se transmiten los datos (tramas de **tipo I** y tramas supervisoras **tipo RR** y después nos desconectaremos mediantes tramas **DISC**).
- **Sin conexión**: sólo transmite datos con **tramas UI**.

---
# Capa de enlace

La capa de enlace libra de errores a un enlace físico. Cuando dos estaciones o más acceden de forma simultánea al medio de transmisión, se produce una **colisión**. Se usa **MAC** para evitar o resolver.

## Funciones

- **Ofrecer servicios** a la capa superior.
- **Entramado**: construir tramas según el formato de protocolo y delimitar el inicio y el fina para facilitar el trabajo del receptor.
- **Gestión de errores**: detección y recuperación.
- **Control de flujo**: para evitar la saturación.

## Tipos de enlace

- Punto a punto ![[p2p|190]]
- Multipunto ![[multipunto|250]]
## Modos de transmisión

- **Símplex** ![[símplex|50]]
- **Half-dúplex** ![[half-dúplex|120]]
- **Full-dúplex** ![[full-dúplex|50]]
## Detección de errores

- **Checksum**: basado en la **paridad** de los bits.
- **CRC**: códigos de reduncancia cíclica. El emisor divide la secuencia de bits a transmitir entre una secuencia binaria fija, de modo que se obtiene un resto que es agregado a la trama. Este resto es posteriormente comparado en el receptor, que comprueba los restos tras volver a hacer la división.
![[arq|600]]
## Servicios

- **Orientados a conexión y fiables** 
	- Los protocolos tienen tres fases
		1. Establecimiento de conexión.
		2. Transmisión de datos.
		3. Finalización de la conexión.
	- Garantizan la entrega fiable de tramas
		- Se detectan errores en la transmisión y se descartan tramas erróneas.
		- Tramas erróneas o perdidas se retransmiten.
		- Tramas duplicadas se descartan.
		- Tramas se entregan a la capa superior ordenadas y sin errores.
		- Control de flujo entre emisor y receptor.
	- Control de errores
		- Técnicas de detección.
		- Numeración de tramas.
		- Confirmación de tramas recibidas correctamente.
		- Retransmisión de tramas no confirmadas.
- **Servicios sin conexión**
	- Sin fases de establecimiento de conexión.
	- Servicio no fiable: sin garantía de entrega fiable de tramas.
	- Servicio fiable: confirmación de trama a trama sin número de secuencia.

## Protocolo HDLC (High-level Data Link Control)

Ofrece servicios con y sin conexión. 

## Modos de funcionamiento

- **NRM**: modo normal de respuesta (enlaces multipunto)
	- Comunicación half-dúplex maestro-esclavo.
	- Estaciones esclavas sólo transmiten cuando maestras lo permiten.
- **ABM**: modo equilibrado asíncrono (punto a punto)
	- Comunicación full-dúplex computador-computador.
	- Cualquier estación puede transmitir en cualquier momento.

### Tipos de tramas

![[tramas-hdlc|700]]

- **Tramas de Información**: transportan datos de la capa superior (conexión y fiable)
	- Números de secuencia, N(S)
		- Control de flujo y errores.
		- 3 o 7 bits.
	- Números de confirmación, N(R)
		- Utilizado para enviar confirmaciones superpuestas.
		- El número de confirmación contiene el identificador de la siguiente trama que se espera recibir.
	- Bit P/F (Pregunta/Final): utilizado en modo NRM y cuando no se recibe la confirmación de una trama y expira el temporizador.
- **Tramas supervisoras**
	- Tipo RR (Receptor Ready, S=00): trama de confirmación (similar ACK).
	- Tipo REJ (Reject, S=01): trama de confirmación negativa (similar NAK)
		- Se indica el número de confirmación N(R) de la trama esperada.
		- Emisor retransmite únicamente la trama especificada en el campo N(R).
	- Tipo RNR (Receptor Not Ready, S=10)
		- Indica al emisor la suspensión temporal del envío de tramas.
		- Confirma las tramas de información anteriores a la N(R), sin incluir esta.
		- Para recibir tramas de nuevo, envía RR.
![[tipos-tramas|700]]

## Protocolo PPP (Punto a Punto)

- Servicios de enlace sin conexión.
- Encapsula tráfico IP (ISP, ADSL).
- Funciones
	- **Control de enlace**: establecimiento y configuración de la conexión, negociación de opciones de conexión (tam. min. de trama, protocolo de autenticación, etc...), LCP.
	- **Autenticación del usuario**: protocolo PAP y CHAP.
	- **Gestión del protocolo de red**: permite negociar dirección IP del cliente, mediante protocolo IPCP (IP Control Protocol).

---
# Redes de Área Local (LAN)

## Topologías

- **Canal compartido (o de difusión)** ⟶ hay colisiones

	- Bus ![[bus]]
	- Anillo ![[anillo]]
	- Estrella ![[hub|450]]
- **Conmutadas** ⟶ sin colisiones
	- Estrella ![[switch|450]]
## Dispositivos 

- **Hub**: repetidor que funciona a nivel físico (I) y retransmite la información por todas sus puertas.
- **Switch**: funciona a nivel de enlace (II), entiende el formato de la trama y retransmite la información por la salida adecuada.
- **Bridge**: interconecta LANs de distinta tecnología (Ethernet y WiFi) y convierte los formatos de trama de una red a otra.
- **AP (Access Point)**: similar al hub pero con funciones adicionales, puede modificar algunos cambios de la cabecera de la trama (II).

## Protocolo IEEE 802

- Divide la capa de enlace en dos niveles
	- **LLC (Control de Enlnace Lógico)**
		- Tiene una interfaz con las capas superiores.
		- Tiene control de errores y flujo si las capas superiores lo demandan.
	- **MAC (Control de Acceso al Medio)**
		- Ensamblado y desensamblado de tramas con campos de dirección.
		![[tramas-mac|600]]
## Protocolo LLC (Logical Link Control)

Es el protocolo de enlace de las redes de área local, descrito en el estándar IEEE 802.2. Ofrece dos tipos de servicio:
- **Orientados a conexión**
	- Establecimiento de conexión
		- Tramas sin numerar: tipo SABM/SABME, UA.
	- Transmisión de datos
		- Tramas de datos: tipo I.
		- Tramas supervisoras: tipo RR, REJ, RNR (no se usan SREJ).
	- Desconexión
		- Tramas sin numerar: tipo DISC, UA.
- **Sin conexión**
	- Sólo transmisión de datos
		- Tramas sin numerar: tipo UI.

>[!note] Nota
>IP sobre LLC utiliza únicamente servicios sin conexión.

### Formato de la trama LLC sin conexión

![[tramas-llc|900]]

- **DSAP** y **SSAP**: puntos de acceso al servicio (SAP = Service Access Point) destino y fuente. En el caso de aplicaciones TCP/IP ⟶ DSAP = 0xAA y SSAP = 0xAA.
- **ORG**: código de organización, en el caso de aplicaciones TCP/IP ⟶ ORG = 0X000000.
- **Tipo**: identifica al protocolo de la caspa superior al que pertenecen los datos. Ejemplos:
	- IP ⟶ Tipo = 2048 (0x0800)
	- ARP ⟶ Tipo = 2054 (0x0806)
- **Control**: tiene el mismo significado que en HDLC. Especifica el tipo de trama e información adicional (número de secuencia, número de confirmación, bit P/, etc...).

## Redes LAN Ethernet

### Topologías Ethernet

- **Topología en bus**
	- La información se difunde a toda la red.
	- Existencia de colisiones (necesario CSMA/CD).
	- Transmisión **half-dúplex**.
	- Privacidad baja.
	![[bus-ethernet]]
- **Topología en estrella**
	- **Hub**
		- Dispositivo repetidor.
		- Retransmite la información por todas las salidas.
		- Existencia de colisiones (necesario CSMA/CD).
		- Transmisión **half-dúplex**.
		- Privacidad baja.
		![[hub-ethernet]]
	- **Switch** 
		- Dispositivo conmutador.
		- Retransmite la información únicamente por la salida adecuada.
		- Libre de colisiones.
		- Transmisión **full-dúplex**.
		- Privacidad elevada.
		![[switch-ethernet]]

### Protocolo MAC de Ethernet

Ethernet utiliza el protocolo de acceso al medio CSMA/CD (Carrier Sense Multiple Access / Collision Detection), que permite anticipar la detección de colisiones y la retransmisión de tramas.

#### Protocolo CSMA
![[csma|500]]

#### Protocolo CSMA/CD
![[csma-cd|500]]

## Detección de colisiones

- **Tiempo máximo de detección de colisión**
	$$\begin{align}
	&\tau = 2\cdot T_p \\\\
	&\tau = \text{ranura temporal} \\
	&T_p = \text{retardo máximo de propagación de señal}
	\end{align}$$
	
	![[deteccion-colision|700]]
- **Tamaño de trama mínima en Ethernet**
	El protocolo CSMA/CD limita el tamaño de la trama mínima: el tiempo de transmisión de cualquier trama debe ser mayor o igual que el tiempo máximo de detección de una colisión o ranura tempora, es decir:
	$$T_x \ge \tau$$
	Por tanto:
	$$T_x = \frac{\text{Tamaño de la trama (bits)}}{\text{Velocidad de transmisión (bps)}} \ge \tau$$
	Valores típicos en Ethernet:
	- **Retardo máximo**: $T_p = 25,6 \mu s \longrightarrow \tau = 2T_p = 512\mu s$ 
	- **Velocidad de transmisión**: $V=10 Mbps$
	- **Tamaño de la trama** 
		$$\begin{align}&\ge \tau\cdot \text{Velocidad de transmisión}=51,2\cdot 10^{-6}s\cdot 10\cdot 10^6 bits/s = 512bits \\
		&\Rightarrow \text{Tamaño trama mínima Ethernet = 512bits = 64bytes}\end{align}$$
### Formato de la trama Ethernet

![[tramas-ethernet|700]]

- **Campos de sincronización y delimitación**
	- ==Preámbulo== (7  bytes)
		- Patrón de bits `10101010` repetido 7 veces.
		- Se utiliza para permitir que el receptor se sincronice con el emisor.
	- ==SFD== (Start Frame Delimiter, 1 byte)
		- Patrón `10101011`.
		- Se utiliza para delimitar el inicio de la trama Ethernet.
- **Campos de la trama Ethernet**
	- ==Direcciones MAC origen y destino== (6 bytes)
	- ==Campo Longitud/Tipo== (2 bytes)
		- En el estándar 802.3: campo Longitud (valor ≤ 1500). Es la longitud del campo Datos.
		- En Ethernet II: campo Tipo (valor ＜ 1500). Indica el protocolo de la capa superior al que van dirigidos los datos.
			- IP → 2048 (0x0800).
			- ARP → 2054 (0x0806).
	- ==Datos== (0 - 1500 bytes)
	- ==Relleno== (0 - 46 bytes): para el caso de tramas menores de 64 bytes (＜ 46 bytes de datos).
	- ==CRC== (4 bytes): código de redundancia cíclica para detección de errores de transmisión.

### Ethernet II vs IEEE 802.3

- **Arquitectura TCP/IP sobre red Ethernet**
	IP es un protocolo de red sin conexión (no fiable), no utiliza los mecanismos de control de errores y flujo de la capa de enlace. Sólo utiliza el servicio sin conexión de LLC y tramas de información sin numerar (UI).
	El formato de las tramas LLC tipo UI (Campo Control = 03)
	![[tramas-llc]]
	Los campos DSAP, SSAP, Control y ORG tienen valores fijos. El único dato relevante en la cabecera de la trama LLC es el campo ==Tipo==, que identifica al protocolo de la capa superior al que pertenecen los datos, en el caso de IP → tipo = 0x0800.
	
	En la arquitectura de TCP/IP sobre Ethernet se puede eliminar el protocolo LLC, puesto que IP se puede comunicar directamente con Ethernet (versión II).
	El campo Tipo se codifica en la trama Ethernet en lugar del campo Longitud. Para distinguir tramas Ethernet II de tramas 802.3 se utiliza el valor del campo Tipo/Longitud.
	- Tramas 802.3 → campo Longitud ≤ 1500 (decimal).
	- Tramas Ethernet II → campo Tipo ﹥1500 (decimal).

- **Encapsulado de IP sobre LLC (802.2) y Ethernet (802.3)**
	![[encapsulado-ip-llc-ethernet|700]]
- **Encapsulado de IP sobre Ethernet II**
	![[encapsulado-ip-ethernet|700]]
	>[!note] 
	> En la arquitectura de TCP/IP sobre la red WiFi (802.11) siempre se utiliza LLC.
	
### Direcciones MAC Ethernet

Identifican al emisor y destinatario(s) de una trama en el ámbito de la red local.
`Dir. MAC = Dir. Ethernet = Dir. física = Dir. hardware`

- **Dirección MAC destino**
	- ==Unicast== (Dirección MAC individual): hace referencia a una única estación. Normalmente esta dirección está grabada en la tarjeta de red. Ejemplo: `00:1C:7E:47:75:1A`.
	- ==Multicast== (Dirección MAC de grupo): hace referencia a un grupo de máquinas en la red local. Ejemplo: `01:00:5E:1A:0A:05`.
	- ==Broadcast== (Dirección MAC de difusión): hace referencia a todas las estaciones de la red local. Por defecto es: `FF:FF:FF:FF:FF:FF`.
- **Dirección MAC origen**: sólo puede ser de tipo Unicast.
- **Formato de la dirección MAC**
	![[formato-mac|500]]
	- **Bits especiales del primer byte**
		- ==Bit unicast/multicast== (b8)
			- 0 → Dirección unicast (`00:1C:7E:47:75:1B`).
			- 1 → Dirección multicast (`01:00:5E:1A:0A:05`).
		- ==Bit global/local== (b7)
			- 0 → Dirección MAC global asignada por el fabricante (grabada en la tarjeta).
			- 1 → Dirección MAC local configurada por el administrador de la red (si existe, prevalece sobre la global).

### Funcionamiento de los Switches

- **Switch de almacenamiento y reenvío (store-and-forward)**: el switch acepta la trama, la almacena temporalmente y la reenvía hacia la salida adecuada.
	>[!success] Ventajas
	> Puede realizar comprobación de errores y descartar las tramas erróneas; puede interconectar dispositivos de diferente velocidad.
	
	>[!fail] Desventajas
	> Introduce retardos adicionales al tener que almacenar la trama completa.
- **Switch de truncamiento (cut-through)**: el switch lee la dirección MAC de destino (que aparece en los primeros bits de la trama) e inmediatamente comienza a reenviar la trama por la salida adecuada.
	>[!success] Ventajas
	> Menores retardos ya que no almacena la trama.
	
	>[!failure] Desventajas
	> Puede enviar tramas erróneas y mayor dificultad para interconectar dispositivos de distintas velocidades.
#### Auto-aprendizaje

Cada switch tiene una **tabla de conmutación** (switching table) que almacena las direcciones MAC asociadas a cada puerto. Cada entrada de la tabla contiene:
- Dirección MAC.
- No. de puerto.
- Marca de tiempo.
Las entradas antiguas (no usadas) son descartadas (TTL ~ 60s)

La tabla de conmutación se aprende de forma automática; el auto-aprendizaje se realiza a partir de las tramas recibidas por el switch. Cuando el switch recibe una trama con dirección origen MAC-X a través del puerto P, el switch añade a su tabla que la dirección MAC-X está asociada al puerto P.
Durante el proceso de aprendizaje, si el switch recibe una trama dirigida a la dirección MAC-Y y todavía no conoce el puerto asociado a esa dirección, entonces envía la trama por todos los puertos (broadcast), excepto el de procedencia.
![[auto-aprendizaje|700]]

El inconveniente es que esto puede dar lugar al llamado **problema de los bucles**.![[problema-bucles|700]]
La solución propuesta por el IEEE 802.1 es usar el protocolo de árbol de expansión (STP, Spanning Tree Protocol) para crear una topología sin bucles:
- Cada LAN podrá ser alcanzada desde cualquier otra LAN solo por un camino.
- El sistema tendrá una topología física que no cambia pero recubierta por una topología lógica que hace efectivas las conexiones.

#### Protocolo del árbol de expansión

El árbol de expansión es un grafo en el que no hay bucles.
- LAN → nodos
- Switches → arcos
Cada switch tiene asignado un identificador y el administrador asigna un coste a los puertos de los switches. El algoritmo busca el camino que minimice el número de saltos o el retardo o que maximice el ancho de banda.
Los switches intercambian mensajes para determinar qué puertos son:
- **Puertos de reenvío** (forman parte del árbol de expansión): reenvían las tramas que reciben.
- **Puertos de bloqueo** (no pertenecen al árbol): bloquean las tramas recibidas por el switch.
Si hay un cambio en la topología, los switches recalculan el árbol.

#### Interconexión de redes Ethernet

- **Dominio de colisión**: es un conjunto de máquinas de una red que pueden producir colisiones entre sí. Cada vez que se produzca una colisión dentro de un dominio de colisión, afectará a todos los equipos conectados a ese dominio pero no a los equipos pertenecientes a otros dominios de colisión. Ejemplos:
	- Todas las máquinas conectadas a un segmento 10BASE2 forman un dominio de colisión.
	- Todas las máquinas conectadas a un hub 10BASE-T forman un dominio de colisión.
	- Cada rama de un switch 100BASE-TX constituye un dominio de colisiones distintos (las colisiones no se retransmiten por los puertos del switch).
- **Interconexión de varios segmentos 10BASE2 o 10BASE5**: se pueden unir varios segmentos mediante repetidores; esto permite ampliar el alcance de la red (limitada a 185 o 500m). Un repetidor es un dispositivo de nivel físico.
	Tiene limitaciones en el uso de repetidores: no pueden existir más de 4 repetidores en el camino entre dos estaciones y la red no puede contener lazos cerrados.
	Además, todos los segmentos unidos mediante repetidores forman un único dominio de colisión.
	![[dominio-colisión|700]]
- **Interconexión de varios hubs 10BASE-T**: se pueden conectar varios hubs para ampliar el tamaño de la red. La longitud máxima del cable es de 100m. El no. máximo de hubs que pueden existir en el camino entre dos estaciones es 4 y no pueden existir caminos que formen lazos cerrados.
	![[dominio-colision-2|700]]
- **Interconexión de varios hubs 100BASE-TX**: se pueden conectar un máximo de 2 hubs 100BASE-TX (Clase II) y la longitud máxima de cada cable es de 5m.
	![[dominio-colisión-3|700]]
- **Interconexión de redes Ethernet mediante switches**: se pueden conectar varios switches para aumentar el tamaño de la red. Longitud máxima del cable: 100m. No existen limitaciones en el no. de switches.
	![[dominio-colisión-4|700]]
## Redes LAN inalámbricas (WiFi)

WiFi (Wireless Fidelity) es una tecnología WLAN especificada por el estándar IEEE 802.11, que define lo siguiente:
- Tipos de redes WiFi soportados
	- Con infraestructura.
	- Sin infraestructura (ad-hoc).
- Conjuntos de servicios permitidos
	- Conjunto de servicios básico (BSS, Basic Service Set).
	- Conjunto de servicios extendido (ESS, Extended Service Set).
- Protocolos de control de acceso al medio
	- Función de coordinación distribuida (DCF), basada en CSMA/CD.
	- Función de coordinación centralizada (PCF), basada en sondeo.
- Implementaciones físicas soportadas
	- 802.11a
	- 802.11b
	- 802.11g
	- 802.11n
- El formato de la trama 

### Arquitectura de la red WiFi (802.11)
![[arquitectura-red-wifi|700]]

## Tipos de redes WiFi

- **Red WiFi con infraestructura**
	- Las estaciones inalámbricas se comunican a través de un punto de acceso inalámbrico (AP, Access Point)
		- Cada AP tiene un identificador (dirección MAC).
		- La conexión de un estación a un AP se denomina asociación.
	- El AP funciona como un hub inalámbrico
		- La estación emisora envía su trama de datos al AP.
		- El AP retransmite la trama de datos a la estación destinataria.
	![[wifi-con-infraestr.|500]]
- **Red WiFi sin infraestructura (ad-hoc)**
	- Las estaciones inalámbricas se comunican directamente entre sí, sin necesidad de un AP.
	![[wifi-sin-infraestr.|400]]
### Conjunto de servicios de redes WiFi

- **Conjunto básico de servicios (BSS, Basic Service Set)**: un BSS es el bloque constitutivo básico de una WLAN. Está formado por un conjunto de estaciones móviles y opcionalmente, un AP.
     Un BSS puede ser una red WLAN con o sin infraestructura:
     - **Sin infraestructura (IBSS, Independent BSS)**: es una red aislada que no puede comunicarse con otras.
     - **Con infraestructura**: se puede comunicar con otras redes a través del AP.
     Cada BSS se identifica mediante un **BSSID**:
     - En un BSS con AP, el BSSID es la dirección MAC del AP.
     - En un IBSS, el BSSID se genera aleatoriamente.
- **Conjunto extendido de servicios (ESS, Extended Service Set)**: un ESS está compuesto por varios BSS unidos a través de sus respectivos APs mediante un **sistema de distribución (DS, Distribution System)**. La red de distribución suele ser una red cableada y puede usar cualquier tipo de tecnología (i.e. Ethernet).
     Un ESS se identifica mediante un **ESSID**, una cadena ASCII de 32 caracteres que también se denomina "nombre de la red".
     ![[ess|700]]
### Control de acceso al medio en redes WiFi

- **Problema de las redes WLAN**: no es posible utilizar CSMA/CD debido a la dificultad de detectar colisiones. La tarjeta de red WiFi no puede transmitir y recibir simultáneamente, por tanto no es posible detectar colisiones. Además existe el problema de la **estación oculta**.
- **Técnicas MAC en redes WLAN 802.11**
	- **Función de coordinación distribuida (DCF, Distributed Coordination Function)**: el control de acceso al medio se lleva a cabo de forma distribuida entre todas las estciones de la red.
		- Es el protocolo más utilizado en redes WiFi.
		- Puede utilizarse en entornos con o sin infraestructura.
		- Se basa en el protocolo CSMA/CA (CSMA with Collision Avoidance).
	- **Función de coordinación centralizada (PCF, Point Coordination Function)**: el control de acceso al medio se lleva a cabo de forma centralizada mediante el AP
		- Sólo se puede utilizar en redes con infraestructura.
		- Es un protocolo basado en sondeo libre de colisiones.
- **Parámetros temporales usados en DCF y PCF**: el funcionamiento de DCF y PCF se basa en tres parámetros temporales.
	- **SIFS (Short Inter-Frame Spacing)**: espaciado inter-trama corto.
	- **PIFS (PCF Inter-Frame Spacing)**: espaciado inter-trama PCF o intermedio.
	- **DIFS (DCF Inter-Frame Spacing):** espaciado inter-trama DCF o largo.
	$$\text{SIFS} \lt \text{PIFS} \lt \text{DIFS}$$
	
| **Función de coordinación** | **Parámetros temporales** |
| --------------------------- | ------------------------- |
| DCF                         | SIFS <br> DIFS |
| PCF                         | SIFS <br> PIFS |

- **Función de coordinación distribuida**
	![[funcion-coord-distr|700]]
	
	 - **Confirmación de trama recibidas**
	![[conf-trama-recibida|700]]
	- **El problema de la estación oculta**
		- B y C no se ven entre sí. B está transmitiendo a A.
		- C quiere transmitir a A y detecta el canal libre pues no recibe la señal de B.
		- C transmite a A y se produce una colisión.
	![[problema-estación-oculta|700]]
	- **Extensión RTS/CTS**: tramas de control para eliminar el problema de la estación oculta.
		- *RTS (Request To Send)*
		- *CTS (Clear To Send)*
		  ![[rts-cts|500]]
	- **Vector de reserva de red (NAV, Network Allocation Vector)**
		- Cuando una estación recibe permiso para enviar (mediante RTS/CTS) el resto de estaciones no deben intentar acceder al medio hasta que finalice la transmisión (hasta la recepción del ACK final).
			- La trama RTS contiene un parámetro, denominado NAV, que indica el tiempo que la estación solicitante ocupará el canal.
			- Durante ese tiempo el resto de estaciones permanecen inactivas.
			  ![[nav|700]]
- **Formato de la trama 802.11**
	- Tipos de tramas 802.11
		- Tramas de datos.
		- Tramas de control (ACK o RTS/CTS).
		- Tramas de gestión (solicitud asociación AP).
	- Formato
	  ![[trama-802.11|700]]
		- *Campo FC* (2 bytes)
			- Versión del protocolo.
			- Tipo de la trama:
				- 10 datos.
				- 01 control.
				- 00 gestión.
			- Subtipo de trama:
				- 1011 RTS.
				- 1100 CTS.
				- 1001 ACK.
			- A DS (A un sistema de distribución).
			- De DS (De un sistema de distribución).
			- Más fragmentos (1).
			- Reintento.
			- Gestión de energía (1 ahorro de energía).
			- Más datos (1).
			- Protección (WEP, WPA, WPA2).
			- Orden.
		- *Campo D / Duración* (2 bytes) ⟶ Tiempo en microsegundos que va a tardar en enviarse la trama.
		- *Campo de Dirección* (4, 6 bytes cada uno).
		- *Control de secuencia* (2 bytes) ⟶ Identificamos los fragmentos dentro de la secuencia de la trama (si perdemos mensaje por las colisiones, tendremos que reconstruir el mensaje original para saber qué falta).
		- *Campos de datos* (0 - 2312 bytes) ⟶ Tiene un mínimo para poder detectar las colisiones como en Ethernet.
		- *Campo FCS* (8 bytes) ⟶ Para comprobar las tramas (CRC).
	- **Significado de las direcciones MAC 802.11**

| **A DS** | **De DS** | **Dirección 1** | **Dirección 2** | **Dirección 3** | **Dirección 4** |
| :--------: | :---------: | :---------------: | :---------------: | :---------------: | :---------------: |
| 0        | 0         | Destino         | Origen          | ID de BSS       | No usado        |
| 0        | 1         | Destino         | AP emisor       | Origen          | No usado        |
| 1        | 0         | AP receptor     | Origen          | Destino         | No usado        |
| 1        | 1         | AP receptor     | AP emisor       | Destino         | Origen          | 
‏‎ ‎
		- **Casos**
			- Caso 00: la trama va de una estación origen a otra destino dentro del mismo BSS sin pasar por un AP (red ad-hoc).
			- Caso 01: la trama procede de un AP y va dirigida a una estación.
			- Caso 10: la trama procede de una estación y va dirigida a un AP
			- Caso 11: la trama va de un AP a otro AP a través de un sistema de distribución inalámbrico.
			  ![[casos-mac-wifi.png]]