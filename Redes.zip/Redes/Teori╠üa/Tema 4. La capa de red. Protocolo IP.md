#redes #tcp #ip #arp #cidr
```toc
```
---
# Repaso de conceptos
## Arquitecturas TCP/IP
![[arquitecturas_tcp-ip|700]]
## Principales dispositivos de red
- **Hubs o repetidores**: capa física (1). Retransmiten lo que les llega por una entrada al resto de salidas. Conecta segmentos de red del mismo tipo.
- **Switches**: capa de enlace (2). Reenvían la trama por la salida adecuada. Pueden almacenarla y detectar errores. Pueden interconectar estaciones y redes del mismo tipo.
- **Routers**: capa de red (3). Pueden interconectar redes de distinto tipo. Convierten formatos y encaminan.

---
# Protocolo IP: formato del datagrama y fragmentación
>[!tldr] Protocolo IP
> Es un conjunto de reglas y estándares que gobiernan la forma en que los datos se transmiten y reciben a través de redes informáticas, incluida la Internet. IP es la base de la comunicación en línea y permite que los dispositivos, como computadoras y teléfonos móviles, se conecten entre sí y compartan información.
> 
> Es un servicio que no está orientado a conexión (no es fiable), y entre sus principales funciones se encuentran:
> - Direccionamiento.
> - Fragmentación y reensamblaje de paquetes.
> - Encaminamiento de los datagramas.

## Formato del datagrama
![[datagrama-ip|700]]
- **Version** (4 bits): Indica la versión del protocolo IP, que es 4 para IPv4.
- **Header Length** (IHL - 4 bits): Especifica la longitud del encabezado IP en palabras de 32 bits.
- **Type of Service** (ToS - 8 bits): Define la calidad de servicio y prioridad del datagrama:
	- 1000 ⟶ retardo mínimo.
	- 0100 ⟶ rendimiento máximo.
	- 0010 ⟶ fiabilidad máxima.
	- 0001 ⟶ coste mínimo.
	- 0000 ⟶ servicio normal.
- **Total Length** (16 bits): Especifica la longitud total del datagrama, incluidos el encabezado y los datos.
- **Identification** (16 bits): Un número único asignado a cada datagrama para ayudar en el ensamblaje de fragmentos.
- **Flags** (3 bits): Contiene información sobre fragmentación, como "No Fragment" y "More Fragments".
- **Fragment Offset** (13 bits): Especifica la posición del fragmento en relación con el datagrama original.
- **Time to Live** (TTL - 8 bits): Limita la vida útil del datagrama en la red, decrementándose en cada salto.
- **Protocol** (8 bits): Identifica el protocolo de nivel superior (como TCP, UDP) utilizado en el segmento de datos.
- **Checksum** (16 bits): Es una suma de comprobación para garantizar la integridad del encabezado IP.
- **Source IP Address** (32 bits): Es la dirección IP del dispositivo que envía el datagrama.
- **Destination IP Address** (32 bits): Es la dirección IP del dispositivo destinatario del datagrama.
- **Options** (variable): Contiene opciones adicionales:
	- **Record Route**: proporciona un medio para registrar la ruta exacta que ha seguido el datagrama (dir. routers).
	- **Strict Source Routing**: proporciona un medio para que el emisor del paquete pueda especificar la ruta que debe seguir el datagrama.
	- **Internet Timestamp**: proporciona un medio para registrar los instantes temporales en los que el paquete ha pasado por cada router y sus direcciones.
- **Data** (variable): Contiene los datos del protocolo de nivel superior (como TCP, UDP).

---
# Protocolo IP: direcciones y máscaras
## Direcciones 
Constan de 32 bits (4 bytes). Se utiliza la notación de punto:
`128.2.7.9 = 1000 0000 . 0000 0010 . 0000 0111 . 0000 1001`
- **Unicast**: un único host.
- **Multicast**: un grupo de hosts.
- **Broadcast**: todos los hosts dentro de mi red local.

> [!info] Administración y registro de direcciones
 **Regional Internet Registries (RIR)**: la parte que identifica a la red es fija para cada red y es necesario solicitarla a una de las entidades regionales de registro de Internet.

![[dir-ipv4|700]]
### Direcciones basadas en clase
- **Clase A**
	- 1 bit para la clase: $0$
	- 8 bits para la red = $2^{8}=128$ redes.
	- 24 bits para direcciones = $2^{24}=16.777.216$ direcciones.
- **Clase B**
	- 2 bits para la clase: $10$
	- 14 bits para la red = $2^{14}=16.384$ redes.
	- 16 bits para direcciones = $2^{14}=65.536$ direcciones.
- **Clase C**
	- 3 bits para la clase: $110$
	- 21 bits para la red = $2^{21}=2.097.152$ redes.
	- 8 bits para direcciones = $2^{8}=256$ direcciones.
- **Clase D**
	- 4 bits para la clase: $1110$
	- 28 bits para direcciones.
- **Clase E**
	- 4 bits para la clase: $1111$
	- 28 bits para direcciones.
	- Experimental.
### Direcciones sin clase
Debido a ciertos problemas, como que no tengamos los suficientes hosts para cubrir la red, aparecen las redes sin clase, en las que el identificador de la red tendrá un número variable de hosts, que en todo caso vendrá en función de los host que vamos a necesitar (nos ajustamos a nuestras necesidades).
![[dir-ipv4 1|700]]
### Direcciones especiales
- **Direcciones reservadas para redes privadas**: existe un conjunto de direcciones reservadas para uso privado que no son válidas para su uso en internet. Sus rangos son los siguientes:
	- **Clase A**: 1 red privada ⟶ `10.0.0.0－10.255.255.255`
	- **Clase B**: 16 redes privadas ⟶ `172.16.0.0－172.31.255.255`
	- **Clase C**: 256 redes privadas ⟶ `192.168.0.0－192.168.255.255`
- **Direcciones de loopback**: direcciones de bucle interno. Casi todas las máquinas tienen como dirección de loopback la `127.0.0.1`
- **Direcciones broadcast**: se utilizan para enviar un paquete a todas las máquinas de la red local. Su formato es poner todos los bits del identificador de host a 1.
- **Direcciones de red**: se usan para representar una red completa en las tablas de encaminamiento. Su formato es poner todos los bits de identificador de host a 0.

>[!tldr] Network Address Translation (NAT)
>Consiste en dar una IP pública al router, de modo que el router va a esconder toda la información de los dispositivos que se conectan a él. Por ello las redes privadas son escondidas por el propio router. Cuando enviamos paquetes, llevarán la IP pública del router.

## Máscaras de red
La **máscara de red** indica:
- Qué parte de la dirección IP identifican a la *red* (bits de máscara a 1)
- Qué parte de la dirección IP identifican al *host* dentro de la red (bits de máscara a 0).
>[!example] Ejemplo
>- Dirección de clase: `221.98.22.2`
>- Máscara: `255.255.255.0`
>
>**Red** - *Host*
>IP 
>**1101 1101 . 0110 0010 . 0001 0110** . *0000 0010*
>Máscara
>**1111 1111 . 1111 11111 . 1111 1111** . *0000 0000*

>[!info] Notación alternativa
>- El valor */24* indica la longitud de la parte de red (no. de unos de la máscara).
>- Esta notación se denomina *dirección IP extendida* o notación *CIDR (Claseless Interdomain Routing)*.

## Tablas de encaminamiento
Son tablas que guardan los routers y los hosts. Guardan el destino, la salida, las máscaras, las flags y la interfaz del router (el puerto por el que va a salir). Una Gateway todo a 0 nos indica que el destinatario está en la propia red local. En la tabla de enrutamiento es necesario tener un Gateway por defecto al que enviar todos los datos en caso de error.

---
# Protocolo ARP
>[!tldr] ARP (Address Resolution Protocol)
>Es un protocolo de red utilizado para *mapear una dirección IP a una dirección MAC*  en redes de área local (LAN) que utilizan el protocolo Ethernet. ARP permite que los dispositivos en una red local se comuniquen entre sí al asociar sus direcciones IP con sus respectivas direcciones MAC, que son identificadores únicos asignados a las tarjetas de red de los dispositivos.
>
Cuando un dispositivo en una red local necesita comunicarse con otro dispositivo en la misma red y conoce su dirección IP pero no su dirección MAC, utiliza el protocolo ARP para descubrir la dirección MAC correspondiente. 

>[!tldr] Tabla ARP
>Mantiene las direcciones IP de las últimas máquinas con las que nos hemos comunicado y las direcciones Ethernet asociadas.
```bash
# arp -an 
? (147.96.80.1) at 0:0:c:9f:f0:50 [ether] on eth0
? (147.96.80.11) at 54:a0:50:7b:f5:8f [ether] on eth0
? (147.96.80.255) at ff:ff:ff:ff:ff:ff [ether] on eth0
? (147.96.80.10) at (incomplete) [ether] on eth0
```
## Funcionamiento
El proceso funciona de la siguiente manera:
	**1.** El dispositivo que necesita la dirección MAC envía una solicitud *ARP Request* mediante broadcast a todos los dispositivos en la red local. La solicitud ARP contiene la dirección IP del dispositivo de destino y solicita su dirección MAC.
	**2.** Todos los dispositivos en la red local reciben la solicitud ARP y la comparan con sus propias direcciones IP.
	**3**. El dispositivo con la dirección IP coincidente responde enviando un mensaje *ARP Reply* al dispositivo solicitante, proporcionando su dirección MAC.
	**4.** El dispositivo solicitante recibe la respuesta ARP y actualiza su tabla ARP, que es una lista de asociaciones de direcciones IP y direcciones MAC. Luego, el dispositivo puede comunicarse directamente con el dispositivo de destino utilizando su dirección MAC.
El protocolo ARP es esencial para el funcionamiento de las redes Ethernet y es parte de la suite de protocolos TCP/IP.

Normalmente, cuando vayamos a querer transmitir a otra red, entonces, tendremos como puerta del enlace (Gateway) la parte del router que corresponderá a nuestra red de área local. 
Cuando enviamos un paquete a un router, este va a sufrir modificaciones (vamos a cambiar las MACs para poder circular por la otra red). ARP no va a salir nunca de una red de área local (no podemos enviar paquetes ARP a otras redes).
## Formato
![[formato-arp|500]]
- **HLEN**: Hardware address length
- **PLEN**: IP address length
- **Operation**:
	- 1 = *ARP Request*
	- 2 = *ARP Response*
	- 3 = *RARP Request*
	- 4 = *RARP Response*

---
# Subredes, superredes y CIDR
## Subredes
Una **subred** es una división de una red IP en segmentos más pequeños y manejables. La creación de subredes permite un mejor control y organización de la red, así como una mayor eficiencia en el uso de las direcciones IP. 
Para crear subredes se utiliza una máscara de subred, que es un número binario de 32 bits que determina qué parte de la dirección IP representa la red y qué parte representa los hosts en esa red.

>[!example] Ejemplo. Suponemos red clase C: `192.168.44.01
>- Queremos dividir la red en 8 subredes.
>	- 3 bits para identificar la subred ($2^{3}=8$ subredes).
>	- 5 bits para identificar el host ($2^{5}=32 \text{dir. por subred}$).
>- Máscara de subred (**red** subred *host*):
>	- IP: `192.168.44.x`
>	  **11000000.10101000.00101100**.sss*hhhhh*
>	- Máscara: `255.255.255.224`
>	   **11111111.11111111.11111111**.‏‎111*0000*
>- Organización resultante:
>	- `192.168.44.0`
>		- hosts: `192.168.44.1－192.168.44.30`
>		- broadcast: `192.168.44.31`
>	- `192.168.44.32`
>		- hosts: `192.168.44.33－192.168.44.62`
>		- broadcast: `192.168.44.63` 
>	- `192.168.44.64`
>		- hosts: `192.168.44.65－192.168.44.94`
>		- broadcast: `192.168.44.95`
>	- `192.168.44.96`
>		- hosts: `192.168.44.97－192.168.44.126`
>		- broadcast: `192.168.44.127`
>	- `192.168.44.128`
>		- hosts: `192.168.44.129－192.168.44.158`
>		- broadcast: `192.168.44.159`
>	- `192.168.44.160`
>		- hosts: `192.168.44.161－192.168.44.190`
>		- broadcast: `192.168.44.191`
>	- `192.168.44.192`
>		- hosts: `192.168.44.193－192.168.44.222`
>		- broadcast: `192.168.44.223
>	- `192.168.44.224
>		- hosts: `192.168.44.225－192.168.44.254`
>		- broadcast: `192.168.44.255`

>[!tldr] VLSM (Variable Length Subnet Mask)
Son máscaras de longitud variable que permiten la creación de sub-subredes.

## Superredes
Una **superred**  es el resultado de combinar varias redes IP contiguas en una sola red más grande (*supernetting*). Esto se hace para simplificar el enrutamiento y reducir la cantidad de entradas en las tablas de enrutamiento de los routers, lo que mejora la eficiencia y el rendimiento de la red.

## CIDR (Classless Interdomain Routing)
Es el resultado de unir *VLSM* y *Supernetting* que elimina el concepto de clases. Las entradas en las tablas de rutas de los routers en CIDR deben tener no solo la dirección de destino, sino también su máscara.
Con *CIDR* se pueden asignar redes ajustadas al tamaño necesario, con un id. de red y una máscara del tamaño deseado, y se reduce el número de entradas en las tablas de rutas "resumiendo" varias entradas en una (agregado de direcciones).

---
# Protocolo ICMP
El *Protocolo ICMP (Internet Control Message Protocol)* es un protocolo de red utilizado para proporcionar información de diagnóstico y control, así como para informar sobre errores en la comunicación entre dispositivos en redes IP. 

ICMP funciona en la capa de red del modelo OSI (Open Systems Interconnection) y utiliza mensajes para comunicarse con otros dispositivos en la red. Estos mensajes ICMP se encapsulan dentro de paquetes IP y se transmiten a través de la red. Hay varios tipos de mensajes ICMP:
- **Mensajes de error**: permiten informar de situaciones de error en la red, i.e. destination unreachable, time exceeded...
- **Mensajes informativos**: permiten intercambiar información sobre la presencia o el estado de un determinado sistema, i.e. echo request, router solicitation...

## Formato del mensaje
![[formato-icmp|500]]
- **Type**: indica el tipo del mensaje ICMP.
- **Code**: ofrece información adicional sobre el contenido del mensaje cuyo significado depende del tipo del mensaje.
- **Checksum**: campo para detectar errores en el mensaje ICMP.
### Tipos de mensajes
#### Mensajes informativos 

| **Tipo** | **Significado** |
| :--------: | :---------------: |
|    0     |     *Echo Reply*      |
|    5     |      *Redirect*       |
|    8     |    *Echo Request*     |
|    9     | *Router Solicitation* |
|    10    | *Router Advertisement*                      |

- **Echo Reply/Request**
	- **Type**: 0/8
	- **Code**: 0
	- **Checksum**
	- **ID**: establece correspondencia entre solicitud y respuesta, ambas tienen el mismo.
	- **No. sequence**: igual que el ID cuando se envían varias solicitudes consecutivas con el mismo ID.
	- **Data**: no. determinado de bytes, generados aleatoriamente o especificado como parámetro en *ping*.
#### Mensajes de error

| **Tipo** |      **Significado**      |
|:--------:|:-------------------------:|
|    3     | *Destination Unreachable* |
|    4     |      *Source Quench*      |
|    11    |      *Time Exceeded*      |
|    12    |    *Parameter Problem*    | 

- **Destination Unreachable**
	- **Code**
		- 0: *Network unreachable* 
			- Fallo en el link hacia la red.
			- Routing incorrecto.
		- 1: *Host unreachable*
			- Máquina apagada o desconectada de la red.
			- Dirección IP incorrecta.
		- 2: *Protocol unreachable*
			- No. de protocolo incorrecto en el paquete IP.
			- Protocolo no disponible (por ej. OSPF, etc.).
		- 3: *Port unreachable*
			- Puerto UDP cerrado.
		- 4: *Fragmentation needed but the Do Not Fragment bit was set*
			- Permite implementar el mecanismo de “Path MTU Discovery”.
		- 5: *Source route failed*
		- 6: *Destination network unknown* 
			- Routing incorrecto o dirección IP incorrecta.
		- 7: *Destination host unknown*
			- Routing incorrecto o dirección IP incorrecta.
		- 9: *Destination network administratively prohibited*
			- Red protegida con un firewall.
		- 10: *Destination host administratively prohibited*
			- Host protegido con un firewall.

---
# Encaminamiento (Routing)
Queremos que nuestros paquetes puedan viajar por distintas redes, para lo que necesitaremos todos los conceptos de este tema. Consiste en buscar un camino entre el origen y el destino para que puedan enviarse correctamente todos los paquetes.

Nos vamos a basar en el concepto del camino más corto (el que mejor nos conviene según un criterio decidido: distancia, retardo, número de saltos, nivel de tráfico, ancho de banda, …).

Tenemos varios modos de decidir qué va a pasar con los paquetes:

- **Encaminamiento local**: No tienen en cuenta la topología de la red y las decisiones que puede tomar son encaminamiento aleatorio (puede producir problemas) o bien encaminamiento aislado o inundación (el paquete se va a enviar por todos los interfaces por los que no ha llegado).

- **Encaminamiento estático**: El administrador de la red es el que se va a encargar de construir manualmente las tablas de enrutamiento. Si alguno de los enlaces se cae, no es capaz de reconfigurarse.

- **Encaminamiento dinámico**: Es el que se utiliza actualmente. Se adapta a la topología de la red (se producen intercambios de información entre routers para crear las rutas). Tenemos dos técnicas distintas: *Encaminamiento por vectores de distancia* y por *estado de los enlaces*.

## Encaminamiento estático 
Sigue el **principio de optimización**. Las tablas son construidas por el administrador de la red. Solo vamos a necesitar conocer la identidad del siguiente encaminador. El encaminamiento se va a denominar *encaminamiento por siguiente salto* o *salto a salto*.

## Encaminamiento por vector de distancias 
Cada nodo de conmutación va a tener una tabla de encaminamiento con una entrada para cada uno de los destinos posibles. Contendrá el **destino**, el **siguiente nodo** y la **distancia al destino**. Los nodos van a intercambiar información con otros vecinos (**vector de distancia**: cada uno de los destinos y las distancias a las que se va a encontrar), con los que se va a actualizar la tabla de encaminamiento. Uno de los algoritmos que se basa en vectores de distancia es *RIP (Routing Information Protocol)*.

Al conectar un nuevo nodo, se realizará un ping al conectarlo y se creará su propia tabla gracias a la información que va a recibir a través de vectores de distancia de sus nodos vecinos. Con esta información que ha recibido, va a ser capaz de crear su propia **tabla de encaminamiento**.

Si los cambios que nos llegan son peores, pero nos los envía la red que nos había dicho previamente que el mejor, tenemos que hacerle caso puesto que puede indicar un cambio en la topología de la red.

## Encaminamiento por estado de enlaces 
Cada encaminador va a mantener información sobre la topología de la red. Cada encaminador va a mantener información sobre los nodos vecinos. La información de los enlaces locales se usa para construir la **base de datos del estado de los enlaces** (todos tienen la misma base de datos).

Cada nodo va a construir su **propio árbol de rutas** (algoritmo Dijkstra) en el que se seleccionan las rutas más cortas a otros nodos y se eliminan posibles bucles. Un posible algoritmo que emplea esto es *OSPF (Open Shortest Path First)*.

## Encaminamiento en Internet 
Se emplean **algoritmos de encaminamiento dinámico**. Internet se organiza jerárquicamente en *Sistemas Autónomos (AS)*. Tendremos *Protocolos Internos (IGP)*, que se emplean dentro de un *AS (RIP, OSPF y IGRP)* y *Protocolos Externos (EGP)*, que se emplean para el encaminamiento entre distintos *AS (EGP, BGP)*.

En redes IP, las tablas de encaminamiento van a contener la siguiente información:
- **Destination**: Red o host de destino.
- **Gateway**: El host que debe entregar o reexpedir el paquete.
- **Genmask**: Máscara de red asociada a la red destino.
- **Flags**: *U* (Ruta usable), *H* (Campo destination es un host), *G* (Host entrega router), *D* (Ruta consecuencia de una redirección ICMP).
- **IFace**: Enlace o interfaz de red por el que se alcanza la red destino.

---
# Encaminamiento (Routing)-ver.GPT4
El **encaminamiento**, también conocido como enrutamiento, es el proceso de selección de rutas en una red para enviar paquetes de datos desde un dispositivo de origen a un dispositivo de destino. Existen diferentes enfoques para el encaminamiento, como el encaminamiento local, el estático y el dinámico.

## Encaminamiento local
El **encaminamiento local** se refiere al proceso de enviar paquetes de datos dentro de la misma red local (LAN) o subred. En este caso, los dispositivos de origen y destino están en la misma red, y no es necesario que los paquetes pasen por un router para llegar a su destino. El encaminamiento local se basa en las direcciones MAC (Media Access Control) de los dispositivos y en la tabla ARP (Address Resolution Protocol) para determinar cómo enviar paquetes a sus destinos.

## Encaminamiento estático
El **encaminamiento estático** es un enfoque en el que las rutas en una red se definen manualmente por un administrador de red. Estas rutas se ingresan en la tabla de enrutamiento del router y no cambian a menos que el administrador las modifique. El encaminamiento estático es simple y fácil de implementar en redes pequeñas y con pocos cambios en la topología de la red. Sin embargo, no es escalable y puede ser difícil de mantener en redes más grandes y dinámicas.

Técnicas comunes en el encaminamiento estático:
- **Rutas predeterminadas (default routes)**: Se utiliza para especificar una ruta por defecto hacia la cual se enviarán todos los paquetes cuyo destino no tenga una ruta específica en la tabla de enrutamiento. Esto simplifica la configuración y reduce el tamaño de la tabla de enrutamiento.
- **Rutas de host**: Son rutas que especifican un único destino IP. Se utilizan para establecer rutas específicas hacia dispositivos individuales en la red.
- **Rutas de red**: Son rutas que especifican una red o subred completa. Se utilizan para establecer rutas hacia redes enteras en lugar de dispositivos individuales.

## Encaminamiento dinámico
El **encaminamiento dinámico** es un enfoque en el que los routers intercambian información de enrutamiento automáticamente utilizando protocolos de enrutamiento. Esto permite que las rutas se ajusten dinámicamente en función de los cambios en la topología de la red, como la adición o eliminación de dispositivos y enlaces. El encaminamiento dinámico es más escalable y fácil de mantener que el encaminamiento estático, pero puede ser más complejo de configurar y requiere más recursos de procesamiento y memoria en los routers.

Técnicas comunes en el encaminamiento dinámico:
- **Protocolos de enrutamiento de vector distancia (distance-vector)**: Estos protocolos, como *RIP (Routing Information Protocol)* y *IGRP (Interior Gateway Routing Protocol)*, utilizan algoritmos basados en la distancia y el número de saltos para determinar las rutas óptimas en una red. Los routers intercambian periódicamente información de enrutamiento y actualizan sus tablas de enrutamiento en función de la información recibida.
- **Protocolos de enrutamiento de estado de enlace (link-state)**: Estos protocolos, como *OSPF (Open Shortest Path First)* e *IS-IS (Intermediate System-to-Intermediate System)*, utilizan algoritmos basados en el estado de los enlaces y el costo de los caminos para determinar las rutas óptimas en una red. Los routers intercambian información sobre el estado de los enlaces y construyen un mapa de la topología de la red, que luego se utiliza para calcular las rutas óptimas.

En resumen, el encaminamiento local, estático y dinámico son enfoques diferentes para seleccionar rutas en una red. El encaminamiento local se utiliza para enviar paquetes dentro de la misma LAN o subred, mientras que el encaminamiento estático y dinámico se utilizan para enviar paquetes a través de diferentes redes y subredes. El encaminamiento estático es simple y fácil de implementar, pero no es escalable, mientras que el encaminamiento dinámico es más escalable y fácil de mantener, pero puede ser más complejo de configurar.