#redes 
```toc
```
---
# Introducción
## Protocolos de transporte en Internet: TCP y UDP
El **protocolo TCP (Transmission Control Protocol)** es un protocolo de transporte *orientado a conexión* que garantiza un servicio extremo a extremo fiable, es decir, detecta segmentos de datos perdidos o erróneos y los retransmite, segmentos duplicados y los descarta y ordena los segmentos en el destino y los entrega de forma ordenada a la capa de aplicación.
Es utilizado en aplicaciones en las que la fiabilidad en la entrega es más a importante que la rapidez, i.e. FTP, HTTP, Telnet, SMTP...

El **protocolo UDP (User Datagram Protocol)** es un protocolo de transporte *sin conexión* que no garantiza un servicio extremo a extremo fiable, es decir, no controla la pérdida de paquetes, los errores o la duplicidad.
Es utilizado en aplicaciones en las que la rapidez en la entrega es más importante que la fiabilidad, i.e. DNS, SNMP, RIP, RTP...

|    **Característica**    |                                                                  **TCP**                                                                   |                                                              **UDP**                                                               |
|:------------------------:|:------------------------------------------------------------------------------------------------------------------------------------------:|:----------------------------------------------------------------------------------------------------------------------------------:|
|     Tipo de conexión     | Orientado a conexión:<br> - Entrega ordenada de paquetes<br> - Retransmisión de paquetes perdidos o erróneos<br> - Detección de duplicados | Sin conexión:<br> - No garantiza la entrega ordenada<br> - No retransmite paquetes perdidos o erróneos<br> - No detecta duplicados | Unidad de transferencia | Segmento (20 bytes mínimo de cabecera) | Datagrama (8 bytes mínimo de cabecera) |
| Fases de la comunicación |                         1. Establecimiento de la conexión<br> 2. Transferencia de datos<br> 3. Cierre de conexión                          |                                          1. Transferencia de datos (bloques individuales)                                          |                         |                                        |                                        |
| Control de errores/flujo |                 Método de tipo ventanas deslizantes:<br> - Numeración de segmentos<br> - Confirmación<br> - Retransmisión                  |                                                  Sin control de errores ni flujo                                                   |                         |                                        |                                        |
|         Ejemplos         |                                                      Telnet, FTP, HTTP, SMTP, POP3...                                                      |                                                      DNS, RIP, SNMP, DHCP...                                                       | 

---
# El modelo cliente-servidor, puertos y sockets
## El modelo cliente-servidor
El **modelo cliente-servidor** es el patrón de comunicación usado por la mayoría de aplicaciones en Internet. En este, el cliente es la aplicación que inicia la conexión con la máquina remota (servidor), el cual recibe las peticiones de los clientes y las procesa (como un servidor web, o un servidor DNS).
Todas las aplicaciones o procesos de red ejecutándose en un ordenador se identifican por un *puerto* único dentro de ese sistema, el cual permite la escucha y comunicación entre el cliente y servidor.
En cuanto se establece una comunicación de cliente-servidor los extremos de este canal se denominan *Sockets*, identificados por la dirección IP, el número de puerto y el protocolo que se está usando (TCP o UDP).
Un concepto importante para los servidores es que deben ser capaces de atender a múltiples usuarios a la vez, lo que se denomina como concurrencia.

---
# Protocolo UDP
El **protocolo UDP** es un protocolo *sin conexión* y *no fiable*, el cual divide los mensajes en datagramas no enumerados, el receptor no envía confirmación de los datagramas recibidos y tampoco garantiza:
- La recuperación de datagramas perdidos o erróneos.
- La presentación ordenada de datagramas.
- La eliminación de duplicados.
## Formato del datagrama
![[datagrama-udp|500]]
## Ejemplos
- Envío de paquetes UDP a un puerto de servicio *abierto*
![[ejemplo-udp-abierto]]
- Envío de paquetes UDP a un puerto de servicio *cerrado*
![[ejemplo-udp-cerrado]]

---
# Protocolo TCP
La unidad de transferencia en el protocolo TCP es el *Segmento TCP* y su transmisión consiste en 3 fases:
- Establecimiento de la conexión.
- Transferencia de Datos.
- Cierre de conexión.
También cuenta con varios mecanismos de control de errores de tipo ventana deslizante:
- Numeración de Segmentos (cada segmento tiene un número de secuencia de 32 bits).
- Confirmaciones superpuestas del receptor (cuando el receptor recibe un segmento correcto y sin errores, envía una confirmación al emisor).
- Retransmisión de segmentos (si pasado un tiempo desde que se envió el segmento, el emisor no recibe confirmación, entonces lo vuelve a enviar).
## Formato
![[datagrama-tcp|500]]
- *URG*: El segmento transporta datos urgentes al principio.
- *ACK*: El segmento lleva un número de confirmación válido (todos los segmentos salvo el primero llevan ACK=1).
- *PSH*: Los datos deben pasarse de forma inmediata a la aplicación.
- *RST*: Aborta una conexión.
- *SYN*: Establece una conexión, y sincroniza los dos extremos de la conexión.
- *FIN*: Finaliza la conexión.
## Ejemplo
### Transmisión sin errores
![[ejemplo-tcp|700]]
### Establecimiento y finalización de conexión
![[tcp-conexion|700]]
![[tcp-desconexion|700]]
En el caso de que el servidor rechace la conexión (que el puerto esté cerrado), cuando el cliente envíe un SYN, el servidor va a responder ocn un RST para rechazar la conexión:
![[tcp-desconexion-abrupta|700]]