#redes 
![[Hoja 1 (Temas 2-3).pdf]]

```toc
```
## Ejercicio 1
$$\begin{align}
&P_{T}=200~mW \\
&f = 1~MHz \\
&atenuación = 20~dB/km\\
& 20~dB/km =\frac{20~db}{1000~m}=0,02~dB/m\\\\
&a)~100m \\
&\text{Atenuación total}=0,02~dB/m*100~m=2~dB\\
&P_{R}=200~mW*10^{\frac{-2dB}{10}}=200~mW*0,63096\approx126,19~mW\\\\
&b)~500m \\
&\text{Atenuación total}=0,02~dB/m*500~m=10~dB\\
&P_{R}=200~mW*10^{\frac{-10dB}{10}}=200~mW*0,1=20~mW\\\\
&c)~1km\\
&\text{Atenuación total}=0,02~dB/m*1000m=20~dB\\
&P_{R}=200~mW*10^{\frac{-20dB}{10}}=200~mW*0,01=2~mW\\\\
&d)~2km\\
&\text{Atenuación total}=0,02~dB/m*2000m=40~dB\\
&P_{R}=200~mW*10^{\frac{-40dB}{10}}=200~mW*0,0001=0,02~mW
\end{align}$$

## Ejercicio 3
$$\begin{align}
&cable = 100m\\
&atenuación = -220~dB/km\\
&SNR_{dB}=20~dB\\
&N=8~\mu W\\\\
&Atenuación = -220~dB/km=-220~dB/1000m=-0,22~dB/m\\
&\text{Atenuación total}=-0,22~dB/m*100m=-22~dB\\
&SNR_{dB}=10*log\left(\frac{S}{N}\right)\implies20~dB=10*log(\frac{S}{8\mu S})\implies\\
&\implies 2=log\left(\frac{S}{8\mu W}\right)\implies10^{2}=\frac{S}{8\mu W}\implies \\\\
&S=10^{2}*8\mu W=800\mu W
\end{align}$$