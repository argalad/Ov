#ampliacionredes
```toc
```
##  Conceptos básicos sobre seguridad
##  Técnicas de cifrado
##  Firmas y certificados digitales. PKI
##  Cortafuegos
##  Redes Privadas Virtuales (VPN)