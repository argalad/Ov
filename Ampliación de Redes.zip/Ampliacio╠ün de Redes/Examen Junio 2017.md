#ampliacionredes

>1. (0,5 puntos) **Explica cómo y cuándo se realiza el proceso de prueba de dirección duplicada en IPv6.**

La prueba de dirección duplicada (*Duplicate Address Detection, DAD*) en IPv6 es un proceso utilizado para asegurar que una dirección IP (Interfaz única de identificación local o global) asignada a una interfaz en una red no es duplicada, es decir, que no está siendo utilizada por otro dispositivo en la misma red. DAD es parte del protocolo NDP (Neighbor Discovery Protocol) en IPv6 y se lleva a cabo automáticamente cada vez que un dispositivo configura una dirección IPv6 en su interfaz.

El proceso de DAD generalmente ocurre en dos situaciones:

1. **Cuando se asigna una dirección IPv6 automáticamente utilizando Stateless Address Autoconfiguration (SLAAC)**: Al asignar una dirección IPv6 global única basada en el prefijo de red y la dirección MAC de la interfaz, el dispositivo debe asegurarse de que la dirección resultante no está siendo utilizada por otro dispositivo en la red.
   
2. **Cuando un dispositivo se inicia o se conecta a una red por primera vez**: El dispositivo verifica si su dirección IP local única de identificación (Link-local address) no está en uso por otro dispositivo en la misma red local. Estas direcciones se usan para comunicarse a nivel de enlace local y son importantes para descubrir otros dispositivos en la red y recibir configuración de enrutadores.

Pasos para realizar la DAD en IPv6:

1. El dispositivo crea una dirección IPv6 tentativa para su interfaz (ya sea una dirección global o de enlace local) y no la asigna inmediatamente.

2. El dispositivo envía un paquete de solicitud de vecino (Neighbor Solicitation, NS) a la dirección IPv6 "solicitada por el nodo" correspondiente a la dirección tentativa. El paquete NS incluye su propia dirección tentativa como dirección de origen y contiene la dirección tentativa como el objetivo en la sección de destino del NS.

3. Si otro dispositivo en la red ya está usando la dirección tentativa, enviará un paquete de anuncio de vecino (Neighbor Advertisement, NA) en respuesta al paquete NS. Esto informa al dispositivo que la dirección IPv6 tentativa ya está en uso.

4. Si el dispositivo no recibe ningún paquete de anuncio de vecino (NA) en respuesta, se determina que la dirección IPv6 tentativa no está en uso y, por lo tanto, es única en la red. Ahora, el dispositivo puede asignar de manera segura la dirección IPv6 a su interfaz y comenzar a utilizarla para comunicarse en la red.

La DAD garantiza que las direcciones IPv6 sean únicas en la red y evita conflictos de direcciones que podrían causar problemas de comunicación y dificultades en la resolución de problemas de red.

>2. (0,75 puntos) **Explica brevemente el funcionamiento de los túneles 6in4, mencionando los dispositivos de red implicados.**

Los *túneles 6in4* son una técnica de transición de red que permite la comunicación entre redes IPv6 utilizando la infraestructura IPv4 existente. En otras palabras, proporciona una forma de transportar paquetes IPv6 a través de enlaces IPv4. Esta técnica es útil para redes que aún no están totalmente preparadas para IPv6, pero necesitan comunicarse con otras redes IPv6.

Funcionamiento de los túneles 6in4:

1. En primer lugar, se configuran dos dispositivos de red (generalmente enrutadores) en los extremos del túnel 6in4. Estos dispositivos se denominan "puntos finales" del túnel. Uno de los puntos finales está en la red de origen y el otro en la red de destino IPv6.

2. Ambos enrutadores a cada lado del túnel deben tener interfaces Ethernet configuradas para IPv6 y una dirección IPv4 en su interfaz de túnel.

3. Cuando un paquete IPv6 necesita ser transportado a través del túnel 6in4, el primer enrutador encapsula el paquete IPv6 en un paquete IPv4. Esto implica añadir una cabecera IPv4 al paquete original, incluyendo las direcciones IPv4 de los puntos finales del túnel en los campos de dirección de origen y destino.

4. El paquete IPv4 encapsulado es enviado a través de la red IPv4 hasta el otro punto final del túnel.

5. El enrutador de destino recibe el paquete IPv4 y, dado que se identifica como parte del túnel 6in4, desencapsula el paquete original IPv6. Esto implica quitar la cabecera IPv4 del paquete.

6. El enrutador de destino luego reenvía el paquete IPv6 a su destino en la red IPv6 local.

Los túneles 6in4 son una solución temporal para permitir la comunicación entre redes IPv6 mientras todavía existen redes basadas en IPv4. No obstante, la adopción completa de IPv6 en la infraestructura de red es el objetivo final para la mayoría de las organizaciones, ya que proporciona una solución más escalable y eficiente en el futuro.

