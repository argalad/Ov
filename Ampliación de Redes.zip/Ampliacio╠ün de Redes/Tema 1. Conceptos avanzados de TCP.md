#ampliacionredes #tcp 
```toc
```
## Repaso de TCP
### Formato del segmento
- **Puertos origen y destino**: $2^{16}$ puertos, de los cuales $1024(1\rightarrow 1023)$ son bien conocidos y el resto efímeros.
> [!info]-
> Cuando queremos usar un puerto por debajo de 1023 (i.e. HTTP→883), tenemos que ejecutarlo como superusuario, eso sólo se realiza en el momento de la conexión, luego cambia su _evid_ a usuario que tiene normalmente menos privilegios que un usuario normal.
- **No. de secuencia**: hay segmentos que no llevan datos pero siempre consumen un número de secuencia. Éstos no pueden ser predecibles y no se pueden repetir (cuando veamos el 0 como un número de secuencia no quiere decir que sea el primero).
	![[Ampliación de Redes/Resources/f1.1|300]]
	Los números de secuencia se van incrementando y cuando lleguen al máximo, volvemos y empezamos con cero, y cuando lleguemos al punto de partida (el valor aleatorio inicial) entonces cerramos la conexión.
- **No. de confirmación ACK**: es el siguiente número que vamos a recibir, no el que acabamos de recibir, y siempre será del mismo tamaño que el número de secuencia.
- **Longitud de cabecera**: donde la longitud mínima es 5 bits, lo que nos dice es donde empiezan los datos, como tenemos varias opciones e incluso el relleno, necesitamos saber ubicar lo que es información de cabecera de los datos.
- **Flags (8 bits)**
	- **FIN**: indica que no transmitiremos más datos.
	- **SYN**: para establecer la conexión.
	- **RST**: para realizar un cierre abrupto de la conexión.
	- **PSH**: para aplicaciones interactivas, donde tiene que enviarse inmediatamente y despertar la app.
	- **ACK**: indica que el número de confirmación tiene sentido.
	- **URG**: los primeros datos que hay en el datagrama, son los que tienen que ser consumidos antes de cualquiera que haya recibido (se saltan el orden de flujo).
	- **ECE**: Explicit Congestion Echo (ECN).
	- **CWR**: Congestion Window Reduced (ECN).
- **Reservado (2 bits) y CMR(2 bits)**.
- **Ventana (16 bits)**: nos indica cuanto espacio (bytes) adicionales puedo recibir.
- **CRC (16 bits)**.
- **Puntero de urgente (16 bits)**: nos indican hasta donde llegan estos datos urgentes y a partir de donde empiezan los normales (hay ambigüedad, por lo que hay que usarlo lo menos posible o enviar un sólo dato de urgente).
- **Opciones + [Relleno]**: se usa el factor multiplicador de la ventana, porque para estos tiempos ya es insuficiente los bits que tenemos para determinar la ventana y el relleno se aplica porque para determinar mejor el inicio de los datos hay que tener un múltiplo de 32.
### Intento de conexión
- **Apertura**
	- **Puerto abierto**: se activan los bits del FLAG en SYN y ACK.
	  ![[f1.2]]
	- **Puerto cerrado**: la conexión es rechazada si es que el puerto no está disponible. En el caso que tenga un cortafuegos y para evitar la exploración de puertos, es el cortafuegos el que recibe y filtra la conexión si el puerto está cifrado, haciendo así que el timeout del cliente se supere y no sepa el estado del puerto.
	  ![[f1.3]]
	  En el momento en el que se realiza el _SYN_, se negocia el _MSS_ (Maximum Segment Size), que en su tiempo era 576 pero ahora podemos aumentar ese valor, tampoco es conveniente aumentarlo mucho ya que tenemos que fragmentar el datagrama, esto si la red es fiable no hay problema, pero si no es así se perdería alguno, lo que obliga a esperar a ese datagrama y en caso de que se superase el límite de espera se tendría que descartar todo el segmento. Si la probabilidad de pérdida es del 1%, se perderán 1 de cada 100 fragmentos, y si nuestro datagrama se fragmenta en 100, nunca se podría realizar una conexión (siempre faltaría 1 fragmento). Lo óptimo es negociar el _MSS_ para que se ajuste lo máximo posible a la MTU mínima del camino.
- **Cierre**
	- **4 vías**
	  ![[f1.4|700]]
	- **3 vías**
	  ![[f1.5|600]]
  A y B pueden ser tanto cliente como servidor, aunque lo normal es que sea el cliente quien la empieza.
## Control de errores en TCP y temporizadores de retransmisión
- **Confirmaciones (ACK)**: sabemos que cuando se envían los segmentos, éstos se almacenan en un buffer hasta que la aplicación las consuma, por ello las confirmaciones son:
	- **Acumulativas**: si yo recibo algunos segmentos, sólo me hace falta confirmar el último de la secuencia que he recibido, así simplemente pido la que me falta y si me han llegado segmentos después del que me falta, en el momento que me llegue el que requiero sólo me hace falta confirmar el último de toda la secuencia, así pues:
	  ![[f1.6|700]]
	- **Incorporadas**: aprovecho los segmentos de datos que vienen en un sentido para confirmar los que ya he recibido, pero si no tengo datos que enviar tengo que confirmar de manera ==explícita==; además si no tengo datos que enviar tengo que esperar un máximo de 500ms por si envían otros datos (tanto por si llega un segmento nuevo o por si la aplicación envía algunos) y puedo confirmar con ellos, pero sólo se espera como mucho a un segmento.
	- Los segmentos ==retrasados== y ==duplicados== se confirman inmediatamente.
	- **Selectivas (SACK)**: es un mecanisno opcional que permite confirmar todos los elementos que he recibido.
## Control de flujo en TCP
El control de flujo es un mecanismo crucial en TCP (Protocolo de Control de Transmisión) que evita que un remitente envíe demasiados datos a un receptor, evitando así que el receptor se sature y que los datos se pierdan porque el buffer del receptor se llena.
Funcionamiento:
1.  **Ventanas deslizantes**: El control de flujo en TCP se realiza mediante un mecanismo conocido como ventanas deslizantes. Cada conexión TCP tiene una ventana de control de flujo que determina cuántos bytes pueden estar en tránsito (enviados pero aún no reconocidos) en un momento dado. Esta "ventana" es la cantidad de datos que el receptor está dispuesto a aceptar (w≠0).
2. **Acuses de recibo y tamaño de la ventana**: En cada acuse de recibo (ACK) que el receptor envía al remitente, indica el tamaño de su ventana de recepción, que es la cantidad de datos que puede aceptar. Si el tamaño de la ventana es de 10.000 bytes, por ejemplo, el remitente puede enviar hasta 10.000 bytes de datos sin recibir un acuse de recibo.
3. **Ajuste de la ventana**: Si el receptor comienza a tener dificultades para procesar los datos tan rápido como llegan (por ejemplo, si su buffer está casi lleno), puede reducir el tamaño de la ventana en sus acuses de recibo para decirle al remitente que reduzca la tasa de transmisión. De manera similar, si el receptor puede procesar los datos más rápidamente, puede aumentar el tamaño de la ventana para permitir una tasa de transmisión más alta.
4. **Ventana llena**: Si el buffer del receptor se llena completamente, anuncia una ventana de tamaño cero. En este punto, el remitente debe detener todas las transmisiones hasta que el receptor pueda vaciar su buffer y anunciar una ventana de tamaño no cero.
5. **Persistencia de TCP**: Para evitar el problema de que el remitente no pueda enviar más datos porque la ventana es cero, y no pueda recibir actualizaciones de la ventana porque no está enviando datos, TCP utiliza un temporizador de persistencia. Si el remitente recibe una ventana de tamaño cero, comienza el temporizador de persistencia y ocasionalmente envía un segmento de sonda para verificar si el receptor puede aceptar más datos.

- **Síndrome de la ventana trivial (silly window syndrome)**: es un problema potencial en el control de flujo de TCP que puede degradar el rendimiento de la red. Sucede cuando se envían pequeñas cantidades de datos en muchos paquetes,  lo que puede llevar a una utilización ineficiente del ancho de banda.
  Esto ocurre cuando el buffer está lleno y la aplicación empieza  a consumir datos lentamente (byte a byte), por lo que enviamos la cabecera (40 bytes) + datos (1 byte) constantemente. Para evitar esto se realiza lo siguiente:
  1. **Emisor**: hace uso del bit PSH del FLAG para enviar los datos (así se consumen sin espera), como estos datos se envían lentamente se utiliza el *algoritmo de Nagle* para mejorar el rendimiento:
	     - Inicia enviando el primer segmento.
	     - Espera que llegue el ACK de ese primer segmento pero mientras tanto voy almacenando en el buffer el resto de bytes hasta que se alcance el MSS (Maximum Segment Size) o expire el RTO.
	       ![[f1.7|600]]
	       Cuando enviamos los datos (caracteres en este caso) lo que nos devuelven es una copia de los datos que hemos recibido, es decir, de los caracteres, de esa manera nos aseguramos de que lo que ha recibido el otro lado es lo que queríamos, pues el receptor puede tener otro estándar de codificación de los datos.
2. **Receptor**: aplicamos la *solución de Clark* cuando vamos enviando anuncios por cada byte consumido, que nos indica que desde que se ha hecho un anuncio de ventana de 0, no se vuelve a hacer hasta que se libere todo el buffer con lo que tendría un aviso =MSS o quede libre la mitad del buffer de recepción. Habría que tener en cuenta que:
	   - Si el MSS < size(buffer)/2 ⟶ se activa cuando quede libre MSS.
	   - Si el MSS > size(buffer)/2 ⟶ se activa cuando quede libre la mitad del buffer.

### Temporizadores
- **Retransmisión Time Out (RTO)**: se utiliza cuando se pierden segmentos, para transmitirlos de nuevo.
	1. **Jacobson**: se basa en estimar una variable *RTT* (Round Time Trip), que se determina por la duración del viaje actual. Así ponemos un valor RTO (inicializado a 3s). Este algoritmo se usa cuando la red es estable y no tiene gran diferencia entre los RTT.
	   $$RTT^{n}_{s}=(1-\alpha)\cdot RTT^{n-1}_{s}+\alpha\cdot M$$
	   $$\alpha=\frac{1}{8}; ~~~RTO=\gamma \cdot RTT_{s};~~~\gamma=2$$
	2. **Jacobson/Karels**: cuando hay demasiado movimiento en la red y los tiempos de $m$ son muy diferentes (no tan estables como en Jacobson), utilizamos este algoritmo que tiene en cuenta la desviación. Como valor inicial de $D=\frac{m}{2}$, $m$ es la varianza y $\upbeta =\frac{1}{4}$
	   $$\begin{align}
	&D^{0}=\frac{m^{0}}{2} \\
	&D^{n}=(1-\upbeta)\cdot D^{n-1}+\upbeta \cdot |RTT^{n-1}-M| \\
	&RTO^{n+1}=RTT^{n+1}_{s}+4\cdot D^{n+1}
\end{align}$$
	3. **Karels**: cuando hemos enviado segmentos y se han cumplido los temporizadores, como vamos a volver a enviar el segmento, no vamos a poder saber a quién pertenece el ACK, por lo que no hace nada, se detienen todos los envíos y se duplica el RTO, y mientras se siga cumpliendo el límite de los temporizadores, seguirá duplicando.
- **KeepAlive**: nos sirve para no mantener las conexiones abiertas indefinidamente y no desperdiciar recursos, ya que pueden quedarse los clientes sin enviar el FIN por motivos diversos (corte de luz, caída del sistema...) y funciona con estos parámetros:
	- `tcp_keepalive_time`: nos indica cuánto tiempo puede estar la conexión sin enviar ni recibir ningún dato.
	- `tcp_keepalive_probes`: número de sondas que vamos a enviar para determinar si es que la conexión se ha caído o no (las sondas se envían después de haber llegado al límite puesto por `tcp_keepalive_time`).
	- `tcp_keepalive_intvl`: número de segundos entre sonda y sonda que vamos a esperar para enviar otra.
- **Time Wait**: es un temporizador que aparece en el diagrama de estados, que sirve para evitar que los segmentos retrasados puedan iniciar una segunda conexión sin querer (nota anterior) y se fijan normalmente al doble de MSS.
- **Persistencia**: cuando el emisor tiene más datos que enviar y no recibe el ACK de confirmación de datos, pone en marcha un temporizador, cuando llega al límite envía una sonda hacia el receptor que fuerza un nuevo envío de ACK, de esta manera ya puede conocer si puede seguir o no enviando datos y el tamaño de ventana (w).
## Control de congestión en TCP
Nos indica la problemática sobre la velocidad de la red y la sobrecarga porque hayan muchos segmentos transitando por una misma conexión, se pueden dividir en leve y severa.
- **Funcionamiento normal de la transmisión**
	- Al principio se envía un segmento y se espera al ACK mientras no expire su RTO. En el caso de que no lo haga, se envían el doble de segmentos y así voy duplicando el envío de segmentos cada vez. A este proceso se le llama *arranque lento*.
	- En el momento que llegue al *SST (Slow Start Threshold)* se empieza a crecer de manera más lineal mientras no expire el temporizador (RTO) y hasta que se llega al máximo número que nos indica el receptor en su ventana w. Esta fase se denomina *evitación de congestión* y termina en una fase *constante*.
	  ![[f1.8|600]]
- **Congestión leve**
	- Cuando se pierden pocos paquetes (3 en concreto) y se envían los duplicados sin mayor problema pero no expira el RTO.
	  ![[f1.9|600]]
	  - Por ejemplo, si cuando la ventana de recepción ya encontró su valor constante, pero de repente recibo 3 ACK duplicados, se disminuye la CW a la mitad, y a partir de ahí empiezo con la fase de evitación de congestión, con la esperanza de que al haber disminuido la ventana de congestión se haya resuelto el problema.
	  - Si vuelvo a recibir 3 ACK duplicado, se realiza el mismo proceso. Esto nos permite enviar lo máximo posible en cada momento, incluso con los conflictos de la red.
	  - Si llegáramos al inicio, no se haría el crecimiento exponiencial, sino que se realizaría el mismo procedimiento.
	  - Es importante que todos los demás segmentos hayan llegado y sean sólo los 3 duplicados los que se perdieran.
- **Congestión severa**
	- Cuando expira el RTO porque se han perdido casi todos los paquetes.
	  ![[f1.10|600]]
	- Para este caso se vuelve a realizar la búsqueda de la ventana de congestión desde el inicio, como si fuera una nueva conexión, con la particularidad que cada vez que llegue a un temporizador que lo limite (expire el RTO) volvemos a buscar esa ventana pero siempre arrancando a la mitad de lo que ya teníamos hasta ese momento.
## Ajuste de parámetros de TCP
## Programación con sockets
