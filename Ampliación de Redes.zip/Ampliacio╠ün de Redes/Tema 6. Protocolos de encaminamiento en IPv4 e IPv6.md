#ampliacionredes
```toc
```
## Sistemas autónomos
Un *sistema autónomo* es un conjunto conexo de redes IP y encaminadores bajo el control de una o varias organizaciones y con una política de encaminamiento común. Puede ser tan pequeño como una empresa o tan grande como un continente.
Se comunican con otros sistemas autónomos por medio de un protocolo de pasarela de frontera *BGP (Border Gateway Protocol)*.
##  RIP
*RIP (Routing Information Protocol)* es un protocolo de enrutamiento de pasarela interior (IGP) que utiliza el algoritmo de estado de enlace de vector de distancia para calcular las rutas óptimas en una red. Fue desarrollado inicialmente para ser utilizado en redes más pequeñas y menos complejas. Hay dos versiones de RIP, RIP versión 1 (RIPv1) y RIP versión 2 (RIPv2). RIPv2 es más avanzado, ya que incluye mejoras en el enmascaramiento de subredes y autenticación.

### Características del encaminamiento RIP
1. **Algoritmo de vector de distancia**: RIP utiliza el algoritmo de Bellman-Ford para calcular las rutas óptimas. Este algoritmo cuenta la cantidad de saltos (hops) que hay entre dos dispositivos y utiliza esta información para determinar la ruta más corta.

2. **Límite de saltos (hops)**: RIP tiene un límite máximo de 15 saltos. Si la ruta entre dos dispositivos es mayor a 15 saltos, se considera inalcanzable. Esto limita el tamaño y la complejidad de las redes que pueden utilizar RIP.

3. **Tabla de enrutamiento**: Cada encaminador RIP mantiene una tabla de enrutamiento que contiene información sobre las rutas óptimas para llegar a otras redes en la topología.

4. **Actualizaciones periódicas**: RIP utiliza actualizaciones de enrutamiento periódicas para asegurar que todos los encaminadores en la red tengan información actualizada sobre la topología. Por defecto, estas actualizaciones se envían cada 30 segundos.

5. **Envejecimiento de las rutas**: RIP establece un tiempo de vida para las rutas en la tabla de enrutamiento, lo que significa que las rutas se eliminarán de la tabla si no se actualizan después de un cierto período.

6. **Eliminación de rutas no utilizadas**: RIP utiliza un proceso llamado "garbage collection" (recolección de basura) para eliminar rutas que ya no se utilizan. Específicamente, cuando una red ya no es accesible o alcanzable, el encaminador marca ese registro como "inválido" y lo elimina de la tabla de enrutamiento después de un periodo de tiempo.

7. **Temporizador de holgura (Hold Down Timer)**: Cuando se detecta una ruta inaccesible, RIP activa un temporizador de holgura para evitar que los encaminadores aprendan rutas inconsistentes. Durante este tiempo, no se aceptarán actualizaciones sobre la ruta inaccesible.

8. **Prevención de bucles de enrutamiento**: RIP implementa dos técnicas principales para prevenir bucles de enrutamiento: temporizadores (explicados anteriormente) y Split Horizon, que evita que un encaminador anuncie rutas en la misma interfaz desde la que las aprendió.
   
   ![[ f3.3|600]]
   R4 se queda con la primera que le llega en caso de recibir dos iguales. Si me quedo con un camino y después cambia y es más largo, me aguanto hasta que llegue uno más corto.

### El problema de bucles en RIP
En el protocolo RIP, un bucle de enrutamiento es una situación en la que un paquete de datos sigue circulando por un ciclo de encaminadores sin llegar nunca a su destino. Esto puede ocurrir debido al intercambio de información entre encaminadores cuando la red cambia o si hay una mala configuración. Un bucle de enrutamiento puede provocar que los paquetes se pierdan, consumir ancho de banda de la red y causar una congestión excesiva.

Veamos un ejemplo sencillo de un bucle de enrutamiento en una red que utiliza el protocolo RIP:

Supongamos que tenemos una red con cuatro encaminadores: A, B, C y D, conectados de la siguiente manera:

```
A -- B -- C
 \       /
  --- D ---
```

Inicialmente, todas las conexiones funcionan correctamente y se establecen las siguientes rutas:

- A llega a B en 1 salto, a C en 2 saltos (a través de B) y a D en 1 salto.
- B llega a A en 1 salto, a C en 1 salto y a D en 2 saltos (a través de A).
- C llega a A en 2 saltos (a través de B), a B en 1 salto y a D en 1 salto.
- D llega a A en 1 salto, a B en 2 saltos (a través de A) y a C en 1 salto.

Ahora, imaginemos que la conexión entre A y B se cae repentinamente. Antes de que todos los encaminadores aprendan sobre la caída del enlace, veremos lo siguiente:

1. A notifica a D que B es inalcanzable ya que su enlace directo con B ha fallado.
2. D sigue pensando que B es alcanzable en 2 saltos a través de A, así que le informa a A que B es alcanzable en 3 saltos (a través de la ruta A-D-B).
3. A, sin saber que la ruta informada por D también pasa por él mismo, actualiza su tabla de enrutamiento creyendo que B es alcanzable en 3 saltos a través de D.

Debido a esto, se crea un bucle de enrutamiento en el que A y D continúan reenviando paquetes entre sí, esperando que el otro encaminador llegue a B, cuando en realidad ninguno de ellos puede alcanzar B directamente.

Este es un simple ejemplo de cómo se pueden formar bucles de enrutamiento en una red RIP si los encaminadores no tienen información actualizada y precisa sobre las rutas. Es importante recordar que las redes reales pueden ser mucho más complejas, y los bucles de enrutamiento más difíciles de detectar y resolver.


### El problema de convergencia lenta
La *convergencia* es el proceso mediante el cual los encaminadores de una red llegan a un acuerdo sobre la topología de la red y las rutas óptimas a seguir para llegar a sus destinatarios. Cuando hay cambios en la red, como la caída de un encaminador o un enlace, el protocolo RIP necesita reajustar su tabla de enrutamiento para reflejar estos cambios. El problema de la convergencia lenta en RIP es que lleva mucho tiempo en propagar esta información por toda la red, lo que resulta en un rendimiento inconsistente de la red hasta que todos los encaminadores sean conscientes del cambio y ajusten su tabla de enrutamiento.
1. Instante 1-6 donde R1 se enciende y está activo.
2. Se cae R1; si en 90s R2 no recibe actualización de R1, borra su entrada.
3. Después de 30s, R2 anuncia a R1 nuevamente.
![[ f3.4|700]]
Soluciones a estos problemas:

1. **Temporizadores**: RIP utiliza varios temporizadores para prevenir problemas como bucles y convergencia lenta. Los temporizadores de actualización, invalidación, holgura y colección de basura, trabajan juntos para eliminar rutas inaccesibles, prevenir bucles y limitar la propagación de información errónea.

2. **Split Horizon**: Esta técnica previene los bucles de enrutamiento al no permitir que un encaminador anuncie rutas aprendidas en la misma interfaz por la que las recibió. De esta manera, se evita el riesgo de compartir información incorrecta o desactualizada con otros encaminadores. NOTA: no funciona para todas las topologías
   ![[ f3.5|700]]

3. **Poison Reverse**: Este mecanismo es una mejora del Split Horizon y consiste en anunciar explícitamente rutas inaccesibles con una métrica infinita (por ejemplo, 16 saltos en RIP) en lugar de no anunciarlas. Esto acelera la convergencia al informar a los encaminadores vecinos de la inaccesibilidad de esas rutas evitando así el riesgo de que puedan intentar utilizarla.

4. **Triggered updates (actualizaciones provocadas)**: En lugar de esperar a que transcurra el intervalo de actualización periódica (30 segundos por defecto), un encaminador RIP puede enviar actualizaciones desencadenadas inmediatamente después de detectar un cambio en la red. Esto puede ayudar a acelerar la convergencia, ya que los encaminadores vecinos son informados rápidamente de los cambios en la red.

A pesar de estas soluciones, RIP sigue siendo propenso a los problemas de convergencia lenta y bucles de enrutamiento en comparación con otros protocolos de enrutamiento más avanzados, como OSPF o EIGRP. Por lo tanto, en redes más grandes y complejas, se recomienda utilizar estos protocolos en lugar de RIP.
##  OSPF
*OSPF (Open Shortest Path First)* es un protocolo de enrutamiento de pasarela interior (IGP) que se utiliza para distribuir información de enrutamiento dentro de un *sistema autónomo (AS)*. A diferencia de RIP, que utiliza el algoritmo de vector de distancia, OSPF emplea el *algoritmo de estado de enlace (Link-State)* para calcular las rutas óptimas en una red. OSPF es un protocolo de enrutamiento de convergencia rápida, escalable y eficiente en el uso de recursos, lo que lo hace preferible en redes más grandes y complejas en comparación con RIP.

### Características y componentes clave del encaminamiento OSPF

1. **Algoritmo de estado de enlace (Link-State)**: OSPF utiliza el algoritmo de Dijkstra para calcular la ruta más corta a través de la red. Este algoritmo basado en el estado de enlace considera la topología completa de la red y el coste de los enlaces, en lugar de simplemente contar los saltos.

2. **Áreas**: OSPF divide una red grande en áreas más pequeñas y jerárquicas con el fin de mantener la información de enrutamiento manejable y reducir el volumen de tráfico de enrutamiento. Cada área tiene un identificador numérico único y mantiene su propia base de datos del estado de enlace.
![[ f3.6|700]]
3. **Protocolo de intercambio de estado de enlace (LSA, Link-State Advertisement)**: OSPF utiliza mensajes LSA para compartir información sobre el estado de enlace y la topología de la red con otros encaminadores OSPF dentro de un área. Los encaminadores utilizan esta información para construir un mapa detallado de la red y calcular las rutas óptimas.

4. **Router ID (RID)**: Cada encaminador OSPF tiene un identificador único llamado Router ID, que es una dirección IP de 32 bits que se utiliza para identificar el encaminador en la red OSPF. Por lo general, se elige la dirección IP de la interfaz más alta en el encaminador.

5. **Router DR (Designated Router) y BDR (Backup Designated Router)**: En redes OSPF con enlaces multiacceso (por ejemplo, redes Ethernet), se selecciona un encaminador DR y un encaminador BDR para centralizar y optimizar el intercambio de información entre encaminadores de un área y, de esta manera, mantener la eficiencia en la comunicación.

6. **Tipo de red**: OSPF admite diferentes tipos de redes, como transmisiones, no transmisiones y punto a punto. Cada tipo de red tiene características específicas que afectan la forma en que OSPF funciona en la red.

7. **Convergencia más rápida**: OSPF es un protocolo de convergencia rápida debido a que reacciona rápidamente a los cambios en la topología y calcula rápidamente las rutas óptimas, lo que resulta en un menor tiempo de interrupción del servicio en comparación con RIP.

8. **Autenticación**: OSPF admite la autenticación para garantizar que los encaminadores compartan información solo con encaminadores autorizados y, de esta manera, proteger la información de enrutamiento.
### Mensajes
Los encaminadores OSPF intercambian varios tipos de mensajes utilizando el protocolo OSPF para establecer relaciones de adyacencia y compartir información sobre la topología de la red. Estos mensajes son:

1. **Hello (Saludo)**: Los encaminadores OSPF envían paquetes Hello periódicamente a través de su interfaz de red para descubrir otros encaminadores OSPF en la misma subred y establecer relaciones de adyacencia. Los paquetes Hello contienen información como el Router ID, el área OSPF, el intervalo Dead y el intervalo Hello. Los encaminadores OSPF deben tener parámetros compatibles en sus paquetes Hello para establecer una relación de adyacencia.

2. **Database Description (DD - Descripción de la Base de Datos)**: Una vez que se establece una relación de adyacencia entre los encaminadores OSPF, intercambian paquetes de descripción de la base de datos (DBD) para sumarizar la información de su base de datos de estado de enlace (LSDB). Estos paquetes contienen información básica sobre las actualizaciones del estado de enlace, como el tipo de paquete y las secuencias de números, pero no el contenido completo.

3. **Link State Request (LSR - Solicitud de Estado de Enlace)**: Si un encaminador OSPF necesita información adicional sobre alguna actualización del estado de enlace que descubrió a través del intercambio de paquetes DBD, envía un mensaje "Link State Request" (LSR) al encaminador vecino. El LSR especifica qué información de estado de enlace adicional se requiere en función del Router ID y del número de secuencia del estado de enlace de interés.

4. **Link State Update (LSU - Actualización de Estado de Enlace)**: En respuesta a un mensaje LSR, el encaminador OSPF vecino enviará un mensaje "Link State Update" (LSU) al encaminador solicitante. Los paquetes LSU contienen información detallada y actualizada sobre el estado de enlace, incluidos los datos de costos y métricas para cada conexión en la red.

5. **Link State Acknowledgment (LSAck - Confirmación de Estado de Enlace)**: Cuando un encaminador OSPF recibe un paquete LSU, envía un mensaje Link State Acknowledgment (LSAck) al encaminador vecino que envió el LSU, confirmando así que recibió y procesó la información del estado de enlace.

Estos cinco tipos de mensajes son fundamentales para el funcionamiento del protocolo OSPF, ya que permiten que los encaminadores en una red OSPF descubran, compartan y sincronicen información sobre la topología de la red, lo que a su vez les permite calcular las rutas óptimas utilizando el algoritmo SPF (Shortest Path First).

### Tipos de encaminadores
OSPF utiliza sus propios tipos de encaminadores especializados para mejorar la gestión y el rendimiento en redes grandes y complejas. Los principales tipos de encaminadores en OSPF son:

1. **Encaminador interno (Internal router)**: Un encaminador interno tiene todas sus interfaces de red conectadas a una única área OSPF. Este tipo de encaminador solamente enruta paquetes dentro de su área y se encarga de construir y mantener una base de datos de topología local a esa área.

2. **Encaminador de borde de área (Area Border Router, ABR)**: Un ABR se encuentra en la frontera entre dos o más áreas OSPF, conectando estas áreas a la red principal (backbone) del área OSPF 0. El ABR es responsable de resumir las rutas de su área local y compartirlas con otras áreas, así como de recibir resúmenes de rutas de otras áreas y distribuirlos dentro de su área local.

3. **Encaminador de backbone (Backbone router)**: Un encaminador de backbone tiene al menos una de sus interfaces de red conectada al área OSPF 0 (la columna vertebral de la red OSPF). Los encaminadores de backbone son responsables de distribuir información de enrutamiento entre las áreas OSPF y mantener la estabilidad en toda la red.

4. **Encaminador de tránsito (Transit router)**: Un encaminador de tránsito tiene al menos una interfaz de red conectada a una red de tránsito OSPF (una red que conecta dos o más encaminadores OSPF pero no contiene ninguna estación de trabajo o servidor). Este tipo de encaminador enruta paquetes entre encaminadores OSPF a través de la red de tránsito.

5. **Encaminador designado (Designated router, DR)**: En redes OSPF multiacceso, como Ethernet y redes de transmisión de paquetes por radio, un encaminador designado es seleccionado para gestionar la información de topología y mantener relaciones de adyacencia con otros encaminadores OSPF en la misma red. Este encaminador es responsable de generar y enviar actualizaciones de enrutamiento en nombre de todos los encaminadores de la red multiacceso, lo que reduce la cantidad de tráfico de enrutamiento OSPF y mejora el rendimiento de la red.

6. **Encaminador de respaldo designado (Backup Designated Router, BDR)**: El BDR es otro encaminador OSPF en redes multiacceso que es seleccionado para actuar como respaldo del DR en caso de que el DR falle. El BDR monitorea el DR y está listo para hacerse cargo de sus responsabilidades si fuera necesario.

Estos diferentes tipos de encaminadores en OSPF permiten una mayor eficiencia en la gestión y el rendimiento de las redes, así como una mejor adaptación a diferentes topologías y entornos de red.

En resumen, OSPF es un protocolo de enrutamiento avanzado y eficiente adecuado para su uso en redes más grandes y complejas. Sus características, como el uso del algoritmo de estado de enlace, la división en áreas, la convergencia rápida y la autenticación, lo convierten en una opción sólida para el enrutamiento en redes empresariales y de operadoras.
##  BGP