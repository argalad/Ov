#ampliacionredes #dns
```toc
```
**DNS (Domain Name System)** es un sistema utilizado en Internet para traducir nombres de dominio legibles (*nombres simbólicos*) por humanos en direcciones IP numéricas que las computadoras utilizan para identificar y comunicarse entre sí. El DNS actúa como una guía telefónica para Internet, facilitando la navegación y el acceso a sitios web y servicios en línea.

Funcionamiento del DNS:

1. **Consulta del usuario**: Cuando un usuario ingresa un nombre de dominio en su navegador (por ejemplo, www.example.com), la computadora del usuario realiza una consulta al *resolutor local* del sistema operativo. Si este no tiene la información, realiza una consulta al DNS para obtener la dirección IP asociada con ese nombre de dominio.

2. **Resolución de la consulta**: La consulta DNS se envía primero al *servidor DNS recursivo*, que generalmente es proporcionado por el proveedor de servicios de Internet (ISP) del usuario. Si el servidor DNS recursivo ya tiene la dirección IP en su caché debido a consultas recientes, puede responder directamente a la consulta. Si no, el servidor DNS recursivo comienza el proceso de resolución de la consulta.

3. **Consulta al servidor DNS raíz**: Si el servidor DNS recursivo no tiene la dirección IP en su caché, consulta a uno de los servidores DNS raíz. Los servidores DNS raíz son 13 servidores distribuidos en todo el mundo que contienen información sobre los *servidores DNS de nivel superior (TLD)* para cada dominio de nivel superior (por ejemplo, .com, .org, .net).

4. **Consulta al servidor DNS de nivel superior (TLD)**: El servidor DNS raíz responde con la dirección IP del servidor DNS TLD correspondiente al dominio solicitado (por ejemplo, el servidor DNS TLD para .com). El servidor DNS recursivo consulta entonces al servidor DNS TLD.

5. **Consulta al servidor DNS autoritativo**: El servidor DNS TLD responde con la dirección IP del servidor DNS autoritativo para el nombre de dominio específico (por ejemplo, example.com). El servidor DNS recursivo consulta entonces al servidor *DNS autoritativo*.

6. **Respuesta del servidor DNS autoritativo**: El servidor DNS autoritativo contiene registros DNS para el nombre de dominio específico, incluida la dirección IP asociada. Responde al servidor DNS recursivo con la dirección IP correspondiente al nombre de dominio solicitado.

7. **Respuesta al usuario**: El servidor DNS recursivo recibe la dirección IP del servidor DNS autoritativo y la envía a la computadora del usuario. El navegador del usuario puede utilizar esta dirección IP para establecer una conexión con el servidor web que aloja el sitio web y solicitar el contenido del sitio.

![[f3.1|700]]

Este proceso, aunque puede parecer complicado, generalmente ocurre en milisegundos. El sistema DNS es fundamental para el funcionamiento de Internet, ya que permite a los usuarios acceder a sitios web y servicios en línea utilizando nombres de dominio fáciles de recordar en lugar de tener que recordar direcciones IP numéricas. Además, el DNS también facilita la administración y escalabilidad de Internet al permitir que los nombres de dominio y las direcciones IP se asignen y modifiquen de manera independiente.

### Estructura de la BBDD distribuida
![[f3.2|700]]
¿Cómo se leen?
`www.ucm.es.` ⟶ Full Qualified Domain Name (FQDN)
`www.ucm.es` ⟶ Nombre de dominio relativo

### Tipos de servidores
1. **Autoritativos**: tienen la autoridad sobre esa zona.
	- **Servidor primario**: aquel que tiene la base de datos de esa zona. Sólo hay una por zona.
	- **Servidor secundario**: mantiene una copia de la información del servidor primario. Sirven para la tolerancia frente a fallos.
2. **No Autoritativos**
	- **Cache**: guarda resoluciones previas.

### Tipos de consultas
- **Consultas recursivas**: se realizan a un DNS para que me de directamente la dirección IP que le pido.
- **Consultas iterativas**: se la hacen los DNS entre ellos.

### Tipos de zonas
Una *zona* es una parte administrativa del espacio de nombres de dominio. Una zona contiene información sobre uno o más nombres de dominio y sus correspondientes registros DNS. Estas zonas son administradas por servidores DNS autoritativos, que son responsables de responder a las consultas DNS para los nombres de dominio dentro de sus zonas.

Hay dos tipos principales de zonas en el DNS:

1. **Zonas primarias (o maestras)**: Una zona primaria es la copia principal y editable de la información de un dominio. El servidor DNS autoritativo que mantiene la zona primaria es responsable de realizar cambios en los registros DNS y garantizar que esos cambios se propaguen a otros servidores DNS que mantienen copias de la información del dominio. La zona primaria contiene todos los registros DNS para los nombres de dominio dentro de la zona, incluidos registros A, AAAA, CNAME, MX y otros.

2. **Zonas secundarias (o esclavas)**: Una zona secundaria es una copia de solo lectura de la información de un dominio que se replica desde la zona primaria. Los servidores DNS autoritativos que mantienen zonas secundarias no pueden realizar cambios directamente en los registros DNS. En cambio, sincronizan periódicamente sus datos con la zona primaria a través de un proceso llamado transferencia de zona. Las zonas secundarias se utilizan para proporcionar redundancia y distribución de carga en el sistema DNS, ya que pueden responder a consultas DNS para los nombres de dominio dentro de sus zonas, al igual que las zonas primarias.
3. **Zona Hint**: hace referencia al archivo de configuración utilizado por los servidores DNS recursivos para conocer las direcciones IP de los servidores DNS raíz. 

En resumen, una zona es una parte administrativa del espacio de nombres de dominio que contiene información sobre uno o más nombres de dominio y sus registros DNS. Las zonas primarias son copias editables de la información del dominio y se utilizan para realizar cambios en los registros DNS, mientras que las zonas secundarias son copias de solo lectura que se replican desde las zonas primarias y se utilizan para proporcionar redundancia y distribución de carga en el sistema DNS.

### Tipos de registros
Los *registros* DNS son esenciales para el funcionamiento de Internet, ya que permiten la resolución de nombres de dominio a direcciones IP y viceversa. Existen varios tipos de registros DNS, y cada uno tiene un propósito específico. Algunos de los registros DNS más comunes incluyen:

1. **Registro A (Address)**: Este registro se utiliza para asignar un nombre de dominio a una dirección IPv4. Es uno de los registros más comunes y es esencial para el funcionamiento de sitios web y servicios en línea.

2. **Registro AAAA (IPv6 Address)**: Similar al registro A, pero para direcciones IPv6. Este registro asigna un nombre de dominio a una dirección IPv6.

3. **Registro CNAME (Canonical Name)**: Este registro se utiliza para crear alias de otros registros DNS. Por ejemplo, si tienes un sitio web con varios subdominios, puedes utilizar registros CNAME para redirigir todos ellos al mismo registro A o AAAA.

4. **Registro MX (Mail Exchange)**: Este registro se utiliza para especificar el servidor de correo electrónico que se encarga de recibir y enviar mensajes de correo electrónico para un dominio.

5. **Registro NS (Name Server)**: Este registro indica qué servidores DNS son responsables de la información sobre un dominio. Cada dominio debe tener al menos dos servidores DNS para garantizar redundancia y disponibilidad.

6. **Registro PTR (Pointer)**: Este registro se utiliza para la resolución inversa de direcciones IP a nombres de dominio. Es útil para verificar la autenticidad de un servidor y para aplicaciones como el correo electrónico.

7. **Registro SRV (Service)**: Este registro se utiliza para especificar la ubicación de servicios específicos en un dominio, como servidores de mensajería instantánea o servicios de voz sobre IP.

8. **Registro TXT (Text)**: Este registro permite almacenar información de texto en el DNS. A menudo se utiliza para la verificación de la propiedad del dominio, la implementación de políticas de seguridad de correo electrónico (como SPF y DKIM) y otros fines.

9. **Registro SOA (Start of Authority)**: Este registro contiene información sobre el dominio, como el servidor DNS principal, el correo electrónico del administrador y los parámetros de actualización y vencimiento del dominio.

10. **Registro MX (Mail Exchanger)**

### Sintaxis
 La sintaxis de un archivo de zona DNS es la siguiente:

1. **Un SOA (Start of Authority) Record**: El primer registro del archivo de zona que indica la autoridad del archivo y contiene información sobre quién es el servidor DNS maestro.
```
example.com.       IN SOA  ns1.example.com. admin.example.com. (
                              2021100101 ; serial (fecha en formato AAAAMMDD##)
                              3600       ; refresh (1 hora)
                              1800       ; retry (30 minutos)
                              604800     ; expire (1 semana)
                              86400 )    ; minimum (1 día)
```

2. **Un NS (Name Server) Record**: Indica qué servidores DNS tienen autoridad sobre el dominio y manejan la resolución de nombres de dominio en ese espacio de nombres.
```
example.com.       IN NS    ns1.example.com.
example.com.       IN NS    ns2.example.com.
```

3. **A (Address) Record**: Mapea un nombre de dominio a una dirección IPv4.
```
example.com.       IN A    192.168.1.1
server1.example.com.       IN A    192.168.1.2
```

4. **AAAA (IPv6 Address) Record**: Mapea un nombre de dominio a una dirección IPv6.
```
example.com.       IN AAAA    2001:db8::1
server1.example.com.       IN AAAA    2001:db8::2
```

5. **MX (Mail Exchange) Record**: Indica a qué servidor de correo deben entregarse los correos electrónicos para ese dominio.
```
example.com.       IN MX   10 mail.example.com.
```

6. **CNAME (Canonical Name) Record**: Es un alias o redireccionamiento de un nombre de dominio a otro.
```
www.example.com.   IN CNAME  example.com.
ftp.example.com.   IN CNAME  server1.example.com.
```

7. **TXT (Text) Record**: Contiene información adicional relacionada con el dominio, como registros SPF (Sender Policy Framework), DKIM (DomainKeys Identified Mail) y DMARC (Domain-based Message Authentication, Reporting & Conformance).
```
example.com.       IN TXT   "v=spf1 mx -all"
```

Estos son los registros más comunes en un archivo de zona DNS. Cada línea en el archivo de zona comienza con el nombre del recurso (subdominio), seguido por el tiempo de vida (TTL, opcional), el registro "IN" (Internet), el tipo de registro y su valor correspondiente. También es importante recordar que cada línea en el archivo de zona DNS debe finalizar con un punto (.) at the end of the fully qualified domain name.
