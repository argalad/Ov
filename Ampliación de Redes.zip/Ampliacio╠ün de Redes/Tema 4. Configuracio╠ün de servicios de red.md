#ampliacionredes 
```toc
```
##  Configuración del servicio DHCP
##  Configuración de NAT
##  Configuración del servicio DNS
##  Configuración y evaluación de servidores