#ampliacionredes #ipv6
```toc
```
## Repaso de IPv4 y comparación con IPv6
### IPv4
El protocolo IP que hemos venido utilizando hasta ahora es el protocolo IPv4, deﬁnido en el RFC791, de 1981. Cuando se propuso, se pensó que un direccionamiento basado en 32 bits, lo que proporciona un espacio de direcciones de $2^{32} = 4.294.967.296$ (más de 4 mil millones), sería suﬁciente. Además, dicho espacio de direcciones se dividió en clases, según el tamaño de las redes objeto.
![[f2.1|700]]
En los últimos años, con la expansión de Internet, el protocolo IPv4 ha debido afrontar dos problemas importantes: la escasez de direcciones libres, y la explosión de las tablas de rutas en los encaminadores troncales. 
Se han propuesto dos soluciones a dichos problemas: por un lado, para sortear la escasez de direcciones disponibles, se ha venido utilizando *NAT (Network Address Translation)*, traducción de direcciones de Internet; por otro lado, el crecimiento desmesurado de las tablas de rutas en los encaminadores troncales se ha visto suavizada por el empleo del direccionamiento *CIDR (Classless Inter-Domain Routing)*, encaminamiento sin clases. 
Sin embargo, NAT modiﬁca los datagramas en tránsito, lo que hace más difícil el funcionamiento de los protocolos en tiempo real, que necesitan conocer su dirección pública, e impide que funcione *IPSEC*, al modiﬁcar los datagramas, lo que invalida la integridad, y también necesita modiﬁcar los puertos, lo que impide el uso de cifrado del contenido del datagrama; esto obliga a la creación de *túneles* y *VPN*.

### Necesidad de IPv6
IPv4 tiene muchas limitaciones:
- **La organización en clases** hace que se desperdicien muchas direcciones porque no se pueden compartir direcciones entre organizaciones, esto además es un problema para los encaminadores troncales porque cada vez que tenemos una subred, ésta tiene que ser conocida por estos encaminadores. Si tenemos millones de subredes, tenemos que recorrer esas tablas inmensas y ello es muy costoso.
  >[!info]-
  >CIDR ayuda a disminuir las tablas de encaminamiento y mejora la distribución de las direcciones, ya que cada región tiene un identificador general, por lo que si tenemos que enviar un paquete a América desde los encaminadores europeos, sólo se comprueba en una tabla (la de encaminadores regionales) una única dirección, y ya sabemos qué camino tiene que seguir, lo que libera el cómputo.
- **El formato de datagrama** es ineficiente ya que la longitud de la cabecera es variable (por las opciones que tiene) y los encaminadores no saben qué mirar a priori, luego examinando la cabecera tiene que calcular un nuevo CRC antes incluso de tomar la decisión de por dónde lo va a encaminar.
- **La fragmentación**: tiene que ir "investigando" según el MTU cuánto tiene que fragmentar para que los datos lleguen completos al otro lado, eso es costoso.
- **La seguridad**: en sus inicios el proyecto era cooperativo y nadie pensó que alguien lo utilizaría para ataques porque ese no era el objetivo, pero eso no era la realidad. Se añadió un parche *IPSEC* que permite solventar esos problemas, pero en IPv6 forma parte del mismo. IPSEC no funciona sobre NAT.
- **Multicast**: ha quedado restringido para el uso local y nunca se ha usado a nivel global. En la actualidad con IPTV necesita utilizar este sistema en su diseño.
  
## Formato del datagrama IPv6. Cabeceras de extensión
![[f2.2|700]]
- **Versión (4 bits):** 6 en este caso.
- **Clase de tráfico (8 bits)**: equivalente al antiguo ToS (Time of Service). Nos permite distinguir entre el tipo de tráfico que necesitamos (tiempo real, normal, gestión de red) y nos sirve además para especificar propiedades ya que mediante eso podemos saber cuáles necesitamos que se envíen antes y cuáles podemos descartar (i.e. cuando vemos una película en streaming vs leer una web).
- **Etiqueta de flujo (20 bits)**: permite identificar el tipo de flujo que voy a transmitir, antes de empezar la transmisión de los datagramas. Esto permite a los encaminadores ponerse de acuerdo para garantizar un mínimo ancho de banda para todos los datagramas que vayan con una etiqueta en específico *QoS (Quality of Service)*.
- **Longitud de la carga (16 bits)**: longitud en bytes de los datos (no de la cabecera pues es fija).
- **Siguiente cabecera (8 bits)**: identifica el protocolo o cabecera de extensión que sigue a la cabecera. UPD = 17 y TCP = 6.
- **Límite de saltos (8 bits)**: es el sustituto de TTL (Time To Live). Se descuenta uno cada vez que entre a un encaminador.
  >[!info]-
  >La fragmentación no se realiza en IPv6, pero sí que existe el envío de datagramas fragmentados. Esto se hace en el emisor y se recompone en el receptor, pero no en tránsito.
- **Dirección origen (128 bits)**
- **Dirección destino (128 bits)**
### Fragmentación y Cabecera de extensión
Cada cabecera IP adicional viene con un campo donde *Next Header* nos dice qué tipo es y con *Header Length* cuánto ocupa.
- **Next header (8 bits)**: puede ser TCP = 6 o UDP= 17.
- **Reservado (8 bits)**
- **Fragment Offset (13 bits)**: se mantiene con 13 bits por practicidad al tener en IPv4 ese tamaño.
- **MF (1 bit)**: indica si hay más fragmentos o no.
- **Identificador (32 bits)**
  >[!info]-
  >En IPv6 se impone que MTU ≥ 1200 y eseto es porque los datagramas que se envían tienen que ir siempre bastante ajustados a la velocidad de la red.

A la hora de fragmentar el ==Next Header== se añade como una copia directa en la cabecera de extensión de la cabecera de IPv6, además cambiamos el valor de ==Next Header== de la cabecera de IPv6 por 44 para indicar esta fragmentación y ==MF== según los fragmentos que tengamos.
![[Ampliación de Redes/Resources/f2.3|700]]
## Direccionamiento IPv6
Las direcciones IP cuentan con 128 bits. En IPv6 el objetivo es facilitar el encaminamiento, pero ya vamos a ver que no ocurre así. Todas las direcciones van a empezar con un *prefijo de formato (FP)* que son los bits más significativos (los primeros), los cuales es importante conocer. IPv6 soporta diferentes tipos de direcciones:
1. **Unicast**: identifican a una sola interfaz dentro de una red. Un datagrama sólo se entraga a esa interfaz.
2. **Multicast**: identifican a un grupo de interfaces y el datagrama se entrega a todas las interfaces del grupo.
3. **Anycast**: identifican a un grupo de interfaces pero el datagrama sólo se entrega a una interfaz dentro del grupo.

### Ámbitos y zonas
Un **ámbito** es el espacio donde la dirección es válida. 
Tipos de ámbitos según el tipo de dirección:

#### Unicast
1. **Enlace local**: una dirección con ámbito de enlace local sólo es válida dentro de la subred donde está definida. Ningún encaminador dará salida a un datagrama que vaya dirigido a una red de enlace local. Permiten realizar descubrimiento de vecinos (equivalente a ARP en IPv4).
   
   $FP=FE8_{(16)}≈ FE80_{(16)}\text{con longitud } = 10$
   `1111:1110:10XX:XXXX:XXXX:XXXX:XXXX:XXXX`
   Prefijo: $fe80::/10^{2}$
   ![[f2.4|500]]
2. **Sitio local**: sólo es válida dentro de un *sitio*. Ya no se pueden usar por problemas de incompatibilidad a la hora de comprar empresas y unificar sus redes.
   
   $FP=FEC_{(16)}\text{ con longitud 10}$
   `1111:1110:11XX:XXXX:XXXX:XXXX:XXXX:XXXX`
   Prefijo: $fc00::/7^{3}$ 
   ![[f2.5|700]]
   Podríamos enviar un mensaje de A a D sólo si ambos enlaces estuvieran dentro del mismo sitio. Para conocer la zona a la que un encaminador tiene que enviar un datagrama, podemos ver su identificador de zona mediante el sistema operativo. Si lo que queremos es comunicar dos zonas con un encaminador en medio, no se puede realizar directamente con nuestras direcciones locales, habría que crear una zona mayor que incluyese esas 2 zonas y utilizar una dirección de sitio local. Una interfaz puede tener muchas direcciones IP, tantas como queramos.
3. **Global agregable:** es válida en todo Internet.
   Prefijo: $2000::/3$
   
   Primera especificación histórica:
   ![[f2.6|700]]
   - **TLA (Top Level Aggregator)**: servía para asignarle una dirección a cada región del planeta (por continentes). Si necesitaran crecer más, utilizarían bits del reservado.
   - **NLA (Next Level Aggregator)**: se brindan a los ISP de cada región, si necesitaran crecer más, utilizarían bits del reservado.
   - **SLA (Size Level Aggregator)**: se utiliza para crear redes internas.
     
    Nueva especificación:
    ![[f2.7|700]]
    Los proovedores necesitan más direcciones que las que les darían si tuvieran una dirección de /48; por ello, por ejemplo: `2001:d000::/20` sería la dirección de una SDP que le permitiría tener $2^{12}\cdot 2^{15}$ direcciones para asignar a sus clientes. Así, quien brinda las direcciones en Europa es RIPE y en España red.es. Las direcciones `2001:db8::` están reservadas a ejemplos.
    
    Actualmente están en uso las dos especificaciones pero dependiendo de lo grande que seas te dan una u otra.
#### Unique Local Addresses (ULA)
#### Multicast
$FF00_{(16)}$
$FP=FF_{(16)} \text{ con longitud }=8$
`1111:1111:XXXX:XXXX:XXXX:XXXX:XXXX`
![[f2.8|700]]
- **R = Redezvous Point**, se usa cuando queremos dirigir el tráfico por un camino en concreto (pasando por algún encaminador específico), el RP es un nodo.
- **P = Prefix**, si vale 0 ⟹ long. prefijo tiene que valer 0 también. Esto se usa cuando el emisor quiere que el resto de la dirección dependa de dónde está situado. Para ello pone el bit a 1 y en long. prefijo ≠ 0.
- **T = Temporal**, se usa en live streaming, determina si me he inventado o no la dirección de grupo. Si vale 1 significa que no es una dirección bien conocida, sin embargo no siempre es así y existen direcciones permanentes (bien conocidas) en cuyo caso el bit valdría 0.
## ICMPv6 (Internet Control Message Protocol v6)
Es un protocolo de control y diagnóstico utilizado en redes IPv6. Es la versión actualizada de ICMP.

Se utiliza para enviar mensajes de control y error entre dispositivos en una red IPv6. Proporciona funciones importantes como la detección de errores, la administración de la red y el mantenimiento de la conectividad. Algunos de los mensajes ICMPv6 más comunes incluyen el eco (ping), la solicitud y anuncio de vecinos, y los mensajes de redirección.

### Descubrimiento de vecinos (Neighbor Discovery)
Permite a los dispositivos de la red descubrir y comunicarse directamente entre sí en la misma subred.

El descubrimiento de vecinos en ICMPv6 implica el uso de varios tipos de mensajes ICMPv6, como *Neighbor Solicitation (NS)* (Solicitud de vecino) y *Neighbor Advertisement (NA)* (Anuncio de vecino), para realizar las siguientes funciones:

1.  **Resolución de direcciones IPv6 a direcciones MAC**: Un dispositivo que necesita comunicarse con otro dispositivo en la misma subred envía un mensaje de *Neighbor Solicitation (NS)* multicast preguntando por la dirección MAC asociada a una dirección IPv6 específica. El dispositivo destinatario responde con un mensaje de *Neighbor Advertisement (NA)* que incluye la dirección MAC solicitada.
   
   El mensaje *NS* se construye de la siguiente manera: 
   1. Toma los últimos 24 bits de la dirección IPv6 del nodo que deseas descubrir. Por ejemplo, si la dirección IPv6 es `2001:0db8:85a3:0000:0000:8a2e:0370:7334`, los últimos 24 bits son `0370:7334`.
   2. Añade el prefijo de la dirección de multidifusión Solicited-Node, que es **`ff02::1:ff::/104`**. La dirección de multidifusión resultante será `ff02::1:ffxx:xxxx`, donde `xx:xxxx` son los últimos 24 bits de la dirección IPv6 del nodo a descubrir.
   3. Sustituye los últimos 24 bits de la dirección IPv6 en la dirección de multidifusión. En nuestro ejemplo, la dirección de multidifusión del nodo a descubrir sería `ff02::1:ff70:7334`.

   El datagrama IPv6 resultante se encapsula en una trama Ethernet que va dirigida a la dirección de multidifusión `33:33:ff:70:73:34`, obtenida a partir del prefijo `33:33` y añadiendo los últimos 32 bits de la dirección de multidifusión IPv6.
    
2.  **Descubrimiento de nuevos encaminadores en la red**: Cuando un dispositivo se une a la red, envía mensajes de *Router Solicitation (RS)* multicast para solicitar información de enrutamiento y anuncios de vecinos. Los routers en la red responden con mensajes de *Router Advertisement (RA)* que incluyen información sobre las rutas predeterminadas y otros parámetros de configuración. Pasos para la conexión:
	1. **Router Solicitation (RS)**: Cuando un dispositivo (por ejemplo, una computadora o un teléfono) se conecta a una red IPv6, necesita encontrar un encaminador para enviar paquetes fuera de la red local. Para hacer esto, el dispositivo envía un mensaje de *Router Solicitation* a la dirección multicast de "todos los encaminadores" `ff02::2`. Este mensaje solicita a los encaminadores disponibles que anuncien su presencia.
		- `ff`: multicast.
		- `0`: flag que indica que la dirección es bien conocida.
		- `2`: de mi ámbito/enlace.
		- `::2`: dirigido a encaminadores.	  
	2. **Router Advertisement (RA)**: Los encaminadores en la red local, al recibir una *Router Solicitation*, responden con mensajes de *Router Advertisement*. Estos mensajes tienen dirección origen la dirección de enlace local de la red y se envían a la dirección multicast de "todos los nodos" `ff02::1` e incluyen información sobre el encaminador, como la dirección del encaminador, el tiempo de vida del encaminador (router lifetime) y las subredes/prefijos disponibles. Los *Router Advertisement* también pueden enviarse periódicamente, incluso si no se ha recibido una *Router Solicitation*, para mantener a los dispositivos informados sobre la presencia de encaminadores.
    
3.  **Detección de cambios en la red**: El descubrimiento de vecinos también permite a los dispositivos detectar cambios en la conectividad de la red. Por ejemplo, si un dispositivo deja de recibir respuestas a los mensajes de *Neighbor Solicitation*, puede inferir que el vecino ya no está disponible.
    
4.  **Mantenimiento de la tabla de vecinos**: Cada dispositivo IPv6 mantiene una tabla de vecinos en la que se almacenan las asociaciones entre direcciones IPv6 y direcciones MAC. Esta tabla se actualiza mediante la recepción de mensajes de *Neighbor Advertisement* y la expiración de entradas inactivas.

### Autoconfiguración (SLAAC, Stateless Address AutoConfiguration)
En este proceso, los dispositivos (nodos) en una red IPv6 generan automáticamente sus propias direcciones IP utilizando una combinación de prefijos de red proporcionados por los routers y la dirección MAC del dispositivo.

Supongamos que tenemos una red IPv6 con un router y un dispositivo (un ordenador) que se conecta a la red. El router ya está configurado con un prefijo de red IPv6, por ejemplo, `2001:db8:abcd::/64`. El dispositivo tiene una dirección MAC de `00:11:22:33:44:55`. A continuación, se describen los pasos para la autoconfiguración SLAAC:
1. El dispositivo se conecta a la red y envía un mensaje *Router Solicitation (RS)* a la dirección multicast de todos los routers `ff02::2`, solicitando información sobre la red.
2. El router recibe la solicitud y responde con un mensaje *Router Advertisement (RA)* que contiene el prefijo de red `2001:db8:abcd::/64` y otros parámetros de configuración, como el tiempo de vida de la dirección IP.
3. El dispositivo recibe el mensaje *RA* y extrae el prefijo de red. A continuación, genera el identificador de interfaz utilizando su dirección MAC `00:11:22:33:44:55` y el *método EUI-64*:
	1. Dividir la dirección MAC de 48 bits en dos partes de 24 bits.
		- `00:11:22` 
		- `33:44:55`
	2. Insertar el valor hexadecimal `fffe` en el medio de las dos partes: `00:11:22:ff:fe:33:44:55`.
	3. Invertir el séptimo bit (bit universal/local) en la primera sección de la dirección MAC modificada. En este caso, la primera sección es `00:11:22`, en binario `00000000 00010001 00100010`. Al invertir el séptimo bit se quedaría en `00000010 00010001 00100010`, que en hexadecimal sería `02:11:22`.
	4. Se combinan ambas partes para obtener el identificador de interfaz: `0211:22ff:fe33:4455`
4. El dispositivo combina el prefijo de red `2001:db8:abcd::/64` con el identificador de interfaz `0211:22ff:fe33:4455` para crear una dirección IP completa: `2001:db8:abcd:0:211:22ff:fe33:4455`.
5. Antes de asignar la dirección IP a su interfaz de red, el dispositivo realiza la *detección de direcciones duplicadas (DAD)* enviando un mensaje de *Neighbor Solicitation (NS)* a la dirección multicast de la posible dirección IP `2001:db8:abcd:0:211:22ff:fe33:4455`.
6. Si no hay respuesta al mensaje *NS*, significa que la dirección IP no está en uso en la red y el dispositivo puede asignarla a su interfaz de red.
7. Con la dirección IP asignada, el dispositivo puede comenzar a comunicarse en la red IPv6 utilizando la autoconfiguración SLAAC.
Este tipo de configuración permitía saber quién eres en todo momento y no permitía ser anónimo en la red, por el contrario si se utilizaba una dirección que vaya combiando cada cierto tiempo (fue una propuesta) traía problemas a los administradores de sistemas y   también al usuario al tener que conectarse y desconectarse constantemente de la red, por ello se ha desaconsejado el uso de este algoritmo y actualmente se recomienda visar el RiD (Router ID) unido a cualquier función criptográfica SHA-1 o SHA-256 para generar éstas direcciones de tal manera que tendríamos una mezcla de:
`Prefijo de red | ID de interfaz | Network ID | DAD_counter | secret_key |`
- **Prefijo de red**: por lo que si estoy en redes diferentes cambiará de dirección.
- **ID del interfaz**: depende del SO.
- **Network ID**: depende del nombre del interfaz o el número.
- **DAD counter**: un contado de duplicados.
- **secret_key**: depende del SO.
>[!info]- Nota
>Una máquina siempre hace primero una generación de dirección de enlace local para autoconfigurarse `fe80::/64` como prefijo y a partir de ahí genera una dirección para ella misma y luego tiene que hacer una prueba de dirección duplicada (DAD) preguntando a sus vecinos si alguno tiene la dirección que acaba de generarse para sí mismo.

##  Mecanismos de transición de IPv4 a IPv6
La transición de IPv4 a IPv6 es un proceso gradual que requiere la coexistencia de ambos protocolos durante un tiempo prolongado. Existen varios mecanismos de transición diseñados para facilitar la interoperabilidad entre redes IPv4 e IPv6. Algunos de los mecanismos de transición más comunes incluyen: dual stack, túneles, traducción de protocolos, redes híbridas, ISATAP.

### Túneles IPv6 sobre IPv4
Los túneles 6to4 son un mecanismo de transición que permite la comunicación entre redes IPv6 a través de una infraestructura de red IPv4 existente. La idea principal detrás de 6to4 es encapsular el tráfico IPv6 dentro de paquetes IPv4 para que puedan ser transportados a través de redes IPv4. Esto permite a los nodos IPv6 comunicarse entre sí incluso si están separados por redes IPv4.

El funcionamiento de los túneles 6to4 se basa en la utilización de direcciones IPv6 especiales que incluyen una dirección IPv4 pública. Estas direcciones IPv6 tienen un prefijo 6to4 de `2002::/16`, seguido de los 32 bits de la dirección IPv4 pública del nodo, y finalmente, 80 bits para el identificador de interfaz. Por ejemplo, si una dirección IPv4 pública es `192.0.2.1`, la dirección IPv6 6to4 correspondiente sería `2002:c000:0201::/48`.

Aquí hay un resumen de cómo funcionan los túneles 6to4:

1. Los nodos IPv6 que deseen utilizar túneles 6to4 deben tener una dirección IPv4 pública. A partir de esta dirección IPv4, se crea una dirección IPv6 con prefijo 6to4, como se describió anteriormente.

2. Los nodos IPv6 configuran un enrutador 6to4, que actúa como punto de entrada y salida para el tráfico 6to4. Este enrutador 6to4 debe tener una dirección IPv4 pública y una dirección IPv6 con prefijo 6to4.

3. Cuando un nodo IPv6 desea comunicarse con otro nodo IPv6 a través de una red IPv4, el tráfico se envía al enrutador 6to4, que encapsula los paquetes IPv6 dentro de paquetes IPv4.

4. Los paquetes encapsulados se envían a través de la red IPv4 hasta llegar al enrutador 6to4 de destino, que desencapsula los paquetes y extrae el tráfico IPv6 original.

5. Finalmente, el tráfico IPv6 desencapsulado se envía al nodo IPv6 de destino.

Los túneles 6to4 permiten la comunicación entre redes IPv6 sin requerir cambios significativos en la infraestructura de red IPv4 existente. Sin embargo, este mecanismo tiene algunas limitaciones, como la dependencia de direcciones IPv4 públicas y la posible degradación del rendimiento debido al encapsulamiento y desencapsulamiento de paquetes. Además, 6to4 no funciona bien en entornos donde se utilizan dispositivos NAT (Network Address Translation). En tales casos, se pueden utilizar otros mecanismos de transición, como Teredo o NAT64.