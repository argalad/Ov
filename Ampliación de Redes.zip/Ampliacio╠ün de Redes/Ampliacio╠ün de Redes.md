#ampliacionredes 
## [[Tema 1. Conceptos avanzados de TCP ]]
## [[Tema 2. Internet de nueva generación. IPv6]]
## [[Tema 6. Protocolos de encaminamiento en IPv4 e IPv6]]
## [[Tema 4. Configuración de servicios de red]]
## [[Tema 5. Introducción a la seguridad]]


### El problema de las clases
IPv4 sólo permite un encaminamiento jerárquico en 2 niveles:
- netid
- hostid
Hay que mantener una entrada en la tabla de encaminamiento para cada destino (red) posible en Internet.

## BGP
### Atributos de ruta
- Bien conocidos
	- Obligatorios
	- No obligatorios
- Opcionales
	- Transitivos
	- No transitivos